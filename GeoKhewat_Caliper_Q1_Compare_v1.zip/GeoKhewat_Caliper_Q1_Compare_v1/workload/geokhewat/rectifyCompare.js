'use strict';
const { WorkloadModuleBase } = require('@hyperledger/caliper-core');
const GRID = 24;
const LON0 = 75.6000;
const LAT0 = 31.2000;
const DX = 0.00035;
const DY = 0.00035;
const W = 0.00012;
const H = 0.00012;
const EPS = 0.0000008; // ~0.7% per dimension; area change stays <2%.
function pid(i) { return `P${String(i).padStart(4, '0')}`; }
function neighbours(i) {
    const r = Math.floor(i / GRID), c = i % GRID, out = [];
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
        if (dr === 0 && dc === 0) continue;
        const rr = r + dr, cc = c + dc;
        if (rr >= 0 && rr < GRID && cc >= 0 && cc < GRID) out.push(pid(rr * GRID + cc));
    }
    return out;
}
function ringFor(i, shrunken) {
    const r = Math.floor(i / GRID), c = i % GRID;
    const lon = LON0 + c * DX, lat = LAT0 + r * DY;
    const w = shrunken ? W - EPS : W;
    const h = shrunken ? H - EPS : H;
    return [[lon,lat],[lon+w,lat],[lon+w,lat+h],[lon,lat+h]];
}
class RectifyCompare extends WorkloadModuleBase {
    constructor() { super(); this.txIndex = 0; this.totalW = 1; }
    async initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext) {
        await super.initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext);
        this.txIndex = 0; this.totalW = totalWorkers;
    }
    async submitTransaction() {
        const start = Number(this.roundArguments.subsetStart);
        const size = Number(this.roundArguments.subsetSize);
        const globalSeq = this.txIndex++ * this.totalW + this.workerIndex;
        const logical = globalSeq % size;
        const target = start + ((logical * 37) % size); // 37 is coprime to 144.
        const cycle = Math.floor(globalSeq / size);
        const shrunken = (cycle % 2 === 0);
        const request = {
            contractId: this.roundArguments.contractId,
            contractFunction: 'RectifyBoundary',
            invokerIdentity: 'User1',
            contractArguments: [
                pid(target), JSON.stringify(ringFor(target, shrunken)),
                'CALIPER-Q1-RECTIFY', JSON.stringify(neighbours(target))
            ],
            readOnly: false
        };
        await this.sutAdapter.sendRequests(request);
    }
}
module.exports.createWorkloadModule = () => new RectifyCompare();
