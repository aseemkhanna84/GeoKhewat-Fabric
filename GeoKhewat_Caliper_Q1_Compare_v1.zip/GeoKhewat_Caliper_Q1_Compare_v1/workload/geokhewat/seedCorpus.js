'use strict';
const { WorkloadModuleBase } = require('@hyperledger/caliper-core');
const GRID = 24;
const N = GRID * GRID;
const LON0 = 75.6000;
const LAT0 = 31.2000;
const DX = 0.00035;
const DY = 0.00035;
const W = 0.00012;
const H = 0.00012;
function pid(i) { return `P${String(i).padStart(4, '0')}`; }
function neighbours(i) {
    const r = Math.floor(i / GRID), c = i % GRID, out = [];
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
        if (dr === 0 && dc === 0) continue;
        const rr = r + dr, cc = c + dc;
        if (rr >= 0 && rr < GRID && cc >= 0 && cc < GRID) out.push(pid(rr * GRID + cc));
    }
    return out;
}
class SeedCorpus extends WorkloadModuleBase {
    constructor() { super(); this.txIndex = 0; }
    async initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext) {
        await super.initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext);
        this.txIndex = 0;
    }
    async submitTransaction() {
        const i = this.txIndex++;
        if (i >= N) throw new Error(`Seed workload exceeded ${N} parcels`);
        const r = Math.floor(i / GRID), c = i % GRID;
        const lon = LON0 + c * DX, lat = LAT0 + r * DY;
        const ring = [[lon,lat],[lon+W,lat],[lon+W,lat+H],[lon,lat+H]];
        const shares = [{ owner: `O${String(i).padStart(4,'0')}`, num: '1', den: '1' }];
        const request = {
            contractId: this.roundArguments.contractId,
            contractFunction: 'RegisterParcel',
            invokerIdentity: 'User1',
            contractArguments: [
                pid(i), `K${String(i).padStart(4,'0')}`,
                JSON.stringify(ring), JSON.stringify(shares),
                'CALIPER-Q1-SEED', JSON.stringify(neighbours(i))
            ],
            readOnly: false
        };
        await this.sutAdapter.sendRequests(request);
    }
}
module.exports.createWorkloadModule = () => new SeedCorpus();
