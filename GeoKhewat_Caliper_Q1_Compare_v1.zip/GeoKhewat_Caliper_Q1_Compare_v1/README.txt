GeoKhewat Q1 deployed-Fabric comparison package
===============================================

Purpose
-------
Run the same 576-parcel corpus and the same geometry-changing workload against B1, B2, B3 and GK on a fresh Fabric/CouchDB network for each strategy.

Design
------
- Fabric test network, CouchDB, 2 peers, 1 orderer, 4-core Codespace.
- Every strategy starts from a fresh network.
- Corpus is always seeded under GK precision 10 so all strategies begin from exactly the same world state, including the same cell index.
- After seeding, the strategy is switched to B1, B2, B3 or GK.
- Comparison loads: 2, 4, 6, 8 TPS, selected from the measured calibration knee.
- Each load targets a disjoint 144-parcel subset of the 24x24 = 576 corpus, reducing carry-over between load levels.
- Rectifications alternate between two valid geometries that differ by <2% area and pass explicit 8-neighbour lists.
- B1 skips ledger-side topology checking; B2 touches the registry-wide key; B3 reads parcel/neighbour keys; GK uses cell-scoped keys.

Install into existing Caliper workspace
---------------------------------------
Copy scripts/, workload/, benchmarks/ into ~/geokhewat/caliper-benchmarks.

Run one strategy
----------------
cd ~/geokhewat/caliper-benchmarks
bash scripts/run_strategy.sh GK 1

Then repeat:
bash scripts/run_strategy.sh B1 1
bash scripts/run_strategy.sh B2 1
bash scripts/run_strategy.sh B3 1

Recommended after validating one complete pass: repeat reps 2 and 3 for all four strategies.

Outputs
-------
~/geokhewat/q1-evidence/<strategy>_rep<rep>_*_compare.log
~/geokhewat/q1-evidence/<strategy>_rep<rep>_*_compare_report.html
strategy.txt, docker stats, and peer conflict logs are also preserved.

Important
---------
These are controlled test-network measurements, not production-capacity measurements.
