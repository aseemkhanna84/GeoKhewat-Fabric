# GeoKhewat Chaincode v1

Research prototype for Hyperledger Fabric 2.5.

Functions:
- InitLedger
- SetStrategy / GetStrategy
- RegisterParcel
- TransferShare
- RectifyBoundary
- PartitionParcel
- AmalgamateParcels
- QueryParcel
- QueryByCell

Experimental strategies:
- B1: parcel/write-only baseline (no on-ledger neighbour validation)
- B2: registry-wide conflict key
- B3: parcel + neighbour read keys
- GK: geohash cell-scoped conflict domains

## Deploy

From the Codespace:

```bash
cd ~/geokhewat/geokhewat-chaincode
npm install
npm shrinkwrap
cd ~/geokhewat/fabric-samples/test-network
./network.sh deployCC -ccn geokhewatcc -ccp ~/geokhewat/geokhewat-chaincode -ccl javascript -c geokhewat
```

Do not use performance numbers from the generic `basic` sample in the paper.
