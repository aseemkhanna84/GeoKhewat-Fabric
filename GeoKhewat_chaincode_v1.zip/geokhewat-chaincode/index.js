'use strict';
const GeoKhewatContract = require('./lib/geokhewat-contract');
module.exports.contracts = [GeoKhewatContract];
