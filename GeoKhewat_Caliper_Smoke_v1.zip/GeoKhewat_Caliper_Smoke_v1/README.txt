GeoKhewat Caliper Smoke Test
============================

Purpose: verify that Hyperledger Caliper 0.6.0 can connect to the already deployed GeoKhewat Fabric test network and submit real RegisterParcel transactions.

1) Copy the three folders (scripts, workload, benchmarks) into ~/geokhewat/caliper-benchmarks.
2) Run: bash scripts/setup.sh
3) Ensure GeoKhewat strategy is GK precision 10.
4) Run:
   npx caliper launch manager --caliper-workspace . --caliper-benchconfig benchmarks/geokhewat/smoke.yaml --caliper-networkconfig networks/geokhewat/network.yaml 2>&1 | tee ~/geokhewat/q1-evidence/caliper-smoke.log
5) Keep report.html and caliper-smoke.log.

This smoke test is only for connectivity and basic write-path validation. Do not use its result as the final B1/B2/B3/GK comparative experiment.
