#!/usr/bin/env bash
set -euo pipefail

WORKSPACE="${HOME}/geokhewat/caliper-benchmarks"
FABRIC="${HOME}/geokhewat/fabric-samples/test-network"

cd "$WORKSPACE"
mkdir -p networks/geokhewat benchmarks/geokhewat workload/geokhewat "${HOME}/geokhewat/q1-evidence"

CCP_SRC="$FABRIC/organizations/peerOrganizations/org1.example.com/connection-org1.json"
KEY_DIR="$FABRIC/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp/keystore"
CERT="$FABRIC/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp/signcerts/cert.pem"

if [[ ! -f "$CCP_SRC" ]]; then
  echo "ERROR: connection-org1.json not found at $CCP_SRC"
  exit 1
fi

KEY="$(find "$KEY_DIR" -maxdepth 1 -type f | head -n 1)"
if [[ -z "${KEY:-}" || ! -f "$KEY" ]]; then
  echo "ERROR: Org1 admin private key not found in $KEY_DIR"
  exit 1
fi
if [[ ! -f "$CERT" ]]; then
  echo "ERROR: Org1 admin certificate not found at $CERT"
  exit 1
fi

cp "$CCP_SRC" networks/geokhewat/connection-org1.json

cat > networks/geokhewat/network.yaml <<YAML
name: GeoKhewat Fabric Test Network
version: "2.0.0"

caliper:
  blockchain: fabric

channels:
  - channelName: geokhewat
    contracts:
      - id: geokhewatcc

organizations:
  - mspid: Org1MSP
    identities:
      certificates:
        - name: User1
          clientPrivateKey:
            path: '$KEY'
          clientSignedCert:
            path: '$CERT'
    connectionProfile:
      path: 'networks/geokhewat/connection-org1.json'
      discover: true
YAML

echo "Created networks/geokhewat/network.yaml"
echo "Using private key: $KEY"
echo "Using certificate: $CERT"
