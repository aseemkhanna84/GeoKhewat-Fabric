'use strict';

const { WorkloadModuleBase } = require('@hyperledger/caliper-core');

class RegisterParcelWorkload extends WorkloadModuleBase {
    constructor() {
        super();
        this.txIndex = 0;
    }

    async initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext) {
        await super.initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext);
        this.txIndex = 0;
    }

    async submitTransaction() {
        // Make IDs and coordinates deterministic and unique per worker.
        const n = this.workerIndex * 1000000 + this.txIndex++;
        const id = `SMK_${this.workerIndex}_${n}`;
        const khewat = `K_${this.workerIndex}_${n}`;

        // Non-overlapping small rectangles around Punjab coordinates.
        const cols = 500;
        const col = n % cols;
        const row = Math.floor(n / cols);
        const lon = 75.6000 + col * 0.00070;
        const lat = 31.2000 + row * 0.00060;
        const w = 0.00020;
        const h = 0.00020;
        const ring = [
            [lon, lat],
            [lon + w, lat],
            [lon + w, lat + h],
            [lon, lat + h]
        ];
        const shares = [{ owner: `O_${this.workerIndex}_${n}`, num: '1', den: '1' }];

        const request = {
            contractId: this.roundArguments.contractId,
            contractFunction: 'RegisterParcel',
            invokerIdentity: 'User1',
            contractArguments: [
                id,
                khewat,
                JSON.stringify(ring),
                JSON.stringify(shares),
                'CALIPER-SMOKE',
                '[]'
            ],
            readOnly: false
        };

        await this.sutAdapter.sendRequests(request);
    }
}

function createWorkloadModule() {
    return new RegisterParcelWorkload();
}

module.exports.createWorkloadModule = createWorkloadModule;
