'use strict';
const { WorkloadModuleBase } = require('@hyperledger/caliper-core');
const GRID = 24;
const LON0 = 75.6000;
const LAT0 = 31.2000;
const DX = 0.000135;
const DY = 0.000135;
const W = 0.000120;
const H = 0.000120;
const EPS = 0.0000008;
const START_R = 9, START_C = 9, SIDE = 6; // 36 spatially adjacent parcels.
function pid(i) { return `P${String(i).padStart(4, '0')}`; }
function neighbours(i) {
    const r = Math.floor(i / GRID), c = i % GRID, out = [];
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
        if (dr === 0 && dc === 0) continue;
        const rr = r + dr, cc = c + dc;
        if (rr >= 0 && rr < GRID && cc >= 0 && cc < GRID) out.push(pid(rr * GRID + cc));
    }
    return out;
}
function hotspotIndex(k) {
    const row = Math.floor(k / SIDE) % SIDE;
    const pos = k % SIDE;
    const col = (row % 2 === 0) ? pos : (SIDE - 1 - pos); // snake: consecutive targets are neighbours.
    return (START_R + row) * GRID + (START_C + col);
}
function ringFor(i, shrunken) {
    const r = Math.floor(i / GRID), c = i % GRID;
    const lon = LON0 + c * DX, lat = LAT0 + r * DY;
    const w = shrunken ? W - EPS : W;
    const h = shrunken ? H - EPS : H;
    return [[lon,lat],[lon+w,lat],[lon+w,lat+h],[lon,lat+h]];
}
class RectifyHotspot extends WorkloadModuleBase {
    constructor() { super(); this.txIndex = 0; this.totalW = 1; }
    async initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext) {
        await super.initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext);
        this.txIndex = 0; this.totalW = totalWorkers;
    }
    async submitTransaction() {
        const globalSeq = this.txIndex++ * this.totalW + this.workerIndex;
        const local = globalSeq % (SIDE * SIDE);
        const cycle = Math.floor(globalSeq / (SIDE * SIDE));
        const target = hotspotIndex(local);
        const shrunken = (cycle % 2 === 0);
        await this.sutAdapter.sendRequests({
            contractId: this.roundArguments.contractId,
            contractFunction: 'RectifyBoundary',
            invokerIdentity: 'User1',
            contractArguments: [
                pid(target), JSON.stringify(ringFor(target, shrunken)),
                'CALIPER-Q1-HOTSPOT', JSON.stringify(neighbours(target))
            ],
            readOnly: false
        });
    }
}
module.exports.createWorkloadModule = () => new RectifyHotspot();
