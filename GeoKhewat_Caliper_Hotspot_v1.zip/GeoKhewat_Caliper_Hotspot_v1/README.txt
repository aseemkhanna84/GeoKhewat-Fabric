GeoKhewat deployed-Fabric hotspot validation
============================================
Why this exists
---------------
The first dispersed comparison showed B3 and B1 almost identical while GK paid substantial cell-index overhead. That workload did not create enough adjacent-parcel concurrency to exercise the claimed conflict-domain advantage. Do not repeat that comparison yet.

This package adds a targeted contention experiment:
- Fresh Fabric/CouchDB network for every strategy.
- 576-parcel 24x24 corpus with approximately metre-scale inter-parcel slack.
- 6x6 contiguous hotspot.
- Consecutive Caliper transactions target spatial neighbours in a snake traversal.
- Loads: 2, 4, 6, 8 TPS.
- Primary metrics: commit yield = Succ/(Succ+Fail), latency, and peer MVCC/phantom conflicts.

First validation runs
---------------------
bash scripts/run_hotspot.sh B3 1
bash scripts/run_hotspot.sh GK 1

Only if the mechanism is visible should B1/B2 and repetitions be run.
