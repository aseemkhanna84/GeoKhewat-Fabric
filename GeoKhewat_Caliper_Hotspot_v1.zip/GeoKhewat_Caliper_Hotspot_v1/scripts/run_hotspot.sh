#!/usr/bin/env bash
set -euo pipefail
STRATEGY="${1:-}"
REP="${2:-1}"
STRATEGY="$(echo "$STRATEGY" | tr '[:lower:]' '[:upper:]')"
[[ "$STRATEGY" =~ ^(B1|B2|B3|GK)$ ]] || { echo "Usage: $0 B1|B2|B3|GK [rep]"; exit 1; }
FABRIC="${HOME}/geokhewat/fabric-samples/test-network"
CAL="${HOME}/geokhewat/caliper-benchmarks"
EVID="${HOME}/geokhewat/q1-evidence"
mkdir -p "$EVID"
TAG="HOTSPOT_${STRATEGY}_rep${REP}_$(date +%Y%m%d_%H%M%S)"
cd "$FABRIC"
./network.sh down >/dev/null 2>&1 || true
./network.sh up createChannel -c geokhewat -ca -s couchdb
./network.sh deployCC -ccn geokhewatcc -ccp "${HOME}/geokhewat/geokhewat-chaincode" -ccl javascript -c geokhewat -ccv 1.0 -ccs 1
export PATH="$PATH:$(realpath ../bin)"
export FABRIC_CFG_PATH="$(realpath ../config)"
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_LOCALMSPID="Org1MSP"
export CORE_PEER_TLS_ROOTCERT_FILE="$FABRIC/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt"
export CORE_PEER_MSPCONFIGPATH="$FABRIC/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp"
export CORE_PEER_ADDRESS=localhost:7051
CAFILE="$FABRIC/organizations/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem"
P1TLS="$FABRIC/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt"
P2TLS="$FABRIC/organizations/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/tls/ca.crt"
invoke() {
  peer chaincode invoke -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com --tls --cafile "$CAFILE" \
    -C geokhewat -n geokhewatcc \
    --peerAddresses localhost:7051 --tlsRootCertFiles "$P1TLS" \
    --peerAddresses localhost:9051 --tlsRootCertFiles "$P2TLS" \
    -c "$1"
  sleep 3
}
invoke '{"function":"InitLedger","Args":[]}'
invoke '{"function":"SetStrategy","Args":["GK","10"]}'
cd "$CAL"
bash scripts/setup.sh
npx caliper launch manager --caliper-workspace . \
  --caliper-benchconfig benchmarks/geokhewat/seed-realistic.yaml \
  --caliper-networkconfig networks/geokhewat/network.yaml \
  2>&1 | tee "$EVID/${TAG}_seed.log"
cp -f report.html "$EVID/${TAG}_seed_report.html"
cd "$FABRIC"
invoke "{\"function\":\"SetStrategy\",\"Args\":[\"$STRATEGY\",\"10\"]}"
peer chaincode query -C geokhewat -n geokhewatcc -c '{"function":"GetStrategy","Args":[]}' | tee "$EVID/${TAG}_strategy.txt"
cd "$CAL"
npx caliper launch manager --caliper-workspace . \
  --caliper-benchconfig benchmarks/geokhewat/hotspot.yaml \
  --caliper-networkconfig networks/geokhewat/network.yaml \
  2>&1 | tee "$EVID/${TAG}_hotspot.log"
cp -f report.html "$EVID/${TAG}_hotspot_report.html"
docker logs peer0.org1.example.com 2>&1 | grep -E 'MVCC_READ_CONFLICT|PHANTOM_READ_CONFLICT' > "$EVID/${TAG}_peer_conflicts.txt" || true
printf '\nDONE: %s\nEvidence: %s\n' "$TAG" "$EVID"
