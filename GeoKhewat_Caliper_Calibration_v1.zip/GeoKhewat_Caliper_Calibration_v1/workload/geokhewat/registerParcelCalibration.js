'use strict';

const { WorkloadModuleBase } = require('@hyperledger/caliper-core');

class RegisterParcelCalibration extends WorkloadModuleBase {
    constructor() {
        super();
        this.txIndex = 0;
        this.localRoundIndex = 0;
    }

    async initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext) {
        await super.initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext);
        this.txIndex = 0;
        this.localRoundIndex = roundIndex;
    }

    async submitTransaction() {
        const i = this.txIndex++;
        const seq = this.localRoundIndex * 10000 + this.workerIndex * 1000 + i;
        const id = `CAL_R${this.localRoundIndex}_W${this.workerIndex}_${i}`;
        const khewat = `KC_R${this.localRoundIndex}_W${this.workerIndex}_${i}`;

        // Deterministic non-overlapping rectangles. Spacing is larger than parcel size.
        const cols = 400;
        const col = seq % cols;
        const row = Math.floor(seq / cols);
        const lon = 75.2000 + col * 0.00070;
        const lat = 30.8000 + row * 0.00060;
        const w = 0.00020;
        const h = 0.00020;
        const ring = [
            [lon, lat],
            [lon + w, lat],
            [lon + w, lat + h],
            [lon, lat + h]
        ];
        const shares = [{ owner: `OC_${this.localRoundIndex}_${this.workerIndex}_${i}`, num: '1', den: '1' }];

        const request = {
            contractId: this.roundArguments.contractId,
            contractFunction: 'RegisterParcel',
            invokerIdentity: 'User1',
            contractArguments: [
                id,
                khewat,
                JSON.stringify(ring),
                JSON.stringify(shares),
                'CALIPER-CALIBRATION',
                '[]'
            ],
            readOnly: false
        };

        await this.sutAdapter.sendRequests(request);
    }
}

function createWorkloadModule() {
    return new RegisterParcelCalibration();
}

module.exports.createWorkloadModule = createWorkloadModule;
