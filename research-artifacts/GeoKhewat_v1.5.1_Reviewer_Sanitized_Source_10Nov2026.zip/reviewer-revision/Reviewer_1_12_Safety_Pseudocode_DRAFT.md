# Source-based safety-algorithm pseudocode — working draft

Paper: IJIES 20267430. Derived from `GeoKhewat_artifact_v10/chaincode/lib/geokhewat-contract.js` (v1.5.1), not from a newly performed experiment. **For coauthor review and adversarial-test validation; NOT an independently proved correctness guarantee.**

## State key families (from chaincode)

- `CONFIG~GEOKHEWAT`: immutable strategy, roles, precision, `eps` etc.
- `PARCEL~id`: parcel ring, active/inactive state, version, predecessors, successors, tolerance flag.
- `KHEWAT~id`: exact fractional co-ownership record.
- `CLAIM~p<P>~<cell>`: claim-scoped index with `[id,version]` geometry references (GKC/GKCR).
- `GEOM~id~version`: immutable geometry (when a claim is recorded / refreshed).
- `CELL~p<P>~<cell>`: full-footprint GKF baseline.
- `DEED~id`, `INDEX~khewat~id`, `MUTATION~id~txid`; global key for B2.

## Initialization of existing parcels (archived experimental fixture)

```
ADMIN: InitConfig(configuration)  // CONFIG nil-read, write once
FOR each non-overlapping parcel in the initial corpus, in stable order:
    SurveyMSP.RegisterParcel(id, khewat, ring, shares, provenance, [])
    // makes the initial claim C = entire ring because there are no inputs
    // builds CLAIM/GEOM entries when configured strategy is GK-CR/GKC
    // checks and commits each registration separately
```

This was the benchmark initializer (`layerb/bench_cc.js:baseWorld`). For a historical government registry there is **no demonstrated operational import** in the archive. A production import must validate all existing topology and provenance, with rejected-map handling, before declaring the initial state safe.

## Core claim-scoped conflict check (GK-CR)

```
INPUT: op = { ins: source parcels, outs: new parcel polygons, kind }
READ CONFIG; validate caller role, polygon topology and operation-specific invariants
ORIGIN := deterministic reference point derived from first output ring
FOR EACH output N:
    C := N \ union(input rings)           // exact rational claimArea2
    retain C only if positive area
cells := conservative geohash cover of all C, with no truncated cell lists
IF cover too large (>256 cells): REJECT
FOR each cell in cells:
    READ CLAIM~p<P>~cell (record absent key as nil-version read)
    FOR each indexed (id,version):
        READ GEOM~id~version
        IF exact positive-area intersection between C and indexed geometry:
            READ PARCEL~id, recursively follow successors of retired parcels
            record currently ACTIVE frontier candidates
IF amalgamation has inherited tolerated-overlap flag:
    additionally read merged-footprint claim-index cells for whole-ring check
FOR EACH output vs currently active candidate not in source/output lineage:
    IF exact overlap > epsilon: REJECT
    IF positive overlap <= epsilon: record tolerance flag
WRITE GEOM record for each new claim-bearing output
WRITE/refresh CLAIM cell references for output claims (GK-CR follows active successors)
WRITE changed parcel/lineage/mutation records in the same endorsed transaction
```

**When `C` is empty:** the implementation does **not** read claim cells. This is an important explicit limitation/assumption, not a hidden candidate discovery step: no newly occupied area should be introduced by a contained partition or inward rectification. Safety relies on an initially valid active map and on operation-specific containment/sibling rules. An amalgamation with an inherited tolerance flag triggers a special merged-footprint read even when its new claim is empty. This needs adversarial tests.

## Successor traversal

```
frontier(id, depth=0):
    IF depth > 64: REJECT
    READ PARCEL~id; IF missing: REJECT
    IF ACTIVE: return [parcel]
    FOR successor in parcel.successors:
        concatenate frontier(successor, depth+1)
    return unique active descendants
```

The lineage is only as safe as immutable, valid successor links and deterministic child-ID transitions. For repeated retirements the path must remain resolvable. Test depths 1, 2, 3, 64, 65, and cycles (explicitly reject or prevent).

## CompactCell (GK-CR only)

```
require SurveyMSP or admin; validate cell length == configured precision
READ CLAIM~p<P>~cell
FOR each indexed id:
    frontier := recursively READ active successors (PARCEL keys)
    retain those whose current ring intersects the cell
    WRITE GEOM~activeId~activeVersion for each retained active frontier element
SORT unique [activeId,activeVersion] pairs
WRITE CLAIM~p<P>~cell as refreshed entry list
```

`CompactCell` is a normal Fabric transaction, not an out-of-band database cleanup. Reads of the `CLAIM` and `PARCEL` keys, and writes of `CLAIM`/`GEOM` keys, enter Fabric validation. Concurrent compaction and a registration sharing a claim-cell key are intended to collide through MVCC; this must be demonstrated in executed schedules.

## Operation-specific read/write overview (key-family level; generate exact logged keys next)

| Operation | Core reads | Core writes |
|---|---|---|
| RegisterParcel | CONFIG, nil PARCEL, CLAIM/GEOM and frontier candidates, KHEWAT (may be absent) | CLAIM, GEOM, PARCEL, KHEWAT if new, INDEX, MUTATION |
| RectifyBoundary | CONFIG, active PARCEL, CLAIM/GEOM/frontiers for newly claimed land | CLAIM, GEOM if claim nonempty; updated PARCEL, MUTATION |
| PartitionParcel | CONFIG, active parent PARCEL, nil reads for child IDs, local geometry rules, CLAIM/GEOM if any new claims, KHEWAT | inactive parent PARCEL successor list; child PARCEL, KHEWAT if new, INDEX, MUTATION; CLAIM/GEOM as applicable |
| AmalgamateParcels | CONFIG, nil merged ID, active source PARCELs, KHEWAT, CLAIM/GEOM/frontiers, possibly whole-footprint index due to tolerated overlap | inactive sources + successor links, merged PARCEL, INDEX, MUTATION; CLAIM/GEOM if applicable |
| TransferShare | CONFIG, DEED, KHEWAT | updated DEED, KHEWAT, MUTATION; **no spatial claim** |
| CompactCell | CONFIG, CLAIM, indexed PARCEL ancestry/frontiers | refreshed CLAIM and GEOM |

Note that `readObj` on an absent key records the nil-version read; the actual Fabric read/write set is conditional on the operation, claim geometry, prior index state, and chosen strategy. Thus the table is a readable *key-family description*, **not yet a complete per-transaction concrete key trace**. Reviewer 1 requests the latter and it should be generated automatically from instrumented test cases.

## Explicit unverified proof obligations

1. Given a validated initial state, every future newly occupied region has a complete geohash cover (including long projected-straight edges and cell-boundary touches); no region is silently omitted under clipping, densification, cap or tolerance.
2. Every intersecting claim can discover a relevant indexed historical geometry or its active descendant, even after repeated partition/amalgamation and reuse of released land.
3. Any competing pair that would create a newly occupied overlap has at least one common versioned CLAIM key (read and write as appropriate), so both cannot commit against a stale snapshot.
4. CompactCell cannot remove a still-needed frontier reference during overlapping enrollment. Its reads/writes must cause MVCC invalidation as required.
5. Operations with an empty claim cannot introduce an overlap despite omitting claim-index reads; verify partitions, inward rectification and tolerance-flag amalgamations.
6. Deterministic polygon/BigInt computation, canonical JSON serialization, stable configuration and identity checks are consistent across endorsers.

## Minimum adversarial schedules to execute next

- Two overlapping registrations endorsed on one shared snapshot, different transaction order.
- Retire A -> partition to B,C -> retire B into D,E -> register into a released region where stale A entries remain.
- Repeated amalgamate after tolerated positive-area contact, with empty/new claim branches.
- Register R into a previously released strip concurrent with CompactCell of the corresponding CLAIM key.
- Two CompactCell operations on same cell; CompactCell concurrent with parcel retirement and with a distinct disjoint registration.
- A near-cell-boundary 10 m densification edge; diagonal rational-coordinate sliver; cover cap 256 vs 257.
- Zero-new-claim share transfer, contained partition, inward rectification; no spurious external topology conflict.

**Use exact source version + SHA-256 (from archival manifest) in each resulting test record. All schedules above are proposed tests, not executed outcomes in this package.**
