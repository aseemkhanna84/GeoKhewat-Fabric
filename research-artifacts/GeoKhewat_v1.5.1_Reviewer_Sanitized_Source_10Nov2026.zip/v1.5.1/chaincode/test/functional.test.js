'use strict';
/* The eleven-step functional suite of the deployed workflow (run 37023120473), adapted to
 * v1.4.0 (roles and a registered deed for the share transfer), plus the MVCC probe. */
const test = require('node:test');
const assert = require('node:assert/strict');
const { fresh, ID, SH1 } = require('./support/world');

const RING1 = [[75.5000, 31.0000], [75.5010, 31.0000], [75.5010, 31.0010], [75.5000, 31.0010], [75.5000, 31.0000]];
const RING2 = [[75.5010, 31.0000], [75.5020, 31.0000], [75.5020, 31.0010], [75.5010, 31.0010], [75.5010, 31.0000]];
const RING3 = [[75.5002, 31.0002], [75.5008, 31.0002], [75.5008, 31.0008], [75.5002, 31.0008], [75.5002, 31.0002]];
const RING1_RECT = [[75.500005, 31.0000], [75.5010, 31.0000], [75.5010, 31.0010], [75.500005, 31.0010], [75.500005, 31.0000]];
const RING1_TOO_BIG = [[75.4990, 30.9990], [75.5020, 30.9990], [75.5020, 31.0020], [75.4990, 31.0020], [75.4990, 30.9990]];
const BOWTIE = [[75.5100, 31.0000], [75.5110, 31.0010], [75.5100, 31.0010], [75.5110, 31.0000], [75.5100, 31.0000]];
const J = JSON.stringify;

for (const strategy of ['GKCR', 'GKC', 'GKF']) {
  test(`functional suite 11/11 and MVCC probe (${strategy})`, async () => {
    const S = await fresh(strategy);
    const t = {};
    const smoke = await S.q('QueryParcel', ['P000']);
    t.smoke = !smoke.ok && /not found/.test(smoke.error);
    t.register_P001 = (await S.reg('P001', RING1, 'K001')).ok;
    t.query_P001 = /P001/.test((await S.q('QueryParcel', ['P001'])).out || '');
    t.shared_boundary_P002 = (await S.reg('P002', RING2, 'K002')).ok;
    t.query_P002 = /P002/.test((await S.q('QueryParcel', ['P002'])).out || '');
    const r3 = await S.reg('P003', RING3, 'K003');
    t.overlap_P003_rejected = !r3.ok && /overlap|meets/i.test(r3.error);
    const q3 = await S.q('QueryParcel', ['P003']);
    t.P003_absent_after_rejection = !q3.ok && /not found/.test(q3.error);
    t.rectify_P001_within_2pct = (await S.rect('P001', RING1_RECT)).ok;
    t.P001_version_increment = JSON.parse((await S.q('QueryParcel', ['P001'])).out).version === 2;
    const big = await S.rect('P001', RING1_TOO_BIG);
    t.rectify_over_2pct_rejected = !big.ok && /2% area bound/.test(big.error);
    const bow = await S.reg('P004', BOWTIE, 'K004');
    t.self_intersection_rejected = !bow.ok && /self-intersecting/.test(bow.error);
    await S.inv('RecordDeed', ['D-K001-1', 'K001', 'O1', 'O2', '1', '2'], ID.registration);
    t.transfer_share_K001 = (await S.inv('TransferShare', ['K001', 'O1', 'O2', '1', '2', 'D-K001-1'], ID.revenue)).ok;
    for (const [k, v] of Object.entries(t)) assert.equal(v, true, k);
    assert.equal(Object.keys(t).length, 12);    // smoke + 11 functional checks
    // MVCC probe: two transfers on K001 endorsed against the same state, committed in one block
    await S.inv('RecordDeed', ['D-a', 'K001', 'O1', 'O3', '1', '4'], ID.registration);
    await S.inv('RecordDeed', ['D-b', 'K001', 'O1', 'O4', '1', '4'], ID.registration);
    const a = await S.end('TransferShare', ['K001', 'O1', 'O3', '1', '4', 'D-a'], ID.revenue);
    const b = await S.end('TransferShare', ['K001', 'O1', 'O4', '1', '4', 'D-b'], ID.revenue);
    assert.deepEqual(S.commit([a, b]), ['VALID', 'MVCC_READ_CONFLICT']);
  });
}
