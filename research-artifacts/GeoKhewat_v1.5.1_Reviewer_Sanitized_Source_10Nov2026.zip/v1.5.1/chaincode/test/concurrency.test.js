'use strict';
/* Hostile interleavings: transactions endorsed against the same committed state and
 * committed in one block, in both orders. After every block no pair of active parcels may
 * overlap by more than eps (GKCR, GKF) or at all (GKC). */
const test = require('node:test');
const assert = require('node:assert/strict');
const { fresh, SH1, G, Contract } = require('./support/world');
const { rect, ringLL } = G;
const J = JSON.stringify;
const ok = r => assert.equal(r.ok, true, r.error || r.code);
const STRATS = ['GKCR', 'GKC', 'GKF'];
const bound = s => (s === 'GKC' ? 1e-9 : 0.01 + 1e-9);
const kid = (k, r) => ({ khasra: k, ring: r, shares: JSON.parse(SH1) });

async function pair(s, setup, mk, cover = 'poly') {
  const res = [];
  for (const order of [0, 1]) {
    const S = await fresh(s, { cover });
    await setup(S);
    const txs = await mk(S);
    const codes = S.commit(order ? txs.slice().reverse() : txs);
    res.push({ codes: order ? codes.slice().reverse() : codes, overlap: G.maxPairOverlap(S.w).area });
  }
  return res;
}

for (const s of STRATS) {
  test(`facing claims into one gap: one invalidated, no overlap (${s})`, async () => {
    const r = await pair(s, async S => { ok(await S.reg('A', rect(0, 0, 60, 40))); ok(await S.reg('B', rect(61.4, 0, 60, 40))); },
      async S => [await S.end('RectifyBoundary', ['A', J(rect(0, 0, 60.9, 40)), 'S', '[]']),
        await S.end('RectifyBoundary', ['B', J(rect(60.5, 0, 60.9, 40)), 'S', '[]'])]);
    for (const x of r) { assert.equal(x.codes.filter(c => c === 'VALID').length, 1, J(x)); assert.ok(x.overlap <= bound(s)); }
  });
  test(`phantom: strip registered into a gap while a neighbour claims it (${s})`, async () => {
    const r = await pair(s, async S => { ok(await S.reg('A', rect(0, 0, 60, 40))); ok(await S.reg('B', rect(61.4, 0, 60, 40))); },
      async S => [await S.end('RegisterParcel', ['S', 'KS', J(rect(60, 0, 1.4, 40)), SH1, 'S', '[]']),
        await S.end('RectifyBoundary', ['A', J(rect(0, 0, 60.9, 40)), 'S', '[]'])]);
    for (const x of r) { assert.equal(x.codes.filter(c => c === 'VALID').length, 1, J(x)); assert.ok(x.overlap <= bound(s)); }
  });
  test(`partition beside a neighbour's outward claim: both commit under claim scoping (${s})`, async () => {
    const r = await pair(s, async S => { ok(await S.reg('P', rect(0, 0, 60, 40))); ok(await S.reg('Q', rect(60, 0, 60, 40))); },
      async S => [await S.end('PartitionParcel', ['P', J([kid('P1', rect(0, 0, 30, 40)), kid('P2', rect(30, 0, 30, 40))]), '[]']),
        await S.end('RectifyBoundary', ['Q', J(rect(60, 0, 60.9, 40)), 'S', '[]'])]);
    for (const x of r) {
      assert.ok(x.overlap <= bound(s));
      if (s === 'GKF') assert.equal(x.codes.filter(c => c === 'VALID').length, 1, J(x));
      else assert.deepEqual(x.codes, ['VALID', 'VALID']);
    }
  });
}
test('GKCR: re-claim race on released land: one invalidated', async () => {
  const r = await pair('GKCR', async S => { ok(await S.reg('A', rect(0, 0, 60, 40))); ok(await S.reg('B', rect(60, 0, 60, 40))); ok(await S.rect('A', rect(0, 0, 59.2, 40))); },
    async S => [await S.end('RectifyBoundary', ['B', J(ringLL([[59.2, 0], [120, 0], [120, 40], [59.2, 40]])), 'S', '[]']),
      await S.end('RectifyBoundary', ['A', J(rect(0, 0, 60, 40)), 'S', '[]'])]);
  for (const x of r) { assert.equal(x.codes.filter(c => c === 'VALID').length, 1, J(x)); assert.ok(x.overlap <= 0.01); }
});
test('GKCR: a claim resolved against a live parcel is invalidated if that parcel changes first', async () => {
  const r = await pair('GKCR', async S => { ok(await S.reg('A', rect(0, 0, 60, 40))); ok(await S.reg('B', rect(60, 0, 60, 40))); ok(await S.rect('A', rect(0, 0, 59.2, 40))); },
    async S => [await S.end('RectifyBoundary', ['B', J(ringLL([[59.2, 0], [120, 0], [120, 40], [59.2, 40]])), 'S', '[]']),
      await S.end('PartitionParcel', ['A', J([kid('A1', rect(0, 0, 29.6, 40)), kid('A2', rect(29.6, 0, 29.6, 40))]), '[]'])]);
  // claim first: both valid (the partition stays inside A's live ring); partition first:
  // the claim read PARCEL~A at a superseded version and is invalidated
  assert.deepEqual(r[0].codes, ['VALID', 'VALID']);
  assert.deepEqual(r[1].codes, ['MVCC_READ_CONFLICT', 'VALID']);
  for (const x of r) assert.ok(x.overlap <= 0.01);
});
test('GKCR: CompactCell races a claim in the same cell; index stays complete', async () => {
  const S0 = await fresh('GKCR');
  ok(await S0.reg('A', rect(0, 0, 60, 40))); ok(await S0.reg('B', rect(60, 0, 60, 40))); ok(await S0.rect('A', rect(0, 0, 59.2, 40)));
  const cell = [...S0.w.state.keys()].filter(k => k.startsWith('CLAIM~')).map(k => k.split('~')[2])
    .find(g => Contract._internal.ringMeetsCellLL(rect(59.2, 0, 0.8, 40), g));
  const r = await pair('GKCR', async S => { ok(await S.reg('A', rect(0, 0, 60, 40))); ok(await S.reg('B', rect(60, 0, 60, 40))); ok(await S.rect('A', rect(0, 0, 59.2, 40))); },
    async S => [await S.end('CompactCell', [cell]), await S.end('RectifyBoundary', ['B', J(ringLL([[59.2, 0], [120, 0], [120, 40], [59.2, 40]])), 'S', '[]'])]);
  for (const x of r) assert.equal(x.codes.filter(c => c === 'VALID').length, 1, J(x));
});
test('GKCR: amalgamation reads its footprint and conflicts with a claim inside it', async () => {
  const r = await pair('GKCR', async S => {
    ok(await S.reg('A', rect(0, 0, 30, 40), 'K1')); ok(await S.reg('B', rect(30, 0, 30, 40), 'K1')); ok(await S.reg('C', rect(0, 41, 60, 40), 'K2'));
  }, async S => [await S.end('AmalgamateParcels', ['A', 'B', 'M', J(rect(0, 0, 60, 40)), '', '[]']),
    await S.end('RectifyBoundary', ['C', J(rect(0, 40.5, 60, 40.5)), 'S', '[]'])]);
  for (const x of r) assert.ok(x.overlap <= 0.01);
});
test('GKCR: a tolerated overlap created concurrently with an amalgamation conflicts with it', async () => {
  const Qring = ringLL([[0, 80], [0, 40.5], [10, 40.5], [10.05, 39.88], [10.1, 40.5], [40, 40.5], [40.05, 39.88], [40.1, 40.5], [60, 40.5], [60, 80]]);
  const r = await pair('GKCR', async S => {
    ok(await S.reg('A', rect(0, 0, 30, 40), 'K1')); ok(await S.reg('B', rect(30, 0, 30, 40), 'K1')); ok(await S.reg('Q', rect(0, 40.5, 60, 39.5), 'K2'));
  }, async S => [await S.end('AmalgamateParcels', ['A', 'B', 'M', J(rect(0, 0, 60, 40)), '', '[]']),
    await S.end('RectifyBoundary', ['Q', J(Qring), 'S', '[]'])]);
  for (const x of r) { assert.equal(x.codes.filter(c => c === 'VALID').length, 1, J(x)); assert.ok(x.overlap <= 0.01); }
});
