'use strict';
/* Property-based test: random blocks of concurrently endorsed operations (registration,
 * outward and inward rectification, partition, amalgamation, compaction) on a 5 x 4 grid,
 * four seeds per configuration. After every block: no pair of active parcels overlaps by
 * more than eps; every tenth block and at the end: QueryByCell equals a brute-force scan
 * for every indexed cell and every cell meeting an active parcel. Writes
 * out/property_results.json. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { fresh, SH1, G, Contract } = require('./support/world');
const I = Contract._internal;
const J = JSON.stringify;

const BLOCKS = Number(process.env.GK_PROP_BLOCKS || 50);
const SEEDS = (process.env.GK_PROP_SEEDS || '1,2,3,4').split(',').map(Number);
const CONFIGS = [['GKCR', 'poly'], ['GKCR', 'bbox'], ['GKC', 'poly'], ['GKF', 'poly']];
const local = ring => ring.slice(0, -1).map(p => { const [x, y] = G.utm(p); return [x - G.X0, y - G.Y0]; });
function boxOf(ring) { const l = local(ring); const xs = l.map(v => v[0]), ys = l.map(v => v[1]); return { x0: Math.min(...xs), y0: Math.min(...ys), x1: Math.max(...xs), y1: Math.max(...ys) }; }
const R = (b) => G.rect(b.x0, b.y0, b.x1 - b.x0, b.y1 - b.y0);
const r3 = v => Math.round(v * 1000) / 1000;

async function runOne(strategy, cover, seed) {
  const rnd = G.rng(seed * 7919 + strategy.length * 31 + (cover === 'bbox' ? 1 : 0));
  const S = await fresh(strategy, { cover });
  for (let row = 0; row < 4; row++) for (let col = 0; col < 5; col++) {
    const r = await S.reg(`R${row}C${col}`, G.rect(col * 30, row * 42, 30, 40), `K${row}`);
    assert.equal(r.ok, true, r.error);
  }
  let nextId = 0;
  const stats = { strategy, cover, seed, blocks: BLOCKS, proposed: 0, endorse_refused: 0, valid: 0, mvcc: 0, phantom: 0, max_overlap_m2: 0, query_checks: 0, query_mismatches: 0, ops: {} };
  const active = () => G.activeParcels(S.w);
  const pick = a => a[Math.floor(rnd() * a.length)];
  async function propose() {
    const ps = active();
    const p = pick(ps); const b = boxOf(p.ring);
    const kind = pick(['out', 'out', 'in', 'in', 'part', 'amal', 'reg', ...(strategy === 'GKCR' ? ['compact'] : [])]);
    stats.ops[kind] = (stats.ops[kind] || 0) + 1;
    if (kind === 'out' || kind === 'in') {
      const e = pick(['W', 'E', 'S', 'N']); const w = b.x1 - b.x0, h = b.y1 - b.y0;
      const d = r3((0.1 + 0.4 * rnd()) * Math.min(1, Math.min(w, h) / 30)) * (kind === 'out' ? 1 : -1);
      const nb = { ...b };
      if (e === 'W') nb.x0 -= d; if (e === 'E') nb.x1 += d; if (e === 'S') nb.y0 -= d; if (e === 'N') nb.y1 += d;
      return S.end('RectifyBoundary', [p.id, J(R(nb)), 'S', '[]']);
    }
    if (kind === 'part') {
      const w = b.x1 - b.x0, h = b.y1 - b.y0; const f = r3(0.3 + 0.4 * rnd());
      const k1 = `N${seed}_${nextId++}`, k2 = `N${seed}_${nextId++}`;
      const [c1, c2] = w >= h ? [{ ...b, x1: r3(b.x0 + w * f) }, { ...b, x0: r3(b.x0 + w * f) }] : [{ ...b, y1: r3(b.y0 + h * f) }, { ...b, y0: r3(b.y0 + h * f) }];
      return S.end('PartitionParcel', [p.id, J([{ khasra: k1, ring: R(c1), shares: JSON.parse(SH1) }, { khasra: k2, ring: R(c2), shares: JSON.parse(SH1) }]), '[]']);
    }
    if (kind === 'amal') {
      const q = ps.find(o => { const c = boxOf(o.ring); return o.id !== p.id && o.khewat === p.khewat && Math.abs(c.y0 - b.y0) < 1e-3 && Math.abs(c.y1 - b.y1) < 1e-3 && (Math.abs(c.x0 - b.x1) < 1e-3 || Math.abs(c.x1 - b.x0) < 1e-3); });
      if (!q) return S.end('QueryParcel', [p.id]);
      const c = boxOf(q.ring);
      return S.end('AmalgamateParcels', [p.id, q.id, `N${seed}_${nextId++}`, J(R({ x0: Math.min(b.x0, c.x0), y0: b.y0, x1: Math.max(b.x1, c.x1), y1: b.y1 })), '', '[]']);
    }
    if (kind === 'reg') {
      const x = r3(-5 + rnd() * 155), y = r3(-5 + rnd() * 170), w = r3(4 + rnd() * 10), h = r3(4 + rnd() * 10);
      return S.end('RegisterParcel', [`N${seed}_${nextId++}`, `KR${seed}`, J(G.rect(x, y, w, h)), SH1, 'S', '[]']);
    }
    const cells = [...S.w.state.keys()].filter(k => k.startsWith('CLAIM~')).map(k => k.split('~')[2]);
    return S.end('CompactCell', [pick(cells)]);
  }
  async function checkQueries() {
    const fam = strategy === 'GKF' ? 'CELL~' : 'CLAIM~';
    const cells = new Set([...S.w.state.keys()].filter(k => k.startsWith(fam)).map(k => k.split('~')[2]));
    const ps = active();
    for (const p of ps) for (const g of I.cellsOf([I.mmPath(p.ring, I.originOf(p.ring.slice(0, -1)))], I.originOf(p.ring.slice(0, -1)), 8, 'poly')) cells.add(g);
    for (const g of cells) {
      const got = JSON.parse((await S.q('QueryByCell', [g])).out).map(x => x.id).sort();
      const want = ps.filter(p => I.ringMeetsCellLL(p.ring, g)).map(p => p.id).sort();
      stats.query_checks += 1;
      if (J(got) !== J(want)) stats.query_mismatches += 1;
    }
  }
  for (let blk = 0; blk < BLOCKS; blk++) {
    const k = 1 + Math.floor(rnd() * 6);
    const txs = [];
    for (let i = 0; i < k; i++) txs.push(await propose());
    stats.proposed += txs.filter(t => t.fn !== 'QueryParcel').length;
    const codes = S.commit(txs.filter(t => t.fn !== 'QueryParcel'));
    for (const c of codes) {
      if (c === 'VALID') stats.valid += 1; else if (c === 'MVCC_READ_CONFLICT') stats.mvcc += 1;
      else if (c === 'PHANTOM_READ_CONFLICT') stats.phantom += 1; else stats.endorse_refused += 1;
    }
    const ov = G.maxPairOverlap(S.w).area;
    stats.max_overlap_m2 = Math.max(stats.max_overlap_m2, ov);
    assert.ok(ov <= 0.01 + 1e-9, `${strategy}/${cover}/seed ${seed} block ${blk}: overlap ${ov}`);
    if (blk % 10 === 9) await checkQueries();
  }
  await checkQueries();
  stats.active_parcels = active().length;
  stats.claim_entries = [...S.w.state.entries()].filter(([k]) => k.startsWith('CLAIM~')).reduce((a, [, v]) => a + JSON.parse(v.value.toString()).entries.length, 0);
  stats.geom_records = [...S.w.state.keys()].filter(k => k.startsWith('GEOM~')).length;
  return stats;
}

test('property: random concurrent blocks keep pairwise overlap <= eps and QueryByCell exact', async () => {
  const all = [];
  for (const [s, cover] of CONFIGS) for (const seed of SEEDS) {
    const st = await runOne(s, cover, seed);
    all.push(st);
    assert.equal(st.query_mismatches, 0, J(st));
  }
  fs.mkdirSync(path.join(__dirname, '..', 'out'), { recursive: true });
  fs.writeFileSync(path.join(__dirname, '..', 'out', 'property_results.json'), JSON.stringify({ timestamp_utc: new Date().toISOString(), node: process.version, cc_version: require('../lib/geokhewat-contract.js')._internal.VERSION, runs: all }, null, 1));
});
