'use strict';
/* Lemma-1 implementation gap in v1.3.0: covers are bounding boxes of the vertices in
 * lon/lat, but parcel edges are straight in UTM 43N. A long UTM-straight edge bows out
 * of the lon/lat bounding box of its end points; if a geohash row boundary falls inside
 * the bow, a cell that the parcel's interior enters is missing from its cover. */
const proj4 = require('proj4');
proj4.defs('EPSG:32643', '+proj=utm +zone=43 +datum=WGS84 +units=m +no_defs');
const ll = p => proj4('EPSG:32643', 'EPSG:4326', p), utm = p => proj4('EPSG:4326', 'EPSG:32643', p);
const dlat8 = 180 / 2 ** 20;
function northEdge(x0, y0, L, th) { // returns lat at start, mid, end of the north edge of a strip
  const a = [x0, y0], b = [x0 + L * Math.cos(th), y0 + L * Math.sin(th)];
  const pts = []; for (let t = 0; t <= 1.0001; t += 0.01) pts.push(ll([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]));
  return { a, b, lats: pts.map(p => p[1]) };
}
const res = {};
if (require.main === module) for (const x0 of [499250, 520000, 600000]) {
  // find th so the two end points of a 1500 m edge share a latitude
  let lo = -0.05, hi = 0.05;
  const f = th => { const e = northEdge(x0, 3450000, 1500, th); return e.lats[e.lats.length - 1] - e.lats[0]; };
  for (let i = 0; i < 80; i++) { const m = (lo + hi) / 2; if (Math.sign(f(m)) === Math.sign(f(lo))) lo = m; else hi = m; }
  const th = (lo + hi) / 2, e = northEdge(x0, 3450000, 1500, th);
  const bow = (Math.max(...e.lats) - Math.max(e.lats[0], e.lats[e.lats.length - 1])) * 110900;
  res[x0] = { theta_deg: th * 180 / Math.PI, bow_north_m: bow, bow_south_m: (Math.min(e.lats[0], e.lats.at(-1)) - Math.min(...e.lats)) * 110900 };
}
if (require.main === module) console.log(JSON.stringify(res, null, 1));

/* construct the counterexample and run it on a chaincode (exported for the audits) */
function construct() {
  const x0 = 600000, L = 1500, W = 8;
  const Lb = Math.ceil((31.1 + 90) / dlat8) * dlat8 - 90;          // a precision-8 row boundary
  let y = 3450000, th = 0;
  for (let round = 0; round < 4; round++) {
    for (let i = 0; i < 30; i++) { const lat = ll([x0, y])[1]; y += (Lb - 5e-8 - lat) * 110900; }
    let lo = -0.05, hi = 0.05;
    const f = t => { const e = northEdge(x0, y, L, t); return e.lats[e.lats.length - 1] - e.lats[0]; };
    for (let i = 0; i < 80; i++) { const m = (lo + hi) / 2; if (Math.sign(f(m)) === Math.sign(f(lo))) lo = m; else hi = m; }
    th = (lo + hi) / 2;
  }
  // north edge P->Q; strip lies south of it
  const P = [x0, y], Q = [x0 + L * Math.cos(th), y + L * Math.sin(th)];
  const nrm = [Math.sin(th), -Math.cos(th)];
  const A = [P, Q, [Q[0] + W * nrm[0], Q[1] + W * nrm[1]], [P[0] + W * nrm[0], P[1] + W * nrm[1]]].map(ll);
  A.push([...A[0]]);
  const mid = ll([(P[0] + Q[0]) / 2, (P[1] + Q[1]) / 2]);
  const lat0 = Lb + 2e-8, lat1 = lat0 + 9e-5, lo0 = mid[0] - 2e-4, lo1 = mid[0] + 2e-4;
  const B = [[lo0, lat0], [lo1, lat0], [lo1, lat1], [lo0, lat1], [lo0, lat0]];
  return { A, B, row_boundary_lat: Lb, end_lat_A: ll(P)[1] };
}
module.exports = { construct };
if (require.main === module) {
  const { World, invoke } = require('./fabric_stub');
  const G = require('./geo_util');
  const C = require('../../lib/geokhewat-contract.js');
  (async () => {
    const k = construct();
    console.log('overlap A/B (exact, m2):', G.overlapM2(k.A, k.B).toFixed(3), 'area A', G.areaM2(k.A).toFixed(0));
    for (const s of ['GKC', 'GK']) {
      const w = new World(), c = new C();
      await invoke(w, c, 'SetStrategy', [s, '8']);
      const rb = await invoke(w, c, 'RegisterParcel', ['B', 'KB', JSON.stringify(k.B), '[{"owner":"O1","num":"1","den":"1"}]', 'SYN', '[]']);
      const ra = await invoke(w, c, 'RegisterParcel', ['A', 'KA', JSON.stringify(k.A), '[{"owner":"O1","num":"1","den":"1"}]', 'SYN', '["B"]']);
      console.log(s, 'B', rb.ok ? 'ok' : rb.error, '| A', ra.ok ? 'accepted' : ra.error, '| committed overlap', G.maxPairOverlap(w).area.toFixed(3));
    }
  })();
}
