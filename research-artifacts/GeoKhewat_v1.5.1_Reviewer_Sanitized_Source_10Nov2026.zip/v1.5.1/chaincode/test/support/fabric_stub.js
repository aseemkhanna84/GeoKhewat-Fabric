'use strict';
/*
 * In-memory stand-in for a Fabric peer, used to execute GeoKhewat chaincode locally
 * (Layer B'). It is not a Fabric network. It reproduces the parts of Fabric's
 * transaction semantics that decide what the chaincode can and cannot see:
 *
 *   - GetState returns committed state only. A transaction does not see its own
 *     pending writes ("read-your-writes semantics are not supported").
 *   - Every key read is recorded with the version it had; an absent key is recorded
 *     with a nil version.
 *   - Writes are buffered in the write set; the last write to a key wins.
 *   - GetStateByRange results are recorded and re-executed at validation
 *     (phantom-read protection for range queries).
 *   - At commit, transactions of a block are validated in order. A transaction is
 *     invalidated with MVCC_READ_CONFLICT if any key in its read set changed version,
 *     including a nil-version key that has since been created, and with
 *     PHANTOM_READ_CONFLICT if a range query's result changed. Only written keys
 *     change version.
 *
 * Endorsement is simulated by running the contract function once against committed
 * state; the endorsement policy, identities, ordering and the state database are not
 * modelled.
 */

class World {
  constructor() {
    this.state = new Map();          // key -> { value: Buffer, ver: string }
    this.block = 0;
  }
  snapshotKeys(start, end) {
    return [...this.state.keys()].filter(k => k >= start && k < end).sort();
  }
}

class Stub {
  constructor(world, txid, identity) {
    this.identity = identity || null;
    this.w = world;
    this.txid = txid;
    this.reads = new Map();          // key -> version or null
    this.writes = new Map();         // key -> Buffer
    this.ranges = [];
  }
  getTxID() { return this.txid; }
  getChannelID() { return 'landrecords'; }
  async getState(key) {
    const e = this.w.state.get(key);
    if (!this.reads.has(key)) this.reads.set(key, e ? e.ver : null);
    return e ? Buffer.from(e.value) : Buffer.alloc(0);
  }
  async putState(key, value) { this.writes.set(key, Buffer.from(value)); }
  async deleteState(key) { this.writes.set(key, null); }
  async getStateByRange(start, end) {
    const keys = this.w.snapshotKeys(start, end);
    const rec = keys.map(k => [k, this.w.state.get(k).ver]);
    this.ranges.push({ start, end, rec });
    const items = keys.map(k => ({ key: k, value: Buffer.from(this.w.state.get(k).value) }));
    /* v10: like fabric-shim's StateQueryIterator, expose next()/close() (the shim's
     * iterator is not async-iterable once awaited); the async iterator is kept */
    let pos = 0;
    return {
      next: async () => (pos < items.length ? { value: items[pos++], done: false } : { value: undefined, done: true }),
      [Symbol.asyncIterator]() {
        let i = 0;
        return { next: async () => (i < items.length ? { value: items[i++], done: false }
                                                      : { value: undefined, done: true }) };
      },
      close: async () => {},
    };
  }
}

let TXN = 0;

/* v10: an optional client identity {msp, id} is exposed as ctx.clientIdentity with the
 * two fabric-shim ClientIdentity methods the chaincode uses (getMSPID, getID). */
function makeIdentity(identity) {
  if (!identity) return null;
  return { getMSPID: () => identity.msp, getID: () => identity.id || `x509::/OU=client/CN=user@${identity.msp}::/CN=ca.${identity.msp}` };
}
async function endorse(world, contract, fn, args, identity) {
  const stub = new Stub(world, `tx${++TXN}`, identity);
  const ctx = { stub, clientIdentity: makeIdentity(identity) };
  try {
    const out = await contract[fn](ctx, ...args);
    return { ok: true, out, stub, fn };
  } catch (e) {
    return { ok: false, error: String(e && e.message || e), stub, fn };
  }
}

function commitBlock(world, endorsed) {
  world.block += 1;
  const codes = [];
  let n = 0;
  for (const tx of endorsed) {
    if (!tx.ok) { codes.push('ENDORSEMENT_FAILURE'); continue; }
    let code = 'VALID';
    for (const [k, ver] of tx.stub.reads) {
      const cur = world.state.get(k);
      const cv = cur ? cur.ver : null;
      if (cv !== ver) { code = 'MVCC_READ_CONFLICT'; break; }
    }
    if (code === 'VALID') {
      for (const r of tx.stub.ranges) {
        const now = world.snapshotKeys(r.start, r.end).map(k => [k, world.state.get(k).ver]);
        if (JSON.stringify(now) !== JSON.stringify(r.rec)) { code = 'PHANTOM_READ_CONFLICT'; break; }
      }
    }
    if (code === 'VALID') {
      n += 1;
      for (const [k, v] of tx.stub.writes) {
        if (v === null) world.state.delete(k);
        else world.state.set(k, { value: v, ver: `${world.block}:${n}` });
      }
    }
    codes.push(code);
  }
  return codes;
}

/* invoke = endorse + commit in a block of its own; query = endorse only */
async function invoke(world, contract, fn, args, identity) {
  const e = await endorse(world, contract, fn, args, identity);
  const [code] = commitBlock(world, [e]);
  return { ok: e.ok && code === 'VALID', code, out: e.out, error: e.error };
}

async function query(world, contract, fn, args, identity) {
  const e = await endorse(world, contract, fn, args, identity);
  return { ok: e.ok, out: e.out, error: e.error };
}

module.exports = { World, Stub, endorse, commitBlock, invoke, query };
