'use strict';
/* Test fixtures: a Layer B' stub world with GeoKhewat v1.4.0 initialised for one strategy. */
const { World, endorse, commitBlock, invoke, query } = require('./fabric_stub');
const G = require('./geo_util');
const Contract = require('../../lib/geokhewat-contract.js');

const ID = {
  admin: { msp: 'SurveyMSP', id: 'x509::/OU=admin/CN=Admin@survey.example.com::/CN=ca.survey.example.com' },
  survey: { msp: 'SurveyMSP' },
  registration: { msp: 'RegistrationMSP' },
  revenue: { msp: 'RevenueMSP' },
  outsider: { msp: 'OutsiderMSP' },
};
const ROLES = { admin: ['SurveyMSP'], survey: ['SurveyMSP'], registration: ['RegistrationMSP'], revenue: ['RevenueMSP'] };
const SH1 = '[{"owner":"O1","num":"1","den":"1"}]';

async function fresh(strategy = 'GKCR', extra = {}) {
  const w = new World(); const c = new Contract();
  const cfg = { strategy, precision: 8, cover: 'poly', eps: 0.01, roles: ROLES, research: ['B1', 'B2', 'B3'].includes(strategy), ...extra };
  const r = await invoke(w, c, 'InitConfig', [JSON.stringify(cfg)], ID.admin);
  if (!r.ok) throw new Error(`InitConfig failed: ${r.error || r.code}`);
  const S = {
    w, c,
    inv: (fn, args, who = ID.survey) => invoke(w, c, fn, args, who),
    q: (fn, args, who = ID.survey) => query(w, c, fn, args, who),
    end: (fn, args, who = ID.survey) => endorse(w, c, fn, args, who),
    commit: txs => commitBlock(w, txs),
    reg: (id, ring, kh = `K${id}`, sh = SH1, nb = '[]') => invoke(w, c, 'RegisterParcel', [id, kh, JSON.stringify(ring), sh, 'SYNTHETIC', nb], ID.survey),
    rect: (id, ring, nb = '[]') => invoke(w, c, 'RectifyBoundary', [id, JSON.stringify(ring), 'SYNTHETIC', nb], ID.survey),
    part: (id, kids, nb = '[]') => invoke(w, c, 'PartitionParcel', [id, JSON.stringify(kids.map(([k, ring]) => ({ khasra: k, ring, shares: JSON.parse(SH1) }))), nb], ID.survey),
    amal: (a, b, n, ring, nb = '[]') => invoke(w, c, 'AmalgamateParcels', [a, b, n, JSON.stringify(ring), '', nb], ID.survey),
    parcel: id => { const e = w.state.get(`PARCEL~${id}`); return e ? JSON.parse(e.value.toString()) : null; },
  };
  return S;
}
module.exports = { fresh, ID, ROLES, SH1, G, Contract, World, endorse, commitBlock, invoke, query };
