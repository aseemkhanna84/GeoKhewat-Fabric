'use strict';
/* Regression tests: every defect demonstrated on v1.3.0 (out/audit_v13.json) replayed on
 * the current version with the corrected expectation, plus T1-T3 for the defects found during the
 * revision (v1.4.1, v1.5.0, v1.5.1). Test names carry the audit probe id. */
const test = require('node:test');
const assert = require('node:assert/strict');
const { fresh, ID, ROLES, SH1, G, Contract, World, invoke } = require('./support/world');
const { rect, ringLL } = G;
const J = JSON.stringify;
const ok = r => assert.equal(r.ok, true, r.error || r.code);
const no = (r, re) => { assert.equal(r.ok, false, 'expected refusal'); if (re) assert.match(r.error || r.code, re); };

test('A1 configuration is immutable: SetStrategy removed, second InitConfig refused', async () => {
  for (const s of ['GKCR', 'GKC', 'GKF']) {
    const S = await fresh(s);
    ok(await S.reg('A', rect(0, 0, 60, 40)));
    no(await S.inv('SetStrategy', ['GK', '8'], ID.admin), /removed/);
    no(await S.inv('InitConfig', [J({ strategy: 'B1', research: true, roles: ROLES })], ID.admin), /immutable/);
    no(await S.reg('B', rect(30, 10, 60, 40)), /overlap|meets/);
    assert.equal(G.maxPairOverlap(S.w).area, 0);
  }
});
test('A1 InitConfig requires an admin identity of an admin MSP', async () => {
  const w = new World(), c = new Contract();
  const cfg = J({ strategy: 'GKCR', roles: ROLES });
  no(await invoke(w, c, 'InitConfig', [cfg], ID.survey), /admin identity/);
  no(await invoke(w, c, 'InitConfig', [cfg], { msp: 'RevenueMSP', id: 'x509::/OU=admin/CN=Admin@rev::/CN=ca' }), /admin identity/);
  no(await invoke(w, c, 'RegisterParcel', ['A', 'K', J(rect(0, 0, 60, 40)), SH1, 'S', '[]'], ID.survey), /not initialised/);
  ok(await invoke(w, c, 'InitConfig', [cfg], ID.admin));
});
test('A1 unsafe baselines need research mode', async () => {
  const w = new World(), c = new Contract();
  no(await invoke(w, c, 'InitConfig', [J({ strategy: 'B1', roles: ROLES })], ID.admin), /research baseline/);
});
test('A1 concurrent InitConfig: one is invalidated on the nil-version read', async () => {
  const w = new World(), c = new Contract();
  const { endorse, commitBlock } = require('./support/fabric_stub');
  const t1 = await endorse(w, c, 'InitConfig', [J({ strategy: 'GKCR', roles: ROLES })], ID.admin);
  const t2 = await endorse(w, c, 'InitConfig', [J({ strategy: 'GKF', roles: ROLES })], ID.admin);
  assert.deepEqual(commitBlock(w, [t1, t2]), ['VALID', 'MVCC_READ_CONFLICT']);
});
test('A2 precision is part of the immutable configuration and of every index key', async () => {
  const S = await fresh('GKCR', { precision: 9 });
  ok(await S.reg('A', rect(0, 0, 60, 40)));
  const keys = [...S.w.state.keys()].filter(k => k.startsWith('CLAIM~'));
  assert.ok(keys.length > 0 && keys.every(k => /^CLAIM~p9~[0-9b-hjkmnp-z]{9}$/.test(k)), keys.join(','));
  no(await S.inv('InitConfig', [J({ strategy: 'GKCR', precision: 8, roles: ROLES })], ID.admin), /immutable/);
});
for (const s of ['GKCR', 'GKC', 'GKF']) {
  test(`A3 identifier reuse refused (${s})`, async () => {
    let S = await fresh(s);
    ok(await S.reg('P', rect(0, 0, 60, 40))); ok(await S.reg('X', rect(200, 0, 60, 40)));
    no(await S.part('P', [['X', rect(0, 0, 30, 40)], ['P2', rect(30, 0, 30, 40)]]), /already exists/);
    no(await S.part('P', [['D', rect(0, 0, 30, 40)], ['D', rect(30, 0, 30, 40)]]), /distinct/);
    no(await S.part('P', [['P', rect(0, 0, 30, 40)], ['Q', rect(30, 0, 30, 40)]]), /parent identifier/);
    ok(await S.part('X', [['X1', rect(200, 0, 30, 40)], ['X2', rect(230, 0, 30, 40)]]));
    no(await S.part('P', [['X', rect(0, 0, 30, 40)], ['P2', rect(30, 0, 30, 40)]]), /already exists/);   // retired id
    S = await fresh(s);
    ok(await S.reg('A', rect(0, 0, 30, 40), 'K1')); ok(await S.reg('B', rect(30, 0, 30, 40), 'K1')); ok(await S.reg('Z', rect(400, 0, 60, 40), 'K2'));
    no(await S.amal('A', 'B', 'Z', rect(0, 0, 60, 40)), /already exists/);
    no(await S.amal('A', 'A', 'M', rect(0, 0, 30, 40)), /two different/);
    no(await S.amal('A', 'B', 'A', rect(0, 0, 60, 40)), /must be new/);
    ok(await S.amal('A', 'B', 'M', rect(0, 0, 60, 40)));
  });
}
test('A3 concurrent creation of one child identifier: one invalidated', async () => {
  const S = await fresh('GKCR');
  ok(await S.reg('P', rect(0, 0, 60, 40))); ok(await S.reg('Q', rect(200, 0, 60, 40)));
  const kid = (k, r) => ({ khasra: k, ring: r, shares: JSON.parse(SH1) });
  const t1 = await S.end('PartitionParcel', ['P', J([kid('X', rect(0, 0, 30, 40)), kid('P2', rect(30, 0, 30, 40))]), '[]']);
  const t2 = await S.end('PartitionParcel', ['Q', J([kid('X', rect(200, 0, 30, 40)), kid('Q2', rect(230, 0, 30, 40))]), '[]']);
  assert.deepEqual(S.commit([t1, t2]), ['VALID', 'MVCC_READ_CONFLICT']);
  const land = G.activeParcels(S.w).reduce((a, p) => a + p.areaM2, 0);
  assert.ok(Math.abs(land - 4800) < 0.01, `land ${land}`);
});
test('A3/B7 amalgamation keeps the Khewat share vector and needs one Khewat', async () => {
  const S = await fresh('GKCR');
  const two = '[{"owner":"O1","num":"1","den":"2"},{"owner":"O2","num":"1","den":"2"}]';
  ok(await S.reg('A', rect(0, 0, 30, 40), 'K1', two)); ok(await S.reg('A2', rect(300, 0, 30, 40), 'K1', two)); ok(await S.reg('B', rect(30, 0, 30, 40), 'K2'));
  no(await S.amal('A', 'B', 'M', rect(0, 0, 60, 40)), /different Khewats/);
  ok(await S.reg('C', rect(-30, 0, 30, 40), 'K1', two));
  no(await S.inv('AmalgamateParcels', ['A', 'C', 'M', J(rect(-30, 0, 60, 40)), '[{"owner":"O9","num":"1","den":"1"}]', '[]']), /cannot change/);
  ok(await S.amal('A', 'C', 'M', rect(-30, 0, 60, 40)));
  const k1 = JSON.parse(S.w.state.get('KHEWAT~K1').value.toString());
  assert.deepEqual(k1.shares.map(s => s.owner), ['O1', 'O2']);
});
test('A4 exact ring validity', async () => {
  const S = await fresh('GKCR');
  const cases = {
    bowtie: [ringLL([[0, 0], [40, 40], [0, 40], [40, 0]]), /self-intersecting/],
    self_touching_pinch: [ringLL([[0, 0], [20, 20], [40, 0], [40, 40], [20, 20], [0, 40]]), /self-touching/],
    vertex_touches_edge: [ringLL([[0, 0], [40, 0], [40, 40], [25, 40], [20, 0], [15, 40], [0, 40]]), /self-touching/],
    collinear_spike: [ringLL([[0, 0], [40, 0], [20, 0], [20, 20], [0, 20]]), /spike/],
    repeated_vertex: [ringLL([[0, 0], [40, 0], [40, 0], [40, 20], [0, 20]]), /repeated vertex/],
    degenerate_collinear: [ringLL([[0, 0], [10, 0], [20, 0]]), /spike|degenerate/],
    zero_width_sliver: [ringLL([[0, 0], [50, 0], [50, 0.00008], [0, 0.00008]]), /repeated|degenerate|spike|below/],
    tiny_triangle: [ringLL([[0, 0], [0.08, 0], [0, 0.1]]), /below 1 m2/],
  };
  for (const [name, [ring, re]] of Object.entries(cases)) no(await S.reg(name.replace(/_/g, '').slice(0, 20), ring), re);
  // valid shapes still pass: collinear extra vertex, concave L, clockwise input, 300-vertex star
  ok(await S.reg('COL', ringLL([[100, 0], [130, 0], [160, 0], [160, 40], [100, 40]])));
  ok(await S.reg('L', ringLL([[200, 0], [260, 0], [260, 20], [220, 20], [220, 60], [200, 60]])));
  ok(await S.reg('CW', ringLL([[300, 0], [300, 40], [360, 40], [360, 0]])));
  const star = []; for (let k = 0; k < 300; k++) { const r = k % 2 ? 40 : 60, t = 2 * Math.PI * k / 300; star.push([500 + r * Math.cos(t), 500 + r * Math.sin(t)]); }
  ok(await S.reg('STAR', ringLL(star)));
  assert.equal(S.parcel('CW').areaM2.toFixed(3), '2400.000');
});
test('A4 partition and amalgamation test whole polygons', async () => {
  for (const s of ['GKCR', 'GKF']) {
    const S = await fresh(s);
    ok(await S.reg('L', ringLL([[0, 0], [60, 0], [60, 20], [20, 20], [20, 60], [0, 60]])));
    no(await S.part('L', [['L1', ringLL([[20, 0], [60, 0], [60, 20], [20, 60]])], ['L2', ringLL([[0, 0], [20, 0], [20, 20], [0, 20]])]]), /outside the parent/);
    no(await S.part('L', [['L1', ringLL([[20, 0], [60, 0], [60, 20], [20, 20]])], ['L2', ringLL([[0, 0], [20, 0], [20, 20], [0, 20]])]]), /uncovered/);
    ok(await S.part('L', [['L1', ringLL([[20, 0], [60, 0], [60, 20], [20, 20]])], ['L2', ringLL([[0, 0], [20, 0], [20, 60], [0, 60]])]]));
    ok(await S.reg('A', rect(100, 0, 30, 40), 'K1')); ok(await S.reg('B', rect(130, 0, 30, 40), 'K1'));
    no(await S.amal('A', 'B', 'M', ringLL([[100, 0], [160, 0], [160, 10], [170, 20], [160, 30], [160, 40], [100, 40], [100, 30], [110, 20], [100, 10]])), /outside/);
    ok(await S.reg('F', rect(300, 0, 30, 40), 'K1'));
    no(await S.amal('A', 'F', 'M2', rect(100, 0, 230, 40)), /allowance|adjacent/);
  }
});
test('R1 rectification may not relocate a parcel', async () => {
  const S = await fresh('GKCR');
  ok(await S.reg('A', rect(0, 0, 60, 40)));
  no(await S.rect('A', rect(1000, 0, 60, 40)), /moves/);
  ok(await S.rect('A', rect(0, 0, 60.5, 40)));
});
test('L1 long UTM edges cannot bow out of their cover (densified covers)', async () => {
  const { construct } = require('./support/probe_long_edge');
  const k = construct();
  for (const s of ['GKCR', 'GKC', 'GKF']) for (const cover of ['bbox', 'poly']) {
    const S = await fresh(s, { cover });
    ok(await S.reg('B', k.B));
    no(await S.reg('A', k.A), /overlap|meets/);
    assert.equal(G.maxPairOverlap(S.w).area, 0);
  }
});
test('A4/GKC-P 600 m x 8 m diagonal strip: refused by bbox cover, accepted by polygon cover', async () => {
  const L = 600, W = 8, th = Math.PI / 4;
  const pts = [[0, 0], [L, 0], [L, W], [0, W]].map(([x, y]) => [x * Math.cos(th) - y * Math.sin(th), x * Math.sin(th) + y * Math.cos(th)]);
  const Sb = await fresh('GKCR', { cover: 'bbox' });
  no(await Sb.reg('STRIP', ringLL(pts)), /exceeds the bound/);
  const Sp = await fresh('GKCR', { cover: 'poly' });
  ok(await Sp.reg('STRIP', ringLL(pts)));
  const n = [...Sp.w.state.keys()].filter(k => k.startsWith('CLAIM~')).length;
  assert.ok(n <= 256, `cells ${n}`);
});
test('A5 QueryByCell returns the active parcels meeting the cell', async () => {
  for (const s of ['GKCR', 'GKC', 'GKF']) {
    const S = await fresh(s);
    ok(await S.reg('A', rect(0, 0, 60, 40)));
    ok(await S.part('A', [['A1', rect(0, 0, 30, 40)], ['A2', rect(30, 0, 30, 40)]]));
    const fam = s === 'GKF' ? 'CELL' : 'CLAIM';
    const cells = [...S.w.state.keys()].filter(k => k.startsWith(`${fam}~`)).map(k => k.split('~')[2]);
    let hits = 0;
    for (const g of cells) {
      const got = JSON.parse((await S.q('QueryByCell', [g])).out).map(x => x.id);
      const want = ['A1', 'A2'].filter(id => Contract._internal.ringMeetsCellLL(S.parcel(id).ring, g));
      assert.deepEqual(got, want, `${s} ${g}`);
      hits += got.length;
    }
    assert.ok(hits > 0);
  }
});
test('A6 tolerance: whole-ring rule stops accumulation (GKCR <= eps; GKC no positive claim overlap)', async () => {
  for (const s of ['GKCR', 'GKC', 'GKF']) {
    const S = await fresh(s);
    ok(await S.reg('A', rect(60, 0, 60, 40)));
    ok(await S.reg('B', rect(0, 0, 60, 40)));
    const bumps = []; let acc = 0;
    for (let k = 0; k < 8; k++) {
      const y = 2 + 4 * k;
      bumps.push([[60, y], [60.18, y + 0.05], [60, y + 0.1]]);
      const right = []; for (const b of bumps) right.push(...b);
      const r = await S.rect('B', ringLL([[0, 0], [60, 0], ...right, [60, 40], [0, 40]]));
      if (r.ok) acc += 1; else bumps.pop();
    }
    const ov = G.maxPairOverlap(S.w).area;
    assert.ok(ov <= 0.01 + 1e-9, `${s}: overlap ${ov}`);
    if (s === 'GKC') assert.equal(acc, 0);
    else assert.equal(acc, 1);
  }
});
test('A7 released land can be claimed again (GKCR); GKC keeps it blocked (documented conservatism)', async () => {
  for (const s of ['GKCR', 'GKC']) {
    const S = await fresh(s);
    ok(await S.reg('A', rect(0, 0, 60, 40))); ok(await S.reg('B', rect(60, 0, 60, 40)));
    ok(await S.rect('A', rect(0, 0, 59.2, 40)));
    const r = await S.rect('B', ringLL([[59.2, 0], [120, 0], [120, 40], [59.2, 40]]));
    if (s === 'GKCR') ok(r); else no(r, /indexed under parcel A/);
    ok(await S.reg('P', rect(500, 0, 60, 40)));
    ok(await S.part('P', [['P1', rect(500, 0, 30, 40)], ['P2', rect(530, 0, 30, 40)]]));
    ok(await S.rect('P2', ringLL([[530.5, 0], [560, 0], [560, 40], [530.5, 40]])));
    const r2 = await S.rect('P1', rect(500, 0, 30.5, 40));
    if (s === 'GKCR') ok(r2); else no(r2);
    assert.equal(G.maxPairOverlap(S.w).area, 0);
  }
});
test('A7 GKCR refuses a claim on land that is still live', async () => {
  const S = await fresh('GKCR');
  ok(await S.reg('A', rect(0, 0, 60, 40))); ok(await S.reg('B', rect(60, 0, 60, 40)));
  ok(await S.rect('A', rect(0, 0, 59.2, 40)));
  no(await S.rect('B', ringLL([[58.8, 0], [120, 0], [120, 40], [58.8, 40]])), /overlap .* with parcel A/);
});
test('A8 roles: Survey geometry, Registration deeds, Revenue mutations', async () => {
  const S = await fresh('GKCR');
  no(await S.inv('RegisterParcel', ['A', 'K1', J(rect(0, 0, 60, 40)), SH1, 'S', '[]'], ID.outsider), /lacks the survey role/);
  no(await S.inv('RegisterParcel', ['A', 'K1', J(rect(0, 0, 60, 40)), SH1, 'S', '[]'], ID.revenue), /lacks the survey role/);
  ok(await S.inv('RegisterParcel', ['A', 'K1', J(rect(0, 0, 60, 40)), SH1, 'S', '[]'], ID.survey));
  no(await S.inv('RecordDeed', ['D1', 'K1', 'O1', 'O2', '1', '2'], ID.revenue), /registration role/);
  ok(await S.inv('RecordDeed', ['D1', 'K1', 'O1', 'O2', '1', '2'], ID.registration));
  no(await S.inv('TransferShare', ['K1', 'O1', 'O2', '1', '2', 'D1'], ID.registration), /revenue role/);
  no(await S.inv('TransferShare', ['K1', 'O1', 'O2', '1', '2'], ID.revenue), /registered deed/);
  no(await S.inv('TransferShare', ['K1', 'O1', 'O2', '1', '3', 'D1'], ID.revenue), /does not match/);
  ok(await S.inv('TransferShare', ['K1', 'O1', 'O2', '1', '2', 'D1'], ID.revenue));
  no(await S.inv('TransferShare', ['K1', 'O1', 'O2', '1', '2', 'D1'], ID.revenue), /unconsumed/);
  no(await S.inv('CompactCell', ['ttw16s1e'], ID.revenue), /role/);
});
test('A8 two mutations consuming one deed: one invalidated', async () => {
  const S = await fresh('GKCR');
  ok(await S.inv('RegisterParcel', ['A', 'K1', J(rect(0, 0, 60, 40)), SH1, 'S', '[]'], ID.survey));
  ok(await S.inv('RecordDeed', ['D1', 'K1', 'O1', 'O2', '1', '2'], ID.registration));
  const t1 = await S.end('TransferShare', ['K1', 'O1', 'O2', '1', '2', 'D1'], ID.revenue);
  const t2 = await S.end('TransferShare', ['K1', 'O1', 'O2', '1', '2', 'D1'], ID.revenue);
  assert.deepEqual(S.commit([t1, t2]), ['VALID', 'MVCC_READ_CONFLICT']);
});
test('A6 amalgamation cannot add up two tolerated overlaps (tol flags, footprint read)', async () => {
  const Qring = ringLL([[0, 80], [0, 40], [10, 40], [10.05, 39.88], [10.1, 40], [40, 40], [40.05, 39.88], [40.1, 40], [60, 40], [60, 80]]);
  for (const s of ['GKCR', 'GKF']) {
    const S = await fresh(s);
    ok(await S.reg('A', rect(0, 0, 30, 40), 'K1')); ok(await S.reg('B', rect(30, 0, 30, 40), 'K1'));
    ok(await S.reg('Q', Qring, 'K2'));
    if (s === 'GKCR') { assert.equal(S.parcel('A').tol, true); assert.equal(S.parcel('B').tol, true); assert.equal(S.parcel('Q').tol, true); }
    no(await S.amal('A', 'B', 'M', rect(0, 0, 60, 40)), /overlap of 0\.01[0-9]* m2 with parcel Q/);
  }
  const S = await fresh('GKC');
  ok(await S.reg('A', rect(0, 0, 30, 40), 'K1'));
  no(await S.reg('Q', Qring, 'K2'), /indexed under parcel A/);
});
test('A6 an untolerated amalgamation does not read its footprint', async () => {
  const S = await fresh('GKCR');
  ok(await S.reg('A', rect(0, 0, 30, 40), 'K1')); ok(await S.reg('B', rect(30, 0, 30, 40), 'K1'));
  const t = await S.end('AmalgamateParcels', ['A', 'B', 'M', J(rect(0, 0, 60, 40)), '', '[]']);
  assert.equal([...t.stub.reads.keys()].filter(k => k.startsWith('CLAIM~')).length, 0);
  ok({ ok: S.commit([t])[0] === 'VALID' });
});
test('T1 (v1.4.1) siblings overlapping a third sibling cannot be amalgamated into an overlap above eps', async () => {
  // found while writing the proof of Theorem 1: in v1.4.0, GKC accepted this and committed 0.018 m2
  const kids = [['A', rect(0, 0, 9, 20)], ['B', rect(9, 0, 9, 20)], ['S', rect(0, 19.999, 18, 20.001)]];
  for (const s of ['GKF', 'GKCR']) {
    const S = await fresh(s);
    ok(await S.reg('P', rect(0, 0, 18, 40), 'K1'));
    ok(await S.part('P', kids));
    no(await S.amal('A', 'B', 'M', rect(0, 0, 18, 20), '["S"]'), /overlap of 0\.01[0-9]* m2 with parcel S/);
    assert.ok(G.maxPairOverlap(S.w).area <= 0.01);
  }
  const S = await fresh('GKC');
  ok(await S.reg('P', rect(0, 0, 18, 40), 'K1'));
  no(await S.part('P', kids), /Children A and S overlap/);
  assert.equal(G.maxPairOverlap(S.w).area, 0);
});
test('T2 (v1.5.0) a sliver thinner than the 1 mm lattice cannot hide an overlap above eps', async () => {
  // rings of parcels R7C13 and R7C14 from the rotated-corpus run (mm offsets in UTM 43N): the true
  // overlap of O and Q is 0.0105 m2; lattice clipping in v1.4.x computed 0 and accepted O
  const proj4 = require('proj4');
  const OR = [600641, 3450313];
  const ring = pts => { const r = pts.map(([X, Y]) => proj4('EPSG:32643', 'EPSG:4326', [OR[0] + X / 1000, OR[1] + Y / 1000])); r.push([...r[0]]); return r; };
  const O = ring([[619, 707], [28904, 28991], [7442, 50452], [-20842, 22168]]);
  const Q = ring([[28655, 29239], [56940, 57523], [35726, 78737], [7442, 50452]]);
  for (const s of ['GKCR', 'GKC', 'GKF']) {
    const S = await fresh(s);
    ok(await S.reg('Q', Q));
    no(await S.reg('O', O), /0\.0105 m2/);
    assert.equal(G.maxPairOverlap(S.w).area, 0);
  }
});
test('T3 (v1.5.1) a descendant may claim new land beside its ancestor\'s indexed geometry; encroachment on a sibling is still refused', async () => {
  // found by diagnosing GKC refusals in the v1.5.0 benchmark: v1.5.0 tested the whole output ring
  // against indexed geometry, so a partition child's outward correction met its parent's ring
  for (const s of ['GKC', 'GKCR']) {
    const S = await fresh(s);
    ok(await S.reg('P', rect(0, 0, 60, 40), 'K1'));
    ok(await S.part('P', [['A', rect(0, 0, 30, 40)], ['B', rect(30, 0, 30, 40)]]));
    ok(await S.rect('A', rect(0, -0.4, 30, 40.4)));                          // outward into free land
    no(await S.rect('B', rect(29.7, 0, 30.3, 40)), s === 'GKC' ? /indexed under parcel (P|A)/ : /overlap of [0-9.]+ m2 with parcel A/);   // into the sibling
    ok(await S.reg('X', rect(100, 0, 30, 40), 'K2')); ok(await S.reg('Y', rect(130, 0, 30, 40), 'K2'));
    ok(await S.amal('X', 'Y', 'M', rect(100, 0, 60, 40)));
    ok(await S.rect('M', rect(100, -0.5, 60, 40.5)));                        // merged parcel claims outward
    assert.equal(G.maxPairOverlap(S.w).area, 0);
  }
});
