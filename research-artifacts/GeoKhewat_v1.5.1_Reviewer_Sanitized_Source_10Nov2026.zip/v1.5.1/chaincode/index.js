'use strict';
const GeoKhewatContract = require('./lib/geokhewat-contract');
module.exports.GeoKhewatContract = GeoKhewatContract;
module.exports.contracts = [GeoKhewatContract];
