# Changelog

Versions change only when the contract code changes. Each entry names the defect, the probe that exhibited it and the regression test that now passes.

## 1.5.1 (2026-10-19)

- **C13 Index entries are examined against the claim itself.** Version 1.5.0 decided whether an index entry concerned a claim by testing the whole output ring against the entry's geometry. GKC refuses any such entry of another parcel, so a partition child could not claim new land in a cell where its parent's geometry was indexed (the child's ring meets the parent's), and a merged parcel could not claim land beside its sources. This refused valid work; it did not admit an overlap. In the v1.5.0 benchmark GKC refused 655 outward corrections at endorsement at 256 proposals per block, against GKCR's 74; on 1.5.1 it refuses 94, and GKC's mean commit yield differs from GKCR's by at most 0.12 percentage points on every mix except boundary adjustment (probe `layerb/probe_descendant_claim.js`; found by diagnosing those refusals). The meeting of a claim N \ (O1 ∪ O2) with indexed geometry G is now computed exactly by inclusion–exclusion over intersections of up to four polygons (`interAreaK`, `claimArea2` in `lib/exact.js`), and claim existence for two inputs is exact instead of an upper bound. Validated against GEOS on 6,000 claim-shaped polygon sets with no disagreement above 1e-6 m² (`layerb/validate_claim.py`). Regression test T3. Encroachment on a sibling is still refused.

## 1.5.0 (2026-10-19)

- **C12 Exact geometry for every safety decision** (`lib/exact.js`, new). Version 1.4.1 computed overlaps and claims with integer-lattice clipping, which rounds the intersection points it constructs to the 1 mm lattice. On diagonal edges a sliver thinner than the lattice vanished from one computation while counting in another: a registration overlapping its neighbour by 0.0105 m² was accepted because the computed overlap was zero, and a sub-millimetre rotation of the shared edge then doubled the overlap without any check (probe `layerb/probe_lattice_sliver.js`; found by auditing rotated-corpus benchmark states against the safety theorem). Whole-ring overlap, claim existence, the cells a claim occupies, the positive-area meeting of a claim with indexed geometry, and the containment tests of partition, rectification and amalgamation are now computed with BigInt rationals. Claim cells are the cells met by a superset of the claim's boundary or containing an interior point of the claim. Validated against GEOS on 4,999 random valid polygon pairs (worst disagreement 4.5 × 10⁻¹³ m²). Regression test T2.

## 1.4.1 (2026-10-19)

- **C11 No sibling overlap under GKC.** GKC never applies the whole-ring rule, so two partition siblings that each overlapped a third by just under eps could be amalgamated and the merged parcel overlapped the third by 0.018 m² (probe `layerb/probe_sibling_amalgamation.js`; found while writing the safety proof). GKC now refuses partitions whose children overlap at all. GKF and GKCR were not affected. Regression test T1.

## 1.4.0 (2026-10-19)

Fixes for the 33 defects found by 42 probes against version 1.3.0 (`layerb/out/audit_v13.json`).

- **C1** Configuration written once by `InitConfig` (admin identity of an admin MSP) and immutable; `SetStrategy` removed; precision in every index key. Tests A1, A2.
- **C2** Every new identifier is read before it is written; reuse of an active or retired identifier is refused; concurrent creation collides on the nil-version read. Tests A3.
- **C3** Exact integer ring validation on the millimetre UTM lattice (repeated vertices, spikes, self-touching, self-intersection, area below 1 m²). Test A4.
- **C4** Partition and amalgamation test whole polygons; rectification bounded by area change and symmetric difference. Tests A4, R1, R2.
- **C5** Covers computed on UTM edges densified to 10 m; optional polygon-exact covers. Tests L1, A4/GKC-P.
- **C6** Claims keep every piece of positive area; whole-ring overlap rule; tolerance flags inherited by successors. Test A6.
- **C7** GKCR: reclaimable claim index with refresh in claim cells and `CompactCell`. Tests A7.
- **C8** `QueryByCell` answers from the index of the configured strategy and returns active parcels whose ring meets the cell; iterator handling fixed for the Fabric shim. Test A5.
- **C9** Roles (survey, registration, revenue, admin) and optional key-level endorsement. Tests A8.
- **C10** Amalgamation keeps the holding's share vector; share transfers consume a recorded deed once. Test A3/B7.

## 1.3.0

Version received for audit. Introduced claim-scoped keys (GKC). Not safe: see the audit.
