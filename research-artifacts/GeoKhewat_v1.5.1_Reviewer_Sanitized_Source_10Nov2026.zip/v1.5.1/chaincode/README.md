# GeoKhewat chaincode 1.5.1

Hyperledger Fabric 2.5 chaincode (Node.js) that keeps cadastral parcels (Khasras) disjoint within a stated tolerance and keeps the ownership shares of each holding (Khewat) summing to exactly one, under Fabric's execute-order-validate concurrency. It is the research artifact of the manuscript "Claim-scoped spatial conflict domains: keeping cadastral parcels disjoint under execute-order-validate concurrency".

This is research code. It has been tested locally against a Fabric validation stub and on a single-host, three-organisation Fabric 2.5.16 network with LevelDB state. It has not been run with CouchDB, on a multi-host network or in production.

## Layout

| Path | Content |
|---|---|
| `index.js` | Exports the contract for `fabric-chaincode-node` |
| `lib/geokhewat-contract.js` | The contract: configuration, roles, operations, covers, conflict-domain strategies, claim index |
| `lib/exact.js` | Exact rational geometry (BigInt): signed area, point classification, intersection area of two or more simple polygons, exact claim areas, claim boundary pieces, interior test |
| `test/regression.test.js` | One regression test per audited defect of version 1.3.0, plus T1 (v1.4.1), T2 (v1.5.0) and T3 (v1.5.1) |
| `test/functional.test.js` | Eleven-check functional suite and a version-conflict probe for GKF, GKC and GKCR |
| `test/concurrency.test.js` | Hostile interleavings endorsed against one snapshot and validated in ledger order |
| `test/property.test.js` | Randomised blocks under four configurations, with overlap and index-consistency checks after every block |
| `test/support/` | Fabric validation stub (MVCC versions, nil-version reads, range-query phantom check), geometry helpers, long-edge probe |
| `out/` | Output of the last executed test runs (TAP files and property-test summary) |
| `package.json`, `package-lock.json` | Pinned dependencies: fabric-contract-api 2.5.8, fabric-shim 2.5.8, clipper-lib 6.4.2, proj4 2.12.1 |

## Configuration

The configuration is written once, by `InitConfig`, and can never be changed. The caller must be an identity whose subject contains `OU=admin` and whose MSP is listed under `roles.admin`.

```json
{"strategy": "GKCR", "precision": 8, "cover": "poly", "eps": 0.01,
 "roles": {"admin": ["SurveyMSP"], "survey": ["SurveyMSP"], "registration": ["RegistrationMSP"], "revenue": ["RevenueMSP"]},
 "sbe": false}
```

| Field | Values | Meaning |
|---|---|---|
| `strategy` | `GKCR` (default), `GKC`, `GKF`; `B1`, `B2`, `B3` only with `"research": true` | Conflict-domain strategy (below) |
| `precision` | integer 5–10, default 8 | Geohash precision of index cells; part of every index key (`CLAIM~p8~…`) |
| `cover` | `poly` (default) or `bbox` | Polygon-exact covers or covers of padded bounding boxes of densified edges |
| `eps` | 0–1 m², default 0.01 | Overlap tolerance |
| `roles` | MSP lists for `admin`, `survey`, `registration`, `revenue` | Who may call what |
| `sbe` | boolean | Sets key-level endorsement policies (survey peers for geometry, revenue for holdings, registration for deeds) |

## Strategies

| Strategy | Keys read beyond the parcel, holding and deed | Overlap check | Safe |
|---|---|---|---|
| B1 | none | none | no (research baseline) |
| B2 | `REGISTRY~GLOBAL` (rewritten by every geometric transaction) and client-named neighbours | whole ring vs neighbours | yes, by serialising all geometric work |
| B3 | client-named neighbours | whole ring vs neighbours | no: a parcel the client did not name is never read |
| GKF | `CELL` records of the old and new footprints | whole ring vs every parcel listed | yes |
| GKC | `CLAIM` records of the cells of newly claimed land, and the `GEOM` records they name | any positive-area meeting of the claim with indexed geometry is refused | yes |
| GKCR | as GKC, plus the live descendants of the lineages a claim meets | whole ring vs live parcels ≤ eps | yes |

"Safe" means the safety theorem of the manuscript applies: under its stated assumptions, every committed state keeps all active parcels pairwise overlapping by at most `eps`.

## Transactions and roles

| Function | Role | Notes |
|---|---|---|
| `InitConfig(configJson)` | admin | Once only; a second call is refused; concurrent calls collide on the nil-version read |
| `RegisterParcel(khasra, khewat, ringJson, sharesJson, provenance, neighbourIdsJson)` | survey | Ring in UTM 43N metres; shares as exact fractions summing to 1 |
| `RectifyBoundary(khasra, ringJson, provenance, neighbourIdsJson)` | survey | Area change ≤ 2 %, symmetric difference ≤ 5 % |
| `PartitionParcel(parentId, childrenJson, neighbourIdsJson)` | survey | Children inside the parent (≤ eps outside), gap ≤ 0.5 %, siblings overlap ≤ eps (not at all under GKC) |
| `AmalgamateParcels(idA, idB, newId, ringJson, sharesJson, neighbourIdsJson)` | survey | Same Khewat, adjacent sources, merged area within −0.5 %/+6 % of the sources |
| `RecordDeed(deedId, khewat, seller, buyer, num, den)` | registration | |
| `TransferShare(khewat, seller, buyer, num, den, deedId)` | revenue | Consumes a recorded deed exactly once |
| `CompactCell(cell)` | survey or admin | GKCR only: rebuilds one cell from live parcels |
| `QueryParcel`, `QueryByCell(prefix)`, `IndexStats`, `GetConfig` | any | Read-only |

`neighbourIdsJson` is used only by B2 and B3; the cell strategies ignore it.

## Geometry

Rings are projected to UTM zone 43N and rounded to millimetres. Validity (simple ring, no repeated vertex, no spike, no self-touching, area ≥ 1 m², at most 2,000 vertices) is decided with exact integer predicates. Every safety-relevant area (whole-ring overlap, existence and location of claimed land, positive-area meeting of a claim with indexed geometry, the containment tests of partition and amalgamation) is computed exactly with rational arithmetic in `lib/exact.js`. `clipper-lib` is used only to test that the two sources of an amalgamation share at least about 1 m of boundary (an operation precondition, not an overlap decision).

## Running the tests

Node.js 18 or later.

```bash
npm ci
npm test                      # 44 tests: regression, functional, concurrency, property (50 blocks per run)
GK_PROP_BLOCKS=200 node --test test/property.test.js   # longer randomised run
```

The last executed results are in `out/tests_stub_final.tap` (44 of 44 passed on 1.5.1) and `out/property_results.json` (16 runs, 800 blocks, 2,512 proposals, 1,608 committed, no pair of active parcels overlapping by more than eps, 4,800 cell queries with no mismatch). The scripts that build a Fabric 2.5.16 network, deploy this chaincode as an external service and run the network tests, Caliper and the load generator are in the reproducibility artifact (`fabric_native/`).

## Test names and the manuscript

Test names carry the identifiers of the revision items they verify (A1 configuration, A2 precision, A3 identifiers, A4 polygon validity, A5 cell queries, A6 tolerance, A7 reclamation, A8 roles, L1 long edges, R1/R2 rectification and amalgamation bounds, T1 sibling amalgamation, T2 lattice slivers, T3 claims beside an ancestor's geometry). The manuscript numbers its safety assumptions A1–A9 independently; Table 4 of the manuscript maps each assumption to the tests that violate it.

## Known limitations

- Progress is not guaranteed: a claim can be invalidated repeatedly under contention, and `CompactCell` writes keys that concurrent claims in the same cell read.
- Not tested with CouchDB, whose handling of deleted keys differs from LevelDB's; the chaincode deletes no key.
- Under GKC released land stays blocked (the index only grows); use GKCR to reclaim it.
- Covers larger than 256 cells are refused; under box covers this rejects long diagonal strips that polygon covers accept.
- The tolerance and the operation bounds are configuration choices, not survey standards.

## Licence

Apache-2.0.
