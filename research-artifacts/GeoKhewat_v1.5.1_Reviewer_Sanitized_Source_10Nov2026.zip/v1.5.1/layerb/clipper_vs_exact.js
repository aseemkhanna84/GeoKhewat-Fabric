'use strict';
/* How far integer-lattice clipping (clipper-lib, as used by v1.4.x) departs from exact areas on
 * the validation cases. Writes out/clipper_vs_exact.json. */
const C = require('clipper-lib');
const cases = require('./out/validate_exact_cases.json');
const invalid = new Set(require('./out/validate_exact_invalid.json'));   // rings GEOS reports as invalid
const P = a => a.map(([X, Y]) => ({ X, Y }));
function clip(a, b, type) {
  const c = new C.Clipper(); c.AddPath(P(a), C.PolyType.ptSubject, true); c.AddPath(P(b), C.PolyType.ptClip, true);
  const sol = new C.Paths(); c.Execute(type, sol, C.PolyFillType.pftNonZero, C.PolyFillType.pftNonZero);
  return Math.abs(sol.reduce((s, p) => s + C.Clipper.Area(p), 0)) / 1e6;
}
const out = { cases: cases.length - invalid.size, by_kind: {} };
for (const [i, c] of cases.entries()) {
  if (invalid.has(i)) continue;
  const k = c.kind; const o = out.by_kind[k] || (out.by_kind[k] = { n: 0, inter_err_gt_1e6: 0, inter_err_gt_eps: 0, diff_err_gt_eps: 0, diff_lost_entirely: 0, worst_err_m2: 0 });
  o.n += 1;
  const ei = Math.abs(clip(c.a, c.b, C.ClipType.ctIntersection) - c.inter), cd = clip(c.a, c.b, C.ClipType.ctDifference), ed = Math.abs(cd - c.aMinusB);
  if (ei > 1e-6) o.inter_err_gt_1e6 += 1; if (ei > 0.01) o.inter_err_gt_eps += 1; if (ed > 0.01) o.diff_err_gt_eps += 1;
  if (c.aMinusB > 1e-6 && cd === 0) o.diff_lost_entirely += 1;
  o.worst_err_m2 = Math.max(o.worst_err_m2, ei, ed);
}
require('fs').writeFileSync('out/clipper_vs_exact.json', JSON.stringify(out, null, 1));
console.log(JSON.stringify(out));
