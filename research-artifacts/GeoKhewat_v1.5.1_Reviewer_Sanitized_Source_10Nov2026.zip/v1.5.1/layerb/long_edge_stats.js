'use strict';
/* Chord deviation between UTM-straight edges and lon/lat-straight edges, and the bow of a
 * 1500 m edge out of its end points' lon/lat box (the L1 counterexample). out/long_edge.json */
const fs = require('fs');
const G = require('./geo_util');
const { construct } = require('./probe_long_edge');
const res = { chord_deviation_m: {} };
for (const L of [10, 50, 100, 500, 1500, 5000]) { let worst = 0;
  for (const th of [0, 0.3, 0.785, 1.2]) for (const [x0, y0] of [[0, 0], [-150000, 0], [150000, 500000]]) {
    const a = [G.X0 + x0, G.Y0 + y0], b = [a[0] + L * Math.cos(th), a[1] + L * Math.sin(th)];
    const la = G.ll(a), lb = G.ll(b);
    for (const t of [0.25, 0.5, 0.75]) { const m = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
      const lm = [la[0] + (lb[0] - la[0]) * t, la[1] + (lb[1] - la[1]) * t]; const back = G.utm(lm);
      worst = Math.max(worst, Math.hypot(back[0] - m[0], back[1] - m[1])); } }
  res.chord_deviation_m[L] = worst; }
const k = construct();
const lats = k.A.map(p => p[1]);
res.l1_case = { strip_length_m: 1500, strip_width_m: 8, row_boundary_lat: k.row_boundary_lat, end_lat: k.end_lat_A,
  max_lat_vertices: Math.max(...lats), overlap_AB_m2: G.overlapM2(k.A, k.B) };
// bow of the densified north edge above the vertex box
const proj4 = require('proj4');
const P = G.utm(k.A[0]), Q = G.utm(k.A[1]); let maxLat = -1e9;
for (let t = 0; t <= 1.00001; t += 0.001) maxLat = Math.max(maxLat, G.ll([P[0] + (Q[0] - P[0]) * t, P[1] + (Q[1] - P[1]) * t])[1]);
res.l1_case.bow_m = (maxLat - Math.max(G.ll(P)[1], G.ll(Q)[1])) * 110900;
fs.writeFileSync('out/long_edge.json', JSON.stringify(res, null, 1));
console.log(JSON.stringify(res));
