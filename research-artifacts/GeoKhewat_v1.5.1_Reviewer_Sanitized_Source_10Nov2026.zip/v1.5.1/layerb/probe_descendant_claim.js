'use strict';
/*
 * Found by diagnosing GKC refusals in the v1.5.0 benchmark. v1.5.0 decided whether an index
 * entry concerns a claim by testing the whole output ring against the entry's geometry. Under
 * GKC, which refuses any such entry of another parcel, a partition child could then not claim
 * new land in a cell where its parent's geometry was indexed (the child's ring meets the
 * parent's), and a merged parcel could not claim land beside its sources. v1.5.1 tests the
 * claim itself, exactly. Encroachment on a sibling must still be refused.
 * Run against v1.5.0 (snapshot) and the current version. Writes out/probe_descendant_claim.json.
 */
const fs = require('fs');
const path = require('path');
const { World, invoke } = require('./fabric_stub');
const G = require('./geo_util');
const CUR = require('../chaincode_v14/geokhewat-chaincode/lib/geokhewat-contract.js');
const VERSIONS = { 'v1.5.0': require('../chaincode_v140_snapshot/v1.5.0/geokhewat-contract.js'), [`v${CUR._internal.VERSION}`]: CUR };
const ID = { admin: { msp: 'SurveyMSP', id: 'x509::/OU=admin/CN=Admin::/CN=ca' }, survey: { msp: 'SurveyMSP' } };
const ROLES = { admin: ['SurveyMSP'], survey: ['SurveyMSP'], registration: ['RegistrationMSP'], revenue: ['RevenueMSP'] };
const SH1 = J => J([{ owner: 'O1', num: '1', den: '1' }]);
const J = JSON.stringify;
const short = r => (r.ok ? 'VALID' : `refused: ${(r.error || r.code).slice(0, 90)}`);
async function run(Contract, strategy) {
  const w = new World(); const c = new Contract();
  const inv = (fn, args) => invoke(w, c, fn, args, ID.survey);
  const init = await invoke(w, c, 'InitConfig', [J({ strategy, precision: 8, cover: 'poly', eps: 0.01, roles: ROLES })], ID.admin);
  if (!init.ok) throw new Error(init.error);
  const out = {};
  await inv('RegisterParcel', ['P', 'K1', J(G.rect(0, 0, 60, 40)), SH1(J), 'S', '[]']);
  out.partition = short(await inv('PartitionParcel', ['P', J([['A', G.rect(0, 0, 30, 40)], ['B', G.rect(30, 0, 30, 40)]].map(([k, ring]) => ({ khasra: k, ring, shares: JSON.parse(SH1(J)) }))), '[]']));
  out.child_outward_0p4m = short(await inv('RectifyBoundary', ['A', J(G.rect(0, -0.4, 30, 40.4)), 'S', '[]']));
  out.child_into_sibling_0p3m = short(await inv('RectifyBoundary', ['B', J(G.rect(29.7, 0, 30.3, 40)), 'S', '[]']));
  await inv('RegisterParcel', ['X', 'K2', J(G.rect(100, 0, 30, 40)), SH1(J), 'S', '[]']);
  await inv('RegisterParcel', ['Y', 'K2', J(G.rect(130, 0, 30, 40)), SH1(J), 'S', '[]']);
  out.amalgamation = short(await inv('AmalgamateParcels', ['X', 'Y', 'M', J(G.rect(100, 0, 60, 40)), '', '[]']));
  out.merged_outward_0p5m = short(await inv('RectifyBoundary', ['M', J(G.rect(100, -0.5, 60, 40.5)), 'S', '[]']));
  const ps = []; for (const [k, e] of w.state) if (k.startsWith('PARCEL~')) { const p = JSON.parse(e.value.toString()); if (p.status === 'ACTIVE') ps.push(p); }
  let mx = 0; for (let i = 0; i < ps.length; i++) for (let j = i + 1; j < ps.length; j++) mx = Math.max(mx, G.overlapM2(ps[i].ring, ps[j].ring));
  out.committed_max_pair_overlap_m2 = mx;
  return out;
}
(async () => {
  const res = { probe: 'descendant_claim', timestamp_utc: new Date().toISOString(), results: {} };
  for (const [ver, C] of Object.entries(VERSIONS)) for (const s of ['GKC', 'GKCR']) res.results[`${ver}_${s}`] = await run(C, s);
  fs.writeFileSync(path.join(__dirname, 'out', 'probe_descendant_claim.json'), J(res, null, 1));
  for (const [k, v] of Object.entries(res.results)) console.log(k, J(v));
})();
