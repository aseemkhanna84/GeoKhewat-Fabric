'use strict';
/*
 * Layer B' workload benchmark (v10). The GeoKhewat chaincode itself (its version and the
 * SHA-256 of its source are recorded in every output line) is executed against the
 * Fabric-semantics stub: every proposal of a block is endorsed against the same
 * committed state and the block is then validated in order (MVCC and phantom checks). The
 * only thing that differs between strategies is the chaincode configuration.
 *
 * usage: node bench_cc.js '<json spec>'   (see SPEC defaults below); appends JSON lines to
 * out/bench/<tag>.jsonl, one line per (strategy, corpus, B, seed) run.
 */
const fs = require('fs');
const path = require('path');
const { World, endorse, commitBlock, invoke } = require('./fabric_stub');
const G = require('./geo_util');
const Contract = require('../chaincode_v14/geokhewat-chaincode/lib/geokhewat-contract.js');
const I = Contract._internal;
const CC_SHA = require('crypto').createHash('sha256').update(fs.readFileSync(require.resolve('../chaincode_v14/geokhewat-chaincode/lib/geokhewat-contract.js'))).update(fs.readFileSync(require.resolve('../chaincode_v14/geokhewat-chaincode/lib/exact.js'))).digest('hex');

const SPEC = Object.assign({
  tag: 'test', strategies: ['GKCR:poly'], corpus: 'uniform', theta: 0, B: [128], seeds: [1], blocks: 6,
  mix: 'admin', skew: 0, precision: 8, compact_every: 0, trace: false,
}, JSON.parse(process.argv[2] || '{}'));
const ID = { admin: { msp: 'SurveyMSP', id: 'x509::/OU=admin/CN=Admin::/CN=ca' }, survey: { msp: 'SurveyMSP' }, registration: { msp: 'RegistrationMSP' }, revenue: { msp: 'RevenueMSP' } };
const ROLES = { admin: ['SurveyMSP'], survey: ['SurveyMSP'], registration: ['RegistrationMSP'], revenue: ['RevenueMSP'] };
const MIXES = {
  admin: { transfer: 0.30, out: 0.20, in: 0.15, part: 0.15, amal: 0.10, reg: 0.10 },
  transfer_heavy: { transfer: 0.70, out: 0.10, in: 0.05, part: 0.05, amal: 0.05, reg: 0.05 },
  rectification_heavy: { transfer: 0.10, out: 0.40, in: 0.40, part: 0.05, amal: 0.025, reg: 0.025 },
  partition_heavy: { transfer: 0.10, out: 0.10, in: 0.10, part: 0.60, amal: 0.05, reg: 0.05 },
  survey_campaign: { transfer: 0.05, out: 0.45, in: 0.30, part: 0.05, amal: 0.05, reg: 0.10 },
  registration_burst: { transfer: 0.10, out: 0.10, in: 0.10, part: 0.10, amal: 0.05, reg: 0.55 },
  boundary_adjustment: { transfer: 0.10, adjust: 0.80, part: 0.05, reg: 0.05 },
};

/* ------------------------------------------------------------- corpus */
const WIDTH_CLASSES = [[7, 12, 0.20], [16, 30, 0.30], [55, 70, 0.35], [100, 135, 0.15]];
function buildCorpus(kind, rnd) {
  const parcels = []; const lanes = []; const ROWS = 24, H = 30, LANE = 4, PATH = 4;
  let y = 0;
  for (let r = 0; r < ROWS; r++) {
    let x = 0, inBlock = 0, block = 0;
    let cls = null;
    if (kind === 'hetero') { let u = rnd(), acc = 0; for (const c of WIDTH_CLASSES) { acc += c[2]; if (u <= acc) { cls = c; break; } } cls = cls || WIDTH_CLASSES[3]; }
    const target = 980;
    let c = 0;
    while (true) {
      const w = kind === 'hetero' ? Math.round((cls[0] + rnd() * (cls[1] - cls[0])) * 100) / 100 : 40;
      if (x + w > target + 1e-9) break;
      parcels.push({ id: `R${r}C${c}`, khewat: `K${r}_${block}`, x0: x, y0: y, x1: x + w, y1: y + H, row: r, col: c });
      x += w; c += 1; inBlock += 1;
      if (inBlock === 4) { inBlock = 0; block += 1; x += PATH; }
    }
    lanes.push({ y0: y + H, y1: y + H + LANE, x0: 0, x1: x });
    y += H + LANE;
  }
  return { parcels, lanes, extent: { x1: 990, y1: y } };
}
function shareVector(rnd) {
  const k = 1 + Math.floor(rnd() * 7);
  const dens = [2, 3, 4, 5, 6, 8, 9, 10, 12];
  let parts = []; let rem = [1n, 1n];   // num/den remaining
  for (let i = 0; i < k - 1; i++) {
    const d = BigInt(dens[Math.floor(rnd() * dens.length)]);
    // take rem * 1/d
    parts.push([rem[0], rem[1] * d]);
    rem = [rem[0] * (d - 1n), rem[1] * d];
  }
  parts.push(rem);
  return parts.map(([n, d], i) => ({ owner: `O${i + 1}`, num: String(n), den: String(d) }));
}

/* local metres -> lon/lat with an optional rotation about the corpus centre */
function makeXf(theta, ext) {
  const cx = ext.x1 / 2, cy = ext.y1 / 2, c = Math.cos(theta * Math.PI / 180), s = Math.sin(theta * Math.PI / 180);
  const fwd = ([x, y]) => [cx + (x - cx) * c - (y - cy) * s, cy + (x - cx) * s + (y - cy) * c];
  const inv = ([x, y]) => [cx + (x - cx) * c + (y - cy) * s, cy - (x - cx) * s + (y - cy) * c];
  const ring = b => G.ringLL([[b.x0, b.y0], [b.x1, b.y0], [b.x1, b.y1], [b.x0, b.y1]].map(fwd));
  const back = ringLL => { const l = ringLL.slice(0, -1).map(p => { const [x, y] = G.utm(p); return inv([x - G.X0, y - G.Y0]); });
    const xs = l.map(v => v[0]), ys = l.map(v => v[1]); const r3 = v => Math.round(v * 1000) / 1000;
    return { x0: r3(Math.min(...xs)), y0: r3(Math.min(...ys)), x1: r3(Math.max(...xs)), y1: r3(Math.max(...ys)) }; };
  return { ring, back, fwd };
}

/* ---------------------------------------------------------- world setup */
const cacheWorlds = new Map();
async function baseWorld(strategy, cover, corpus, theta) {
  const key = `${strategy}|${cover}|${corpus}|${theta}|${SPEC.precision}`;
  if (cacheWorlds.has(key)) return cacheWorlds.get(key);
  const rnd = G.rng(20261019);
  const C = buildCorpus(corpus, rnd);
  const xf = makeXf(theta, C.extent);
  const w = new World(); const c = new Contract();
  const cfg = { strategy, precision: SPEC.precision, cover, eps: 0.01, roles: ROLES, research: ['B1', 'B2', 'B3'].includes(strategy) };
  const r0 = await invoke(w, c, 'InitConfig', [JSON.stringify(cfg)], ID.admin);
  if (!r0.ok) throw new Error(r0.error);
  const kh = new Map();
  for (const p of C.parcels) {
    if (!kh.has(p.khewat)) kh.set(p.khewat, shareVector(rnd));
    const r = await invoke(w, c, 'RegisterParcel', [p.id, p.khewat, JSON.stringify(xf.ring(p)), JSON.stringify(kh.get(p.khewat)), 'SYNTHETIC', '[]'], ID.survey);
    if (!r.ok) throw new Error(`corpus ${p.id}: ${r.error || r.code}`);
  }
  const out = { w, C, xf, kh: [...kh.entries()] };
  cacheWorlds.set(key, out);
  return out;
}
function cloneWorld(w) {
  const n = new World(); n.block = w.block;
  for (const [k, e] of w.state) n.state.set(k, { value: Buffer.from(e.value), ver: e.ver });
  return n;
}

/* --------------------------------------------------- state model for proposals */
function model(w, xf) {
  const ps = [];
  for (const [k, e] of w.state) {
    if (!k.startsWith('PARCEL~')) continue;
    const p = JSON.parse(e.value.toString());
    if (p.status !== 'ACTIVE') continue;
    ps.push({ id: p.id, khewat: p.khewat, ...xf.back(p.ring) });
  }
  ps.sort((a, b) => (a.id < b.id ? -1 : 1));
  return ps;
}
function khewats(w) {
  const out = new Map();
  for (const [k, e] of w.state) if (k.startsWith('KHEWAT~')) out.set(k.slice(7), JSON.parse(e.value.toString()).shares);
  return out;
}
/* B3's client-side neighbour list: active parcels whose rotated bounding boxes, widened by 3 m, meet */
function neighbourIndex(ps, xf) {
  const box = p => { const pts = [[p.x0, p.y0], [p.x1, p.y0], [p.x1, p.y1], [p.x0, p.y1]].map(xf.fwd); const xs = pts.map(v => v[0]), ys = pts.map(v => v[1]); return [Math.min(...xs) - 3, Math.min(...ys) - 3, Math.max(...xs) + 3, Math.max(...ys) + 3]; };
  const bx = ps.map(box); const grid = new Map(); const S = 50;
  bx.forEach((b, i) => { for (let gx = Math.floor(b[0] / S); gx <= Math.floor(b[2] / S); gx++) for (let gy = Math.floor(b[1] / S); gy <= Math.floor(b[3] / S); gy++) { const k = `${gx},${gy}`; if (!grid.has(k)) grid.set(k, []); grid.get(k).push(i); } });
  return (rect) => {
    const b = box(rect); const seen = new Set(); const out = [];
    for (let gx = Math.floor(b[0] / S); gx <= Math.floor(b[2] / S); gx++) for (let gy = Math.floor(b[1] / S); gy <= Math.floor(b[3] / S); gy++) for (const i of grid.get(`${gx},${gy}`) || []) {
      if (seen.has(i)) continue; seen.add(i);
      const o = bx[i]; if (o[0] <= b[2] && b[0] <= o[2] && o[1] <= b[3] && b[1] <= o[3]) out.push(ps[i].id);
    }
    return out;
  };
}

let nextId = 0;
function proposals(state, B, rnd, mixName, skew, hot, uniq) {
  const { ps, kh, nb, xf, C } = state;
  const mix = MIXES[mixName];
  const kinds = Object.keys(mix); const cum = []; let acc = 0; for (const k of kinds) { acc += mix[k]; cum.push(acc); }
  const pickKind = () => { const u = rnd() * acc; return kinds[cum.findIndex(v => u <= v)]; };
  const hotPs = ps.filter(p => p.x1 <= hot.x1 && p.y1 <= hot.y1);
  const pickP = () => { const pool = (rnd() < skew && hotPs.length) ? hotPs : ps; return pool[Math.floor(rnd() * pool.length)]; };
  const out = [];
  const deeds = [];
  const r3 = v => Math.round(v * 1000) / 1000;
  for (let i = 0; i < B; i++) {
    let kind = pickKind();
    const p = pickP();
    const neigh = r => JSON.stringify(nb(r).filter(id => id !== p.id));
    if (kind === 'transfer') {
      const sh = kh.get(p.khewat);
      if (!sh) { kind = 'in'; } else {
        const s = sh[Math.floor(rnd() * sh.length)];
        const k = 2 + Math.floor(rnd() * 3);
        const deedId = `D${uniq}_${String(nextId++).padStart(6, '0')}`;
        const buyer = rnd() < 0.5 ? sh[Math.floor(rnd() * sh.length)].owner : `B${uniq}_${String(nextId++).padStart(6, '0')}`;
        if (buyer === s.owner) { kind = 'in'; } else {
          const num = s.num, den = String(BigInt(s.den) * BigInt(k));
          deeds.push(['RecordDeed', [deedId, p.khewat, s.owner, buyer, num, den], ID.registration]);
          out.push({ kind, fn: 'TransferShare', args: [p.khewat, s.owner, buyer, num, den, deedId], who: ID.revenue });
          continue;
        }
      }
    }
    const w = p.x1 - p.x0, h = p.y1 - p.y0;
    if (kind === 'adjust') {
      /* boundary adjustment between row neighbours: take back a released strip if there is
       * one (a claim on land another parcel released), otherwise release a strip */
      const east = rnd() < 0.5;
      const q = ps.find(o => o.id !== p.id && Math.abs(o.y0 - p.y0) < 1e-3 && Math.abs(o.y1 - p.y1) < 1e-3 &&
        (east ? (o.x0 >= p.x1 - 1e-3 && o.x0 - p.x1 < 2) : (o.x1 <= p.x0 + 1e-3 && p.x0 - o.x1 < 2)));
      const gap = q ? (east ? q.x0 - p.x1 : p.x0 - q.x1) : 0;
      const dmax = 0.015 * w;
      const nb2 = { ...p };
      if (q && gap > 0.05) { const d = r3(Math.min(gap, dmax)); if (east) nb2.x1 += d; else nb2.x0 -= d; out.push({ kind: 'reclaim', fn: 'RectifyBoundary', args: [p.id, JSON.stringify(xf.ring(nb2)), 'S', neigh(nb2)], who: ID.survey }); }
      else { const d = r3((0.3 + 0.7 * rnd()) * dmax); if (east) nb2.x1 -= d; else nb2.x0 += d; out.push({ kind: 'release', fn: 'RectifyBoundary', args: [p.id, JSON.stringify(xf.ring(nb2)), 'S', neigh(nb2)], who: ID.survey }); }
      continue;
    }
    if (kind === 'out' || kind === 'in') {
      const e = kind === 'out' ? (rnd() < 0.5 ? 'S' : 'N') : ['W', 'E', 'S', 'N'][Math.floor(rnd() * 4)];
      const along = (e === 'W' || e === 'E') ? h : w; const area = w * h;
      const d = r3((0.2 + 0.6 * rnd()) * Math.min(1, 0.015 * area / along / 0.8)) * (kind === 'out' ? 1 : -1);
      const nb2 = { ...p };
      if (e === 'W') nb2.x0 -= d; if (e === 'E') nb2.x1 += d; if (e === 'S') nb2.y0 -= d; if (e === 'N') nb2.y1 += d;
      out.push({ kind, fn: 'RectifyBoundary', args: [p.id, JSON.stringify(xf.ring(nb2)), 'S', neigh(nb2)], who: ID.survey });
    } else if (kind === 'part') {
      const f = r3(0.3 + 0.4 * rnd());
      const [a, b] = w >= h ? [{ ...p, x1: r3(p.x0 + w * f) }, { ...p, x0: r3(p.x0 + w * f) }] : [{ ...p, y1: r3(p.y0 + h * f) }, { ...p, y0: r3(p.y0 + h * f) }];
      const sh = kh.get(p.khewat);
      const kids = [a, b].map(q => ({ khasra: `N${uniq}_${String(nextId++).padStart(6, '0')}`, ring: xf.ring(q), shares: sh }));
      out.push({ kind, fn: 'PartitionParcel', args: [p.id, JSON.stringify(kids), neigh(p)], who: ID.survey });
    } else if (kind === 'amal') {
      const q = ps.find(o => o.id !== p.id && o.khewat === p.khewat && Math.abs(o.y0 - p.y0) < 1e-3 && Math.abs(o.y1 - p.y1) < 1e-3 && (Math.abs(o.x0 - p.x1) < 1e-3 || Math.abs(o.x1 - p.x0) < 1e-3));
      if (!q) { out.push({ kind: 'amal_none', fn: 'QueryParcel', args: [p.id], who: ID.survey }); continue; }
      const m = { x0: Math.min(p.x0, q.x0), y0: p.y0, x1: Math.max(p.x1, q.x1), y1: p.y1 };
      out.push({ kind, fn: 'AmalgamateParcels', args: [p.id, q.id, `N${uniq}_${String(nextId++).padStart(6, '0')}`, JSON.stringify(xf.ring(m)), '', neigh(m)], who: ID.survey });
    } else {
      const lane = C.lanes[Math.floor(rnd() * C.lanes.length)];
      const ww = r3(4 + rnd() * 8), hh = r3(1.5 + rnd() * 2);
      const x = r3(lane.x0 + rnd() * (lane.x1 - lane.x0 - ww)), y = r3(lane.y0 + rnd() * (lane.y1 - lane.y0 - hh));
      const r = { x0: x, y0: y, x1: x + ww, y1: y + hh };
      out.push({ kind: 'reg', fn: 'RegisterParcel', args: [`N${uniq}_${String(nextId++).padStart(6, '0')}`, `KN${uniq}_${String(nextId++).padStart(6, '0')}`, JSON.stringify(xf.ring(r)), '[{"owner":"O1","num":"1","den":"1"}]', 'S', neigh(r)], who: ID.survey });
    }
  }
  return { out, deeds };
}

function maxOverlap(w) {
  const ps = []; for (const [k, e] of w.state) if (k.startsWith('PARCEL~')) { const p = JSON.parse(e.value.toString()); if (p.status === 'ACTIVE') ps.push(p); }
  const bb = ps.map(p => { const l = p.ring.map(G.utm); const xs = l.map(v => v[0]), ys = l.map(v => v[1]); return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)]; });
  const grid = new Map(), S = 60; bb.forEach((b, i) => { for (let gx = Math.floor(b[0] / S); gx <= Math.floor(b[2] / S); gx++) for (let gy = Math.floor(b[1] / S); gy <= Math.floor(b[3] / S); gy++) { const k = `${gx},${gy}`; if (!grid.has(k)) grid.set(k, []); grid.get(k).push(i); } });
  let best = 0, n = 0; const seen = new Set();
  for (const lst of grid.values()) for (let a = 0; a < lst.length; a++) for (let b = a + 1; b < lst.length; b++) {
    const i = lst[a], j = lst[b]; const key = i < j ? `${i},${j}` : `${j},${i}`; if (seen.has(key)) continue; seen.add(key);
    const A = bb[i], Bx = bb[j]; if (A[2] <= Bx[0] || Bx[2] <= A[0] || A[3] <= Bx[1] || Bx[3] <= A[1]) continue;
    const o = G.overlapM2(ps[i].ring, ps[j].ring); if (o > 0.01) n += 1; if (o > best) best = o;
  }
  return { max_m2: best, pairs_over_eps: n };
}
function indexStats(w) {
  let claimRecs = 0, claimEntries = 0, cellRecs = 0, geom = 0, bytes = 0;
  for (const [k, e] of w.state) {
    if (k.startsWith('CLAIM~')) { claimRecs += 1; claimEntries += JSON.parse(e.value.toString()).entries.length; bytes += e.value.length + k.length; }
    else if (k.startsWith('CELL~')) { cellRecs += 1; bytes += e.value.length + k.length; }
    else if (k.startsWith('GEOM~')) { geom += 1; bytes += e.value.length + k.length; }
  }
  return { claim_records: claimRecs, claim_entries: claimEntries, cell_records: cellRecs, geom_records: geom, index_bytes: bytes };
}

async function run(strategyCover, B, seed) {
  nextId = 0;   // v10.1: identifiers restart per run, so a run's proposal stream does not depend on earlier runs in the process
  const [strategy, cover] = strategyCover.split(':');
  const base = await baseWorld(strategy, cover || 'poly', SPEC.corpus, SPEC.theta);
  const w = cloneWorld(base.w); const c = new Contract();
  const rnd = G.rng(seed * 1000003 + B * 101 + SPEC.skew * 1000 + Object.keys(MIXES).indexOf(SPEC.mix) * 7 + SPEC.theta);
  const hot = { x1: base.C.extent.x1 * 0.33, y1: base.C.extent.y1 * 0.33 };
  const rec = { cc_version: I.VERSION, cc_sha256: CC_SHA, tag: SPEC.tag, strategy, cover: cover || 'poly', corpus: SPEC.corpus, theta: SPEC.theta, mix: SPEC.mix, skew: SPEC.skew, B, seed, blocks: SPEC.blocks,
    corpus_parcels: base.C.parcels.length, offered: 0, endorsed: 0, valid: 0, mvcc: 0, phantom: 0, refused: 0, by_kind: {}, read_keys: 0, write_keys: 0, valid_read_keys: 0, valid_write_keys: 0, ms_endorse: 0 };
  rec.trace = [];
  for (let b = 0; b < SPEC.blocks; b++) {
    if (SPEC.compact_every && strategy === 'GKCR' && b > 0 && b % SPEC.compact_every === 0) {
      const cells = [...w.state.entries()].filter(([k, e]) => k.startsWith('CLAIM~') && JSON.parse(e.value.toString()).entries.length > 1).map(([k]) => k.split('~')[2]);
      const ct = []; for (const g of cells) ct.push(await endorse(w, c, 'CompactCell', [g], ID.survey));
      const cc = commitBlock(w, ct);
      rec.compactions = (rec.compactions || 0) + cc.filter(x => x === 'VALID').length;
    }
    const ps = model(w, base.xf); const kh = khewats(w);
    const st = { ps, kh, nb: neighbourIndex(ps, base.xf), xf: base.xf, C: base.C };
    const { out, deeds } = proposals(st, B, rnd, SPEC.mix, SPEC.skew, hot, `${seed}_${b}`);
    if (deeds.length) {   // deeds are recorded in an unmeasured block beforehand
      const ds = []; for (const [fn, args, who] of deeds) ds.push(await endorse(w, c, fn, args, who));
      commitBlock(w, ds);
    }
    const txs = []; const kinds = [];
    const t0 = process.hrtime.bigint();
    for (const p of out) { if (p.fn === 'QueryParcel') { rec.offered += 1; rec.refused += 1; continue; } txs.push(await endorse(w, c, p.fn, p.args, p.who)); kinds.push(p.kind); }
    rec.ms_endorse += Number(process.hrtime.bigint() - t0) / 1e6;
    const codes = commitBlock(w, txs);
    codes.forEach((code, i) => {
      const k = kinds[i]; const bk = rec.by_kind[k] || (rec.by_kind[k] = { offered: 0, valid: 0, mvcc: 0, phantom: 0, refused: 0 });
      bk.offered += 1; rec.offered += 1;
      if (code === 'ENDORSEMENT_FAILURE') {
        rec.refused += 1; bk.refused += 1;
        /* refusal reasons, digits and identifiers masked, for the diagnosis of refusals by kind */
        const why = `${k}: ${String(txs[i].error || '').replace(/[0-9]+(\.[0-9]+)?/g, '#').replace(/parcel [A-Za-z#_]+/g, 'parcel X').slice(0, 90)}`;
        rec.refusal_reasons = rec.refusal_reasons || {}; rec.refusal_reasons[why] = (rec.refusal_reasons[why] || 0) + 1;
        return;
      }
      rec.endorsed += 1; rec.read_keys += txs[i].stub.reads.size + txs[i].stub.ranges.length; rec.write_keys += txs[i].stub.writes.size;
      if (code === 'VALID') { rec.valid += 1; bk.valid += 1; rec.valid_read_keys += txs[i].stub.reads.size; rec.valid_write_keys += txs[i].stub.writes.size; }
      else if (code === 'MVCC_READ_CONFLICT') { rec.mvcc += 1; bk.mvcc += 1; } else { rec.phantom += 1; bk.phantom += 1; }
    });
    if (SPEC.trace) rec.trace.push({ block: b, valid: codes.filter(x => x === 'VALID').length, offered: out.length, ...indexStats(w) });
  }
  rec.yield = rec.valid / rec.offered;
  rec.yield_of_endorsed = rec.endorsed ? rec.valid / rec.endorsed : 0;
  Object.assign(rec, { overlap: maxOverlap(w), index: indexStats(w) });
  return rec;
}

(async () => {
  const dir = path.join(__dirname, 'out', 'bench'); fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `${SPEC.tag}.jsonl`);
  for (const B of SPEC.B) for (const seed of SPEC.seeds) for (const s of SPEC.strategies) {
    const t0 = Date.now();
    const r = await run(s, B, seed);
    r.wall_s = (Date.now() - t0) / 1000;
    fs.appendFileSync(file, JSON.stringify(r) + '\n');
    console.log(`${SPEC.tag} ${s.padEnd(10)} B=${B} seed=${seed} yield=${r.yield.toFixed(3)} valid=${r.valid}/${r.offered} mvcc=${r.mvcc} refused=${r.refused} ovl=${r.overlap.max_m2.toFixed(3)} ${r.wall_s}s`);
  }
})();
