'use strict';
/*
 * Counterexample found while writing the safety proof (Theorem 1, inherited part).
 * A partition may leave siblings overlapping each other by up to eps. If two siblings A and B
 * both overlap a third sibling S and are then amalgamated, the merged parcel inherits both
 * overlaps (2 x 0.009 m2 here). A strategy that never re-tests the merged ring against S
 * commits an overlap above eps. Run against chaincode v1.4.0, v1.4.1, v1.5.0 (snapshots) and the current version.
 * Writes out/probe_sibling_amalgamation.json.
 */
const fs = require('fs');
const path = require('path');
const { World, invoke } = require('./fabric_stub');
const G = require('./geo_util');
const VERSIONS = {
  'v1.4.0': require('../chaincode_v140_snapshot/geokhewat-contract-v1.4.0.js'),
  'v1.4.1': require('../chaincode_v140_snapshot/geokhewat-contract-v1.4.1.js'),
  'v1.5.0': require('../chaincode_v140_snapshot/v1.5.0/geokhewat-contract.js'),
  [`v${require('../chaincode_v14/geokhewat-chaincode/lib/geokhewat-contract.js')._internal.VERSION}`]: require('../chaincode_v14/geokhewat-chaincode/lib/geokhewat-contract.js'),
};
const ID = { admin: { msp: 'SurveyMSP', id: 'x509::/OU=admin/CN=Admin::/CN=ca' }, survey: { msp: 'SurveyMSP' } };
const ROLES = { admin: ['SurveyMSP'], survey: ['SurveyMSP'], registration: ['RegistrationMSP'], revenue: ['RevenueMSP'] };
const SH1 = [{ owner: 'O1', num: '1', den: '1' }];
const J = JSON.stringify;

async function run(Contract, strategy) {
  const w = new World(); const c = new Contract();
  const init = await invoke(w, c, 'InitConfig', [J({ strategy, precision: 8, cover: 'poly', eps: 0.01, roles: ROLES })], ID.admin);
  if (!init.ok) throw new Error(init.error);
  const reg = await invoke(w, c, 'RegisterParcel', ['P', 'K1', J(G.rect(0, 0, 18, 40)), J(SH1), 'SYNTHETIC', '[]'], ID.survey);
  const kids = [['A', G.rect(0, 0, 9, 20)], ['B', G.rect(9, 0, 9, 20)], ['S', G.rect(0, 19.999, 18, 20.001)]]
    .map(([k, ring]) => ({ khasra: k, ring, shares: SH1 }));
  const part = await invoke(w, c, 'PartitionParcel', ['P', J(kids), '[]'], ID.survey);
  let amal = null;
  if (part.ok) amal = await invoke(w, c, 'AmalgamateParcels', ['A', 'B', 'M', J(G.rect(0, 0, 18, 20)), '', '["S"]'], ID.survey);
  const ov = G.maxPairOverlap(w);
  return {
    registration: reg.ok ? 'VALID' : reg.error,
    partition: part.ok ? 'VALID' : `refused: ${part.error}`,
    sibling_overlap_A_S_m2: part.ok ? G.overlapM2(kids[0].ring, kids[2].ring) : null,
    amalgamation: amal === null ? 'not attempted' : amal.ok ? 'VALID' : `refused: ${amal.error}`,
    committed_max_pair_overlap_m2: ov.area,
    violates_I2: ov.area > 0.01,
  };
}

(async () => {
  const out = { probe: 'sibling_amalgamation', eps_m2: 0.01, timestamp_utc: new Date().toISOString(), results: {} };
  for (const [ver, Contract] of Object.entries(VERSIONS)) {
    for (const s of ['GKC', 'GKF', 'GKCR']) {
      const r = await run(Contract, s);
      out.results[`${ver}_${s}`] = r;
      console.log(ver, s.padEnd(5), 'partition:', r.partition.slice(0, 60), '| amalgamation:', String(r.amalgamation).slice(0, 70), '| max overlap', r.committed_max_pair_overlap_m2.toFixed(4), r.violates_I2 ? 'VIOLATION' : 'ok');
    }
  }
  fs.mkdirSync(path.join(__dirname, 'out'), { recursive: true });
  fs.writeFileSync(path.join(__dirname, 'out', 'probe_sibling_amalgamation.json'), J(out, null, 1));
})();
