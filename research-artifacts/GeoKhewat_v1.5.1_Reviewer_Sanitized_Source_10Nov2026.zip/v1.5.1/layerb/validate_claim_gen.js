'use strict';
/* v1.5.1: generates claim-shaped polygon sets (an output ring N, one or two input rings O,
 * and an indexed geometry G) with shared and collinear edges, 1 mm shifts and nudges,
 * slivers, concave and clockwise rings, and records the exact areas computed by
 * lib/exact.js: area(N ∩ O ∩ G), area(N \ ∪O) and area((N \ ∪O) ∩ G).
 * validate_claim.py checks them against GEOS. Writes out/validate_claim_cases.json. */
const E = require('../chaincode_v14/geokhewat-chaincode/lib/exact.js');
const P = a => a.map(([X, Y]) => ({ X, Y }));
let s = 20261021; const rnd = () => { s = (s * 1103515245 + 12345) % 2147483648; return s / 2147483648; };
const rot = (cx, cy, w, h, th) => [[-w / 2, -h / 2], [w / 2, -h / 2], [w / 2, h / 2], [-w / 2, h / 2]].map(([x, y]) => [Math.round(cx + x * Math.cos(th) - y * Math.sin(th)), Math.round(cy + x * Math.sin(th) + y * Math.cos(th))]);
const rq = () => rot(20000 + Math.round(rnd() * 20000), 20000 + Math.round(rnd() * 20000), 2000 + Math.round(rnd() * 30000), 2000 + Math.round(rnd() * 30000), rnd() * Math.PI);
/* move edge k of a quad outward along its normal by d mm (rounded vertices) */
function moveEdge(q, k, d) {
  const a = q[k], b = q[(k + 1) % 4]; const ex = b[0] - a[0], ey = b[1] - a[1]; const L = Math.hypot(ex, ey);
  const nx = ey / L, ny = -ex / L;     // right normal; quads from rot() are CCW, so outward
  const r = q.map(p => p.slice()); r[k] = [Math.round(a[0] + nx * d), Math.round(a[1] + ny * d)]; r[(k + 1) % 4] = [Math.round(b[0] + nx * d), Math.round(b[1] + ny * d)];
  return r;
}
const cases = [];
for (let k = 0; k < 6000; k++) {
  const kind = k % 6; let N, Os, G;
  if (kind === 0) { N = rq(); Os = [rq()]; G = rq(); }
  if (kind === 1) {                       // rectification: one edge moved out or in, G a neighbour across it or random
    const O = rq(); const e = Math.floor(rnd() * 4); const d = Math.round((rnd() - 0.3) * 1500);
    N = moveEdge(O, e, d); Os = [O];
    G = rnd() < 0.6 ? moveEdge(moveEdge(O, e, Math.round(rnd() * 600)), (e + 2) % 4, -Math.round(Math.hypot(O[1][0] - O[2][0], O[1][1] - O[2][1]) * 0.9)) : rq();
  }
  if (kind === 2) {                       // amalgamation: two sources sharing an edge, merged ring, G nearby
    const O1 = rq(); const O2 = [O1[1], [O1[1][0] + (O1[1][0] - O1[0][0]), O1[1][1] + (O1[1][1] - O1[0][1])], [O1[2][0] + (O1[1][0] - O1[0][0]), O1[2][1] + (O1[1][1] - O1[0][1])], O1[2]];
    N = moveEdge([O1[0], O2[1], O2[2], O1[3]], Math.floor(rnd() * 4), Math.round(rnd() * 800)); Os = [O1, O2]; G = rnd() < 0.5 ? O2.map(([x, y]) => [x + Math.round((rnd() - 0.5) * 3000), y + Math.round((rnd() - 0.5) * 3000)]) : rq();
  }
  if (kind === 3) {                       // collinear: G shares an edge line with N and O; or G = O shifted by 1 mm
    const O = rq(); N = moveEdge(O, 0, Math.round(rnd() * 900)); Os = [O];
    G = rnd() < 0.5 ? O.map(([x, y]) => [x + 1, y]) : N.map(p => p.slice());
  }
  if (kind === 4) {                       // sliver: one vertex of N nudged 1 mm off O; G = the neighbour across that vertex's edge
    const O = rq(); N = O.map(p => p.slice()); const v = Math.floor(rnd() * 4); N[v] = [N[v][0] + (rnd() < 0.5 ? 1 : -1), N[v][1] + (rnd() < 0.5 ? 1 : -1)]; Os = [O];
    G = moveEdge(moveEdge(O, v, 400), (v + 2) % 4, -Math.round(Math.hypot(O[1][0] - O[2][0], O[1][1] - O[2][1]) * 0.95));
  }
  if (kind === 5) {                       // concave and clockwise rings, two inputs
    const O1 = rq(); const c = [Math.round((O1[0][0] + O1[2][0]) / 2), Math.round((O1[0][1] + O1[2][1]) / 2)];
    N = [O1[0], O1[1], c, O1[2], O1[3]].reverse(); Os = [rq(), O1]; G = rq();
  }
  cases.push({ kind, N, Os, G,
    claim: E.toNum(E.claimArea2(P(N), Os.map(P), null)) / 2e6,
    claimG: E.toNum(E.claimArea2(P(N), Os.map(P), P(G))) / 2e6,
    triple: E.toNum(E.interAreaK([P(N), P(Os[0]), P(G)])) / 2e6 });
}
require('fs').writeFileSync('out/validate_claim_cases.json', JSON.stringify(cases));
console.log('cases', cases.length);
