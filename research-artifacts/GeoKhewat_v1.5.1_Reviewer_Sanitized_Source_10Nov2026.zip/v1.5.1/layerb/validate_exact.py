"""Checks lib/exact.js against GEOS (Shapely 2.2) on out/validate_exact_cases.json. Integer
millimetre coordinates are exact in IEEE doubles, so GEOS's error is the floating error of its
overlay, far below the 1e-6 m2 tolerance used here. Writes out/validate_exact.json."""
import json
from shapely.geometry import Polygon
C = json.load(open('out/validate_exact_cases.json'))
res = {'cases': 0, 'skipped_invalid': 0, 'mismatch_inter': 0, 'mismatch_diff': 0, 'worst_abs_err_m2': 0.0, 'by_kind': {}}
for c in C:
    a, b = Polygon(c['a']), Polygon(c['b'])
    if not a.is_valid or not b.is_valid: res['skipped_invalid'] += 1; continue
    res['cases'] += 1
    gi = a.intersection(b).area * 1e-6; gd = a.difference(b).area * 1e-6
    e1, e2 = abs(gi - c['inter']), abs(gd - c['aMinusB'])
    res['worst_abs_err_m2'] = max(res['worst_abs_err_m2'], e1, e2)
    if e1 > 1e-6: res['mismatch_inter'] += 1
    if e2 > 1e-6: res['mismatch_diff'] += 1
    k = str(c['kind']); res['by_kind'][k] = res['by_kind'].get(k, 0) + 1
json.dump(res, open('out/validate_exact.json', 'w'), indent=1); print(res)
