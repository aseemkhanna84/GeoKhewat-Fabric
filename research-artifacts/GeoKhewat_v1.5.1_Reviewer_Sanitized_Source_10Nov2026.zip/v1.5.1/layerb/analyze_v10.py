"""Analysis of the Layer B' v10 benchmark (chaincode v1.4.0 under Fabric's validation rule).

Reads out/bench/*.jsonl (one line per strategy x corpus x B x seed run) and writes
out/tables_v10.json plus CSV summaries in out/csv/. Paired statistics compare strategies
run on the same seed: mean difference with a 95 % t interval, the exact Wilcoxon signed-rank
p-value (n = 10), Cliff's delta, and the number of seeds on which the difference is positive.
Nothing is estimated: every number is computed from the run records.
"""
import json, glob, os, math, itertools, csv
from collections import defaultdict
import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out'); os.makedirs(os.path.join(OUT, 'csv'), exist_ok=True)
runs = []
for f in sorted(glob.glob(os.path.join(OUT, 'bench', 'e*.jsonl'))):
    for line in open(f):
        r = json.loads(line); runs.append(r)

def key(r): return f"{r['strategy']}:{r['cover']}"
def group(tag, **flt):
    g = defaultdict(dict)
    for r in runs:
        if r['tag'] != tag: continue
        if any(r.get(k) != v for k, v in flt.items()): continue
        g[key(r)][r['seed']] = r
    return g

def cliff(a, b):
    n = 0
    for x in a:
        for y in b:
            n += int(x > y) - int(x < y)
    return n / (len(a) * len(b))

def paired(g, a, b, metric='yield'):
    seeds = sorted(set(g.get(a, {})) & set(g.get(b, {})))
    if len(seeds) < 2: return None
    x = np.array([g[a][s][metric] for s in seeds]); y = np.array([g[b][s][metric] for s in seeds])
    d = x - y
    m = d.mean(); sd = d.std(ddof=1)
    half = stats.t.ppf(0.975, len(d) - 1) * sd / math.sqrt(len(d)) if sd > 0 else 0.0
    try:
        p = stats.wilcoxon(x, y, method='exact').pvalue if np.any(d != 0) else 1.0
    except ValueError:
        p = float('nan')
    return {'a': a, 'b': b, 'n': len(d), 'diff_mean_pp': 100 * m, 'ci95_pp': [100 * (m - half), 100 * (m + half)],
            'wilcoxon_p': float(p), 'cliffs_delta': cliff(list(x), list(y)), 'positive': int((d > 0).sum()), 'zero': int((d == 0).sum())}

def summary(g):
    out = {}
    for k, by in g.items():
        rs = list(by.values())
        y = np.array([r['yield'] for r in rs])
        out[k] = {'n': len(rs), 'yield_mean': float(y.mean()), 'yield_sd': float(y.std(ddof=1)) if len(y) > 1 else 0.0,
                  'mvcc_per_offered': float(np.mean([r['mvcc'] / r['offered'] for r in rs])),
                  'refused_per_offered': float(np.mean([r['refused'] / r['offered'] for r in rs])),
                  'read_keys_per_endorsed': float(np.mean([r['read_keys'] / max(1, r['endorsed']) for r in rs])),
                  'write_keys_per_endorsed': float(np.mean([r['write_keys'] / max(1, r['endorsed']) for r in rs])),
                  'max_overlap_m2': float(max(r['overlap']['max_m2'] for r in rs)),
                  'runs_with_overlap_over_eps': int(sum(1 for r in rs if r['overlap']['pairs_over_eps'] > 0)),
                  'pairs_over_eps_total': int(sum(r['overlap']['pairs_over_eps'] for r in rs)),
                  'claim_entries_mean': float(np.mean([r['index']['claim_entries'] for r in rs])),
                  'cell_records_mean': float(np.mean([r['index']['cell_records'] for r in rs])),
                  'geom_records_mean': float(np.mean([r['index']['geom_records'] for r in rs])),
                  'index_kib_mean': float(np.mean([r['index']['index_bytes'] for r in rs]) / 1024),
                  'offered_per_run': rs[0]['offered'], 'corpus_parcels': rs[0]['corpus_parcels']}
        kinds = defaultdict(lambda: [0, 0, 0, 0])
        for r in rs:
            for kk, v in r['by_kind'].items():
                kinds[kk][0] += v['offered']; kinds[kk][1] += v['valid']; kinds[kk][2] += v['mvcc'] + v['phantom']; kinds[kk][3] += v['refused']
        out[k]['by_kind'] = {kk: {'offered': v[0], 'valid': v[1], 'conflict': v[2], 'refused': v[3]} for kk, v in kinds.items()}
    return out

T = {'runs': len(runs)}
COMPARE = [('GKCR:poly', 'GKF:poly'), ('GKCR:poly', 'B3:poly'), ('GKC:poly', 'GKF:poly'), ('GKC:poly', 'B3:poly'),
           ('GKCR:poly', 'GKC:poly'), ('GKCR:poly', 'GKCR:bbox'), ('GKF:poly', 'B3:poly'), ('B1:poly', 'GKCR:poly'), ('GKCR:poly', 'B2:poly')]
T['e1'] = {}
for B in [32, 64, 128, 256]:
    g = group('e1_uniform', B=B)
    T['e1'][B] = {'summary': summary(g), 'paired': [p for p in (paired(g, a, b) for a, b in COMPARE) if p]}
g = group('e2_hetero'); T['e2'] = {'summary': summary(g), 'paired': [p for p in (paired(g, a, b) for a, b in COMPARE) if p]}
T['e3'] = {}
for th in [0, 30, 45]:
    g = group(f'e3_rot{th}')
    pr = [('GKCR:poly', 'GKCR:bbox'), ('GKC:poly', 'GKC:bbox'), ('GKF:poly', 'GKF:bbox'), ('GKCR:poly', 'GKF:poly'), ('GKCR:poly', 'B3:poly'), ('GKCR:bbox', 'GKF:bbox')]
    T['e3'][th] = {'summary': summary(g), 'paired': [p for p in (paired(g, a, b) for a, b in pr) if p]}
T['e4'] = {}
for m in ['admin', 'transfer_heavy', 'rectification_heavy', 'partition_heavy', 'survey_campaign', 'registration_burst', 'boundary_adjustment']:
    g = group(f'e4_mix_{m}')
    if not g: continue
    pr = [('GKCR:poly', 'GKF:poly'), ('GKCR:poly', 'B3:poly'), ('GKCR:poly', 'GKC:poly'), ('GKC:poly', 'GKF:poly')]
    T['e4'][m] = {'summary': summary(g), 'paired': [p for p in (paired(g, a, b) for a, b in pr) if p]}
T['e5'] = {}
for f in ['0.25', '0.5', '0.75', '0.9']:
    g = group(f'e5_skew_{f}')
    if not g: continue
    pr = [('GKCR:poly', 'GKF:poly'), ('GKCR:poly', 'B3:poly'), ('GKCR:poly', 'GKC:poly')]
    T['e5'][f] = {'summary': summary(g), 'paired': [p for p in (paired(g, a, b) for a, b in pr) if p]}
T['e7'] = {}
for p in [7, 9]:
    g = group(f'e7_prec{p}')
    if not g: continue
    pr = [('GKCR:poly', 'GKF:poly'), ('GKC:poly', 'GKF:poly'), ('GKCR:poly', 'GKC:poly')]
    T['e7'][p] = {'summary': summary(g), 'paired': [pp for pp in (paired(g, a, b) for a, b in pr) if pp]}
# E6: long history, per-block traces
T['e6'] = {}
for tag in ['e6_history', 'e6_history_compact']:
    for r in runs:
        if r['tag'] != tag: continue
        k = f"{r['strategy']}{'+compact' if tag.endswith('compact') else ''}"
        d = T['e6'].setdefault(k, {'seeds': [], 'trace': {}})
        d['seeds'].append({'seed': r['seed'], 'yield': r['yield'], 'refused': r['refused'], 'mvcc': r['mvcc'], 'by_kind': r['by_kind'],
                           'final_index': r['index'], 'compactions': r.get('compactions', 0), 'max_overlap_m2': r['overlap']['max_m2']})
        for t in r['trace']:
            d['trace'].setdefault(t['block'], []).append(t)
for k, d in T['e6'].items():
    d['trace_mean'] = [{'block': b, 'claim_entries': float(np.mean([t['claim_entries'] for t in ts])), 'geom_records': float(np.mean([t['geom_records'] for t in ts])),
                        'index_kib': float(np.mean([t['index_bytes'] for t in ts]) / 1024), 'valid_frac': float(np.mean([t['valid'] / t['offered'] for t in ts]))}
                       for b, ts in sorted(d['trace'].items())]
    del d['trace']
json.dump(T, open(os.path.join(OUT, 'tables_v10.json'), 'w'), indent=1, default=float)
# flat CSV of every run
with open(os.path.join(OUT, 'csv', 'v10_runs_raw.csv'), 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['tag', 'strategy', 'cover', 'corpus', 'theta', 'mix', 'skew', 'precision_tag', 'B', 'seed', 'blocks', 'offered', 'endorsed', 'valid', 'mvcc', 'phantom', 'refused', 'yield',
                'read_keys', 'write_keys', 'max_overlap_m2', 'pairs_over_eps', 'claim_entries', 'cell_records', 'geom_records', 'index_bytes'])
    for r in runs:
        w.writerow([r['tag'], r['strategy'], r['cover'], r['corpus'], r['theta'], r['mix'], r['skew'], r['tag'] if r['tag'].startswith('e7') else '', r['B'], r['seed'], r['blocks'],
                    r['offered'], r['endorsed'], r['valid'], r['mvcc'], r['phantom'], r['refused'], f"{r['yield']:.6f}", r['read_keys'], r['write_keys'],
                    r['overlap']['max_m2'], r['overlap']['pairs_over_eps'], r['index']['claim_entries'], r['index']['cell_records'], r['index']['geom_records'], r['index']['index_bytes']])
print('runs', len(runs))
for B, v in T['e1'].items():
    print('E1 B', B, {k: round(s['yield_mean'], 4) for k, s in v['summary'].items()})
    for p in v['paired']: print('   ', p['a'], '-', p['b'], f"{p['diff_mean_pp']:+.2f} pp [{p['ci95_pp'][0]:+.2f},{p['ci95_pp'][1]:+.2f}] p={p['wilcoxon_p']:.4g} d={p['cliffs_delta']:.2f} pos={p['positive']}/{p['n']}")
