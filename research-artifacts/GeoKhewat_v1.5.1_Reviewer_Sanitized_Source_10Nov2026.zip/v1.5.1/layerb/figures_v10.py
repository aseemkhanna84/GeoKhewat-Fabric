"""Figures for manuscript v10, generated only from executed results:
out/tables_v10.json, out/bench/*.jsonl, out/census_strips.json, ../fabric_native/results/loadgen.jsonl,
plus chaincode cover functions (via node) for the geometry illustration. 600 dpi PNG, 160 mm wide.
Every figure reads the current chaincode and result files; nothing is typed in."""
import json, os, glob, subprocess, math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyBboxPatch, Polygon as MPoly

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..', 'figs_v10'); os.makedirs(OUT, exist_ok=True)
T = json.load(open(os.path.join(HERE, 'out', 'tables_v10.json')))
W_IN = 160 / 25.4
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 7.5, 'axes.titlesize': 8, 'axes.labelsize': 7.5,
                     'axes.edgecolor': '#52514e', 'axes.linewidth': 0.6, 'xtick.color': '#52514e', 'ytick.color': '#52514e',
                     'axes.spines.top': False, 'axes.spines.right': False, 'grid.color': '#e4e3df', 'grid.linewidth': 0.5,
                     'legend.frameon': False, 'savefig.dpi': 600, 'figure.dpi': 150})
INK, INK2 = '#0b0b0b', '#52514e'
COL = {'GKCR:poly': '#2a78d6', 'GKC:poly': '#eb6834', 'GKF:poly': '#1baf7a', 'B3:poly': '#eda100', 'B2:poly': '#e87ba4', 'GKCR:bbox': '#6250d6', 'B1:poly': '#8a8985'}
MK = {'GKCR:poly': 'o', 'GKC:poly': 's', 'GKF:poly': '^', 'B3:poly': 'D', 'B2:poly': 'v', 'GKCR:bbox': 'P', 'B1:poly': 'x'}
LAB = {'GKCR:poly': 'GK-CR (claim, reclaimable)', 'GKC:poly': 'GK-C (claim, append-only)', 'GKF:poly': 'GK-F (footprint)', 'B3:poly': 'B3 (parcel + neighbours)',
       'B2:poly': 'B2 (registry key)', 'GKCR:bbox': 'GK-CR, box covers', 'B1:poly': 'B1 (no on-chain check)'}
def save(fig, name):
    fig.savefig(os.path.join(OUT, name), dpi=600, bbox_inches='tight', facecolor='white'); plt.close(fig)

def runs(tag):
    rs = []
    for line in open(os.path.join(HERE, 'out', 'bench', f'{tag}.jsonl')): rs.append(json.loads(line))
    return rs
def ci(vals):
    v = np.array(vals); m = v.mean(); h = 2.262 * v.std(ddof=1) / math.sqrt(len(v)) if len(v) > 1 else 0
    return m, h

# ---------------------------------------------------------------- Fig. 3 yield vs B
def fig_yield():
    rs = runs('e1_uniform'); Bs = [32, 64, 128, 256]
    fig, (a, b) = plt.subplots(1, 2, figsize=(W_IN, 2.6), gridspec_kw={'width_ratios': [1.35, 1]})
    for s in ['B1:poly', 'GKCR:poly', 'GKC:poly', 'GKF:poly', 'B3:poly', 'B2:poly']:
        ms, hs = zip(*[ci([r['yield'] for r in rs if f"{r['strategy']}:{r['cover']}" == s and r['B'] == B]) for B in Bs])
        ls = '--' if s == 'B1:poly' else '-'
        a.errorbar(Bs, 100 * np.array(ms), yerr=100 * np.array(hs), color=COL[s], marker=MK[s], ms=4, lw=1.4, ls=ls, capsize=2, label=LAB[s])
    a.set_xscale('log', base=2); a.set_xticks(Bs); a.set_xticklabels([str(x) for x in Bs])
    a.set_xlabel('Proposals endorsed against one state (block size B)'); a.set_ylabel('Commit yield (% of offered)')
    a.set_ylim(0, 100); a.grid(axis='y'); a.set_title('(a) Commit yield, uniform 576-parcel corpus', loc='left')
    a.legend(fontsize=6.0, loc='lower left', bbox_to_anchor=(0.0, 0.29), ncol=1)
    # (b) runs with committed overlap > eps
    width = 0.18
    for k, s in enumerate(['B1:poly', 'B3:poly', 'GKF:poly', 'GKC:poly', 'GKCR:poly']):
        vals = [sum(1 for r in rs if f"{r['strategy']}:{r['cover']}" == s and r['B'] == B and r['overlap']['pairs_over_eps'] > 0) for B in Bs]
        b.bar(np.arange(4) + (k - 2) * width, vals, width * 0.9, color=COL[s], label=LAB[s].split(' (')[0])
    b.set_xticks(range(4)); b.set_xticklabels([str(x) for x in Bs]); b.set_ylim(0, 10.5)
    b.set_xlabel('Block size B'); b.set_ylabel('Runs (of 10) ending with an overlap > 0.01 m²')
    b.set_title('(b) Committed overlaps', loc='left'); b.legend(fontsize=6.2, loc='upper left'); b.grid(axis='y')
    b.text(0.03, 0.40, 'GK-F, GK-C, GK-CR:\n0 runs at every B', transform=b.transAxes, ha='left', fontsize=6.0, color=INK2)
    fig.tight_layout(); save(fig, 'fig3_yield_overlap.png')

# ---------------------------------------------------------------- Fig. 4 forest plot
def fig_forest():
    rows = []
    def add(label, plist):
        d = {(p['a'], p['b']): p for p in plist}
        rows.append((label, d.get(('GKCR:poly', 'GKF:poly')), d.get(('GKCR:poly', 'B3:poly'))))
    for B in ['32', '64', '128', '256']: add(f'Uniform, B = {B}', T['e1'][B]['paired'])
    add('Heterogeneous widths, B = 128', T['e2']['paired'])
    for th in ['30', '45']: add(f'Rotated {th}°, B = 128', T['e3'][th]['paired'])
    names = {'transfer_heavy': 'Transfer-heavy mix', 'rectification_heavy': 'Rectification-heavy mix', 'partition_heavy': 'Partition-heavy mix',
             'survey_campaign': 'Survey campaign mix', 'registration_burst': 'Registration burst', 'boundary_adjustment': 'Boundary adjustment'}
    for m, lab in names.items(): add(lab, T['e4'][m]['paired'])
    for f in ['0.5', '0.9']: add(f'{int(float(f) * 100)}% of proposals in hot spot', T['e5'][f]['paired'])
    fig, ax = plt.subplots(figsize=(W_IN, 3.6))
    y = np.arange(len(rows))[::-1]
    for i, (lab, p1, p2) in enumerate(rows):
        for p, off, s in [(p1, 0.15, 'GKF:poly'), (p2, -0.15, 'B3:poly')]:
            if not p: continue
            ax.plot(p['ci95_pp'], [y[i] + off] * 2, color=COL[s], lw=1.6)
            ax.plot(p['diff_mean_pp'], y[i] + off, marker=MK[s], color=COL[s], ms=4)
    ax.set_yticks(y); ax.set_yticklabels([r[0] for r in rows]); ax.axvline(0, color=INK2, lw=0.6)
    ax.set_xlabel('Paired difference in commit yield, GK-CR minus baseline (percentage points, mean and 95% CI, 10 seeds)')
    ax.plot([], [], color=COL['GKF:poly'], marker='^', label='GK-CR − GK-F (footprint)'); ax.plot([], [], color=COL['B3:poly'], marker='D', label='GK-CR − B3 (parcel + neighbours)')
    ax.legend(loc='upper right', fontsize=6.5); ax.grid(axis='x'); ax.set_xlim(0, 33)
    fig.tight_layout(); save(fig, 'fig4_paired_differences.png')

# ---------------------------------------------------------------- Fig. 5 GKC-P
def fig_gkcp():
    C = json.load(open(os.path.join(HERE, 'out', 'census_strips.json')))
    fig, (a, b) = plt.subplots(1, 2, figsize=(W_IN, 2.5), gridspec_kw={'width_ratios': [1.2, 1]})
    Ls = [100, 250, 500, 1000, 1500]
    for deg, col, mk in [(0, '#1baf7a', '^'), (45, '#2a78d6', 'o')]:
        bb = [next(r['cells_bbox'] for r in C if r['length_m'] == L and r['bearing_deg'] == deg and r['width_m'] == 8) for L in Ls]
        pp = [next(r['cells_poly'] for r in C if r['length_m'] == L and r['bearing_deg'] == deg and r['width_m'] == 8) for L in Ls]
        a.plot(Ls, bb, color=col, ls='--', marker=mk, ms=3.5, lw=1.2, label=f'bearing {deg}°, bounding-box cover')
        a.plot(Ls, pp, color=col, ls='-', marker=mk, ms=3.5, lw=1.4, label=f'bearing {deg}°, polygon cover')
    a.axhline(256, color='#e34948', lw=0.8); a.text(1500, 290, 'cover bound (256 cells)', color='#e34948', fontsize=6.0, ha='right')
    a.set_yscale('log'); a.set_xlabel('Length of an 8 m wide strip (m)'); a.set_ylabel('Geohash cells in the cover (precision 8)')
    a.set_title('(a) Keys declared for one claim', loc='left'); a.legend(fontsize=5.6, loc='lower right'); a.grid(axis='y', which='both')
    ths = ['0', '30', '45']; width = 0.25
    for k, (s, lab) in enumerate([('GKF', 'GK-F'), ('GKC', 'GK-C'), ('GKCR', 'GK-CR')]):
        vals, errs = [], []
        for th in ths:
            p = next(p for p in T['e3'][th]['paired'] if p['a'] == f'{s}:poly' and p['b'] == f'{s}:bbox')
            vals.append(p['diff_mean_pp']); errs.append((p['ci95_pp'][1] - p['ci95_pp'][0]) / 2)
        col = {'GKF': COL['GKF:poly'], 'GKC': COL['GKC:poly'], 'GKCR': COL['GKCR:poly']}[s]
        b.bar(np.arange(3) + (k - 1) * width, vals, width * 0.9, yerr=errs, color=col, capsize=2, label=lab, error_kw={'lw': 0.7})
    b.set_xticks(range(3)); b.set_xticklabels([f'{t}°' for t in ths]); b.axhline(0, color=INK2, lw=0.6)
    b.set_xlabel('Rotation of the 576-parcel corpus'); b.set_ylabel('Yield gain, polygon − box covers (pp)')
    b.set_title('(b) Effect on commit yield, B = 128', loc='left'); b.legend(fontsize=6.2, loc='upper left'); b.grid(axis='y')
    fig.tight_layout(); save(fig, 'fig5_polygon_covers.png')

# ---------------------------------------------------------------- Fig. 6 GKC-R
def fig_gkcr():
    rs = runs('e6_history') + runs('e6_history_compact')
    fig, (a, b) = plt.subplots(1, 2, figsize=(W_IN, 2.5))
    series = [('GKC', 'e6_history', COL['GKC:poly'], 'GK-C (append-only)'), ('GKCR', 'e6_history', COL['GKCR:poly'], 'GK-CR'), ('GKCR', 'e6_history_compact', '#6250d6', 'GK-CR + CompactCell every 10 blocks')]
    for s, tag, col, lab in series:
        sel = [r for r in rs if r['strategy'] == s and r['tag'] == tag]
        vf = np.mean([[t['valid'] / t['offered'] for t in r['trace']] for r in sel], axis=0)
        a.plot(np.arange(1, len(vf) + 1), 100 * vf, color=col, lw=1.3, label=lab)
        ce = np.mean([[t['claim_entries'] for t in r['trace']] for r in sel], axis=0)
        gr = np.mean([[t['geom_records'] for t in r['trace']] for r in sel], axis=0)
        sl = {'GK-C (append-only)': 'GK-C', 'GK-CR': 'GK-CR', 'GK-CR + CompactCell every 10 blocks': 'GK-CR + compaction'}[lab]
        b.plot(np.arange(1, len(ce) + 1), ce / 1000, color=col, lw=1.3, label=f'{sl}: entries')
        b.plot(np.arange(1, len(gr) + 1), gr / 1000, color=col, lw=1.0, ls=':', label=f'{sl}: geometry')
    a.set_xlabel('Block (64 proposals, boundary-adjustment mix)'); a.set_ylabel('Committed in block (% of offered)')
    a.set_ylim(50, 100); a.grid(axis='y'); a.set_title('(a) Yield as released land accumulates', loc='left'); a.legend(fontsize=6, loc='lower left')
    b.set_xlabel('Block'); b.set_ylabel('Index size (thousands)'); b.grid(axis='y'); b.set_title('(b) Index growth (mean of 3 seeds)', loc='left')
    b.legend(fontsize=5.0, loc='center right', bbox_to_anchor=(1.0, 0.56), ncol=2, columnspacing=0.8, handlelength=1.6)
    fig.tight_layout(); save(fig, 'fig6_reclaim_index.png')

# ---------------------------------------------------------------- Fig. 2 geometry illustration
def fig_geometry():
    js = r"""
    const I = require('/home/claude/gk10/chaincode_v14/geokhewat-chaincode/lib/geokhewat-contract.js')._internal;
    const G = require('/home/claude/gk10/layerb/geo_util');
    const th = 30 * Math.PI / 180, rot = ([x, y]) => [x * Math.cos(th) - y * Math.sin(th), x * Math.sin(th) + y * Math.cos(th)];
    const old = [[0,0],[60,0],[60,40],[0,40]].map(rot), neu = [[0,0],[60,0],[60,40.9],[0,40.9]].map(rot);
    const rO = G.ringLL(old), rN = G.ringLL(neu); const o = I.originOf(rO.slice(0,-1));
    const claim = I.claimOf([rN],[rO],o);
    const foot = [...new Set([...I.cellsOf([I.mmPath(rO,o)],o,8,'poly'), ...I.cellsOf([I.mmPath(rN,o)],o,8,'poly')])];
    const cb = I.claimCellsOf([claim],o,8,'bbox'), cp = I.claimCellsOf([claim],o,8,'poly');
    const rect = g => { const r = I.geohashRect(g); return [[r[0],r[1]],[r[2],r[1]],[r[2],r[3]],[r[0],r[3]]].map(p => { const u = G.utm(p); return [u[0]-G.X0, u[1]-G.Y0]; }); };
    console.log(JSON.stringify({ old, neu, foot: foot.map(rect), cb: cb.map(rect), cp: cp.map(rect), n: [foot.length, cb.length, cp.length] }));
    """
    d = json.loads(subprocess.check_output(['node', '-e', js], cwd=HERE))
    fig, axs = plt.subplots(1, 3, figsize=(W_IN, 2.3), sharex=True, sharey=True)
    titles = [f"(a) GK-F footprints:\n{d['n'][0]} cells", f"(b) Claim, box cover:\n{d['n'][1]} cells", f"(c) Claim, polygon cover:\n{d['n'][2]} cells"]
    for ax, cells, t in zip(axs, [d['foot'], d['cb'], d['cp']], titles):
        for c in cells: ax.add_patch(MPoly(c, closed=True, fc='#cfe0f6', ec='#2a78d6', lw=0.5))
        ax.add_patch(MPoly(d['old'], closed=True, fc='none', ec=INK, lw=1.0))
        strip = [d['old'][3], d['old'][2], d['neu'][2], d['neu'][3]]
        ax.add_patch(MPoly(strip, closed=True, fc='#eb6834', ec='#eb6834', lw=0.6))
        ax.set_title(t, loc='left', fontsize=6.6); ax.set_aspect('equal'); ax.set_xticks([]); ax.set_yticks([])
        for sp in ax.spines.values(): sp.set_visible(False)
    allx = [p[0] for c in d['foot'] for p in c]; ally = [p[1] for c in d['foot'] for p in c]
    axs[0].set_xlim(min(allx) - 2, max(allx) + 2); axs[0].set_ylim(min(ally) - 2, max(ally) + 2)
    axs[0].text(0.0, -0.08, 'Black: parcel before; orange: 0.9 m strip claimed by an outward rectification; blue: geohash cells (precision 8) declared as keys.',
                transform=axs[0].transAxes, fontsize=6, color=INK2)
    fig.tight_layout(); save(fig, 'fig2_claim_cells.png')

# ---------------------------------------------------------------- Fig. 1 evidence map
def fig_evidence():
    import textwrap
    V = json.load(open(os.path.join(HERE, '..', 'manuscript_v10', 'values_v10.json')))
    fig, ax = plt.subplots(figsize=(W_IN, 3.9)); ax.set_xlim(0, 100); ax.set_ylim(0, 78); ax.axis('off')
    cols = [('Fabric 2.5.16 network (one host)', 1, '#2a78d6'), ("Local: Fabric validation rule", 34.5, '#1baf7a'), ('Real record: Bolina', 68, '#eb6834')]
    for lab, x, c in cols:
        ax.add_patch(FancyBboxPatch((x, 70), 31, 5.5, boxstyle='round,pad=0.3', fc=c, ec='none'))
        ax.text(x + 15.5, 72.75, lab, ha='center', va='center', color='white', fontsize=6.2, weight='bold')
    W = 36
    items = [
        (1, [f"v1.1.0, earlier GitHub Actions run (two organisations, CouchDB): lifecycle, 11/11 functional checks, one MVCC_READ_CONFLICT",
             f"v1.3.0 on the native network: {V['v13_replay_reproduced']} of {V['v13_replay_total']} audit defects reproduced",
             f"v{V['cc_version']}: three organisations, Raft, LevelDB, TLS; {V['n_fabric_tests']}/{V['n_fabric_tests']} tests passed; interleavings 20/20; load generator ({V['n_loadgen_runs']} runs) and Caliper ({V['n_caliper_rounds']} rounds)"]),
        (34.5, [f"v1.3.0 audit: {V['audit_probes']} probes, {V['audit_defects']} defects",
                f"v{V['cc_version']}: {V['n_stub_tests']}/{V['n_stub_tests']} tests; property test {V['prop_runs']} runs, {V['prop_proposals']} proposals, {V['prop_query_checks']} cell-query checks",
                f"v{V['cc_version']} benchmark: {V['n_stub_runs']} runs; 7 strategies, 2 corpora, rotations, 7 mixes, skew, precision, 40-block histories"]),
        (68, [f"2023–24 Jamabandi attributes: {V['real_interests']} fractions, exact sum = 1 (computed)",
              'Khasra 207 located on the sheet in image space only',
              'Geometry NOT DERIVED: no verified ground-control points']),
    ]
    for x, texts in items:
        y = 68
        for t in texts:
            lines = textwrap.wrap(t, W); h = 2.6 * len(lines) + 2.6
            y -= h + 1.6
            ax.add_patch(FancyBboxPatch((x, y), 31, h, boxstyle='round,pad=0.3', fc='#f4f3f0', ec='#c3c2b7', lw=0.6))
            ax.text(x + 15.5, y + h / 2, '\n'.join(lines), ha='center', va='center', fontsize=5.3, color=INK, linespacing=1.25)
    ax.text(50, 8, textwrap.fill('Not executed: multi-host deployment, CouchDB state with the revised chaincode, georeferenced real geometry, production workloads.', 95),
            ha='center', va='center', fontsize=5.8, color='#c0392b')
    ax.text(50, 2.5, 'Sections 7.1–7.6: local layer (network tests in 7.2); Section 7.7: network; Section 7.8: real record.', ha='center', va='center', fontsize=5.8, color=INK2)
    save(fig, 'fig1_evidence_map.png')

# ---------------------------------------------------------------- Fig. 7 Fabric performance
def fig_fabric():
    f = os.path.join(HERE, '..', 'fabric_native', 'results', 'loadgen.jsonl')
    if not os.path.exists(f): print('no loadgen results yet'); return
    L = [json.loads(l) for l in open(f) if l.strip()]
    if not L: return
    fig, axs = plt.subplots(1, 3, figsize=(W_IN, 2.4))
    for s, key in [('gkcr', 'GKCR:poly'), ('gkc', 'GKC:poly'), ('gkf', 'GKF:poly'), ('b3', 'B3:poly'), ('b2', 'B2:poly')]:
        for wl, ax_tp in [('reg', 0), ('mixed', 1)]:
            rates = sorted({r['rate'] for r in L if r['cc'] == s and r['workload'] == wl})
            if not rates: continue
            tp = [[r['committed_tps'] for r in L if r['cc'] == s and r['workload'] == wl and r['rate'] == q] for q in rates]
            md = [float(np.median(v)) for v in tp]
            axs[ax_tp].errorbar(rates, md, yerr=[[m - min(v) for m, v in zip(md, tp)], [max(v) - m for m, v in zip(md, tp)]], color=COL[key], marker=MK[key], ms=3.5, lw=1.2, capsize=2, label=LAB[key].split(' (')[0])
        rates = sorted({r['rate'] for r in L if r['cc'] == s and r['workload'] == 'reg'})
        p95 = [float(np.median([r['latency_ms_valid']['p95'] for r in L if r['cc'] == s and r['workload'] == 'reg' and r['rate'] == q and r['latency_ms_valid']['p95']])) / 1000 for q in rates]
        axs[2].plot(rates, p95, color=COL[key], marker=MK[key], ms=3.5, lw=1.2, label=LAB[key].split(' (')[0])
    for ax in axs[:2]:
        lim = max(ax.get_xlim()[1], 1); ax.plot([0, lim], [0, lim], color='#c3c2b7', lw=0.6, ls='--')
    axs[0].set_title('(a) Disjoint registrations', loc='left'); axs[1].set_title('(b) Contended edits, 64 parcels', loc='left'); axs[2].set_title('(c) p95 latency, registrations', loc='left')
    for ax in axs[:2]: ax.set_xlabel('Offered load (tx/s)'); ax.set_ylabel('Committed (tx/s)'); ax.grid(axis='y')
    axs[2].set_xlabel('Offered load (tx/s)'); axs[2].set_ylabel('p95 end-to-end latency (s)'); axs[2].grid(axis='y')
    axs[1].legend(fontsize=5.8, loc='upper left')
    fig.tight_layout(); save(fig, 'fig7_fabric_performance.png')

# ---------------------------------------------------------------- Fig. 8 real record
def fig_real():
    from PIL import Image
    R = json.load(open(os.path.join(HERE, '..', 'realcase', 'real_case_results.json')))
    sheet = Image.open(os.path.join(HERE, '..', 'inputs', 'bolina_map.jpg')).convert('RGB')
    crop = Image.open(os.path.join(HERE, '..', 'inputs', 'khasra207_crop.png')).convert('RGB')
    fig = plt.figure(figsize=(W_IN, 3.0))
    g = fig.add_gridspec(1, 3, width_ratios=[1.0, 1.0, 0.75], wspace=0.32)
    a = fig.add_subplot(g[0]); a.imshow(sheet); a.axis('off'); a.set_title('(a) Aks Shajra, Hadbast 200,\nas supplied', loc='left', fontsize=6.4)
    b = fig.add_subplot(g[1]); b.imshow(crop); b.axis('off'); b.set_title('(b) Khasra 207 marked,\nimage space only', loc='left', fontsize=6.4)
    c = fig.add_subplot(g[2])
    own = sorted(R['ground_m2'].items(), key=lambda kv: -kv[1])
    c.barh(range(len(own))[::-1], [v for _, v in own], color='#2a78d6', height=0.7)
    c.set_yticks(range(len(own))[::-1]); c.set_yticklabels([k for k, _ in own], fontsize=5.2)
    c.set_xlabel('Share of 2756.92 m² (m²)', fontsize=6.2); c.grid(axis='x'); c.tick_params(axis='x', labelsize=5.6)
    c.set_title(f"(c) {R['interests']} interests,\nexact sum {R['sum']}", loc='left', fontsize=6.4)
    save(fig, 'fig8_bolina_record.png')

if __name__ == '__main__':
    import sys
    which = sys.argv[1:] or ['yield', 'forest', 'gkcp', 'gkcr', 'geometry', 'evidence', 'fabric', 'real']
    for w in which: globals()[f'fig_{w}']()
    print(sorted(os.listdir(OUT)))
