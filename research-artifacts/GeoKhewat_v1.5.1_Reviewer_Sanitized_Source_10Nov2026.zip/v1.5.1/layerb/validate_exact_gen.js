'use strict';
/* Generates random polygon pairs with integer mm coordinates (rotated rectangles, shared and
 * collinear edges, sub-millimetre shifts, slivers, concave rings) and records the exact
 * intersection area and claim area computed by lib/exact.js; validate_exact.py checks them
 * against GEOS. Writes out/validate_exact_cases.json. */
const E = require('../chaincode_v14/geokhewat-chaincode/lib/exact.js');
const P = a => a.map(([X, Y]) => ({ X, Y }));
let s = 20261020; const rnd = () => { s = (s * 1103515245 + 12345) % 2147483648; return s / 2147483648; };
const rq = () => { const cx = Math.round(rnd() * 60000), cy = Math.round(rnd() * 60000), w = 500 + Math.round(rnd() * 40000), h = 500 + Math.round(rnd() * 40000), th = rnd() * Math.PI;
  return [[-w / 2, -h / 2], [w / 2, -h / 2], [w / 2, h / 2], [-w / 2, h / 2]].map(([x, y]) => [Math.round(cx + x * Math.cos(th) - y * Math.sin(th)), Math.round(cy + x * Math.sin(th) + y * Math.cos(th))]); };
const cases = [];
for (let k = 0; k < 5000; k++) {
  let a = rq(), b = rq(); const kind = k % 6;
  if (kind === 1) b = [a[1], [a[1][0] + 20000, a[1][1] + 3], [a[2][0] + 20000, a[2][1] - 5], a[2]];        // shared edge, opposite direction
  if (kind === 2) b = a.map(([x, y]) => [x + 1, y]);                                                          // 1 mm shift
  if (kind === 3) { const m = [Math.round((a[0][0] + a[1][0]) / 2), Math.round((a[0][1] + a[1][1]) / 2)]; b = [a[0], m, a[2], a[3]]; }
  if (kind === 4) { b = a.map(p => p.slice()); b[2] = [b[2][0] + (rnd() < 0.5 ? 1 : -1), b[2][1] + (rnd() < 0.5 ? 1 : -1)]; }   // vertex nudged 1 mm (sliver)
  if (kind === 5) { const c = [Math.round((a[0][0] + a[2][0]) / 2), Math.round((a[0][1] + a[2][1]) / 2)]; b = [a[0], a[1], c, a[2], a[3]].reverse(); }   // concave, clockwise input
  cases.push({ kind, a, b, inter: E.interAreaM2(P(a), P(b)), aMinusB: Number(E.area2(P(a)) < 0n ? -E.area2(P(a)) : E.area2(P(a))) / 2e6 - E.interAreaM2(P(a), P(b)) });
}
require('fs').writeFileSync('out/validate_exact_cases.json', JSON.stringify(cases));
console.log('cases', cases.length);
