'use strict';
/* Corpus statistics for the manuscript: rebuilds the two corpora exactly as bench_cc.js does
 * (same generator code and seed) and reports counts and areas. Writes out/corpus_stats.json. */
const fs = require('fs');
const G = require('./geo_util');
const WIDTH_CLASSES = [[7, 12, 0.20], [16, 30, 0.30], [55, 70, 0.35], [100, 135, 0.15]];
function buildCorpus(kind, rnd) {   // copied verbatim from bench_cc.js
  const parcels = []; const lanes = []; const ROWS = 24, H = 30, LANE = 4, PATH = 4;
  let y = 0;
  for (let r = 0; r < ROWS; r++) {
    let x = 0, inBlock = 0, block = 0;
    let cls = null;
    if (kind === 'hetero') { let u = rnd(), acc = 0; for (const c of WIDTH_CLASSES) { acc += c[2]; if (u <= acc) { cls = c; break; } } cls = cls || WIDTH_CLASSES[3]; }
    const target = 980;
    let c = 0;
    while (true) {
      const w = kind === 'hetero' ? Math.round((cls[0] + rnd() * (cls[1] - cls[0])) * 100) / 100 : 40;
      if (x + w > target + 1e-9) break;
      parcels.push({ id: `R${r}C${c}`, khewat: `K${r}_${block}`, x0: x, y0: y, x1: x + w, y1: y + H, row: r, col: c });
      x += w; c += 1; inBlock += 1;
      if (inBlock === 4) { inBlock = 0; block += 1; x += PATH; }
    }
    lanes.push({ y0: y + H, y1: y + H + LANE, x0: 0, x1: x });
    y += H + LANE;
  }
  return { parcels, lanes, extent: { x1: 990, y1: y } };
}
const out = {};
for (const kind of ['uniform', 'hetero']) {
  const C = buildCorpus(kind, G.rng(20261019));
  const a = C.parcels.map(p => (p.x1 - p.x0) * (p.y1 - p.y0)).sort((x, y) => x - y);
  const kh = new Set(C.parcels.map(p => p.khewat));
  const elong = C.parcels.map(p => Math.max(p.x1 - p.x0, p.y1 - p.y0) / Math.min(p.x1 - p.x0, p.y1 - p.y0));
  out[kind] = { parcels: C.parcels.length, holdings: kh.size, area_min_m2: a[0], area_median_m2: a[Math.floor(a.length / 2)], area_max_m2: a[a.length - 1],
    total_ha: a.reduce((s, v) => s + v, 0) / 1e4, extent_m: [C.extent.x1, C.extent.y1], max_elongation: Math.max(...elong) };
}
out.anchor_utm43n = [G.X0, G.Y0]; out.anchor_lonlat = G.ll([G.X0, G.Y0]);
fs.writeFileSync('out/corpus_stats.json', JSON.stringify(out, null, 1));
console.log(JSON.stringify(out));
