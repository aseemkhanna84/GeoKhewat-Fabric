'use strict';
/*
 * Counterexample found by auditing the rotated-corpus benchmark (45 degrees, GK-C, seed 1):
 * integer-lattice clipping rounds computed intersection points to the 1 mm lattice, so a
 * sliver thinner than the lattice can vanish. Two diagonal parcels R7C13 and R7C14 of that
 * run are replayed here, with their rings exactly as committed (mm offsets in UTM 43N).
 * Step 1 registers Q; step 2 registers O, whose true overlap with Q is 0.0105 m2 (> eps);
 * step 3 rotates O's shared edge by less than 1 mm about one end (the transaction committed in
 * block 5), which doubles the overlap. Run against v1.4.1 (Clipper), v1.5.0 and the current version (exact).
 * Writes out/probe_lattice_sliver.json.
 */
const fs = require('fs');
const path = require('path');
const proj4 = require('proj4');
const { World, invoke } = require('./fabric_stub');
const E = require('../chaincode_v14/geokhewat-chaincode/lib/exact.js');
proj4.defs('EPSG:32643', '+proj=utm +zone=43 +datum=WGS84 +units=m +no_defs');
const VERSIONS = {
  'v1.4.1': require('../chaincode_v140_snapshot/geokhewat-contract-v1.4.1.js'),
  'v1.5.0': require('../chaincode_v140_snapshot/v1.5.0/geokhewat-contract.js'),
  [`v${require('../chaincode_v14/geokhewat-chaincode/lib/geokhewat-contract.js')._internal.VERSION}`]: require('../chaincode_v14/geokhewat-chaincode/lib/geokhewat-contract.js'),
};
const ORIGIN = [600641, 3450313];
const ring = pts => { const r = pts.map(([X, Y]) => proj4('EPSG:32643', 'EPSG:4326', [ORIGIN[0] + X / 1000, ORIGIN[1] + Y / 1000])); r.push([...r[0]]); return r; };
const MM = { O: [[619, 707], [28904, 28991], [7442, 50452], [-20842, 22168]], N: [[619, 707], [28904, 28991], [7677, 50218], [-20607, 21933]],
  Q: [[28655, 29239], [56940, 57523], [35726, 78737], [7442, 50452]] };
const P = a => a.map(([X, Y]) => ({ X, Y }));
const exact = { O_Q: E.interAreaM2(P(MM.O), P(MM.Q)), N_Q: E.interAreaM2(P(MM.N), P(MM.Q)), N_minus_O: Number(E.area2(P(MM.N))) / 2e6 - E.interAreaM2(P(MM.N), P(MM.O)) };
const ID = { admin: { msp: 'SurveyMSP', id: 'x509::/OU=admin/CN=Admin::/CN=ca' }, survey: { msp: 'SurveyMSP' } };
const ROLES = { admin: ['SurveyMSP'], survey: ['SurveyMSP'], registration: ['RegistrationMSP'], revenue: ['RevenueMSP'] };
const SH = '[{"owner":"O1","num":"1","den":"1"}]';
const J = JSON.stringify;
(async () => {
  const out = { probe: 'lattice_sliver', eps_m2: 0.01, exact_m2: exact, timestamp_utc: new Date().toISOString(), results: {} };
  for (const [ver, C] of Object.entries(VERSIONS)) for (const s of ['GKC', 'GKCR', 'GKF']) {
    const w = new World(), c = new C();
    await invoke(w, c, 'InitConfig', [J({ strategy: s, precision: 8, cover: 'poly', eps: 0.01, roles: ROLES })], ID.admin);
    const rq = await invoke(w, c, 'RegisterParcel', ['Q', 'KQ', J(ring(MM.Q)), SH, 'S', '[]'], ID.survey);
    const ro = await invoke(w, c, 'RegisterParcel', ['O', 'KO', J(ring(MM.O)), SH, 'S', '["Q"]'], ID.survey);
    const rn = ro.ok ? await invoke(w, c, 'RectifyBoundary', ['O', J(ring(MM.N)), 'S', '["Q"]'], ID.survey) : null;
    const st = id => { const e = w.state.get(`PARCEL~${id}`); return e ? JSON.parse(e.value.toString()) : null; };
    const o = st('O'), q = st('Q');
    const committed = o && q ? E.interAreaM2(P(o.ring.slice(0, -1).map(p => proj4('EPSG:4326', 'EPSG:32643', p)).map(([x, y]) => [Math.round((x - ORIGIN[0]) * 1000), Math.round((y - ORIGIN[1]) * 1000)])),
      P(q.ring.slice(0, -1).map(p => proj4('EPSG:4326', 'EPSG:32643', p)).map(([x, y]) => [Math.round((x - ORIGIN[0]) * 1000), Math.round((y - ORIGIN[1]) * 1000)]))) : 0;
    const r = { register_Q: rq.ok ? 'VALID' : rq.error, register_O: ro.ok ? 'VALID' : `refused: ${ro.error}`, rectify_O: rn === null ? 'not attempted' : rn.ok ? 'VALID' : `refused: ${rn.error}`,
      committed_overlap_exact_m2: committed, violates_I2: committed > 0.01 };
    out.results[`${ver}_${s}`] = r;
    console.log(ver, s.padEnd(4), '| register O:', r.register_O.slice(0, 55), '| rectify:', r.rectify_O.slice(0, 40), '| committed overlap', committed.toFixed(4), r.violates_I2 ? 'VIOLATION' : 'ok');
  }
  console.log('exact areas', J(exact));
  fs.writeFileSync(path.join(__dirname, 'out', 'probe_lattice_sliver.json'), J(out, null, 1));
})();
