"""v1.5.1: checks interAreaK and claimArea2 of lib/exact.js against GEOS (Shapely) on
out/validate_claim_cases.json. Writes out/validate_claim.json."""
import json
from shapely.geometry import Polygon
from shapely.ops import unary_union
C = json.load(open('out/validate_claim_cases.json'))
res = {'cases': 0, 'skipped_invalid': 0, 'mismatch_claim': 0, 'mismatch_claimG': 0, 'mismatch_triple': 0, 'positive_claimG': 0, 'worst_abs_err_m2': 0.0, 'by_kind': {}}
for c in C:
    N, G = Polygon(c['N']), Polygon(c['G']); Os = [Polygon(o) for o in c['Os']]
    if not all(p.is_valid for p in [N, G, *Os]): res['skipped_invalid'] += 1; continue
    res['cases'] += 1
    U = unary_union(Os); claim = N.difference(U)
    g = {'claim': claim.area * 1e-6, 'claimG': claim.intersection(G).area * 1e-6, 'triple': N.intersection(Os[0]).intersection(G).area * 1e-6}
    for k in g:
        e = abs(g[k] - c[k]); res['worst_abs_err_m2'] = max(res['worst_abs_err_m2'], e)
        if e > 1e-6: res['mismatch_' + k] += 1
    if c['claimG'] > 0: res['positive_claimG'] += 1
    k = str(c['kind']); res['by_kind'][k] = res['by_kind'].get(k, 0) + 1
json.dump(res, open('out/validate_claim.json', 'w'), indent=1); print(res)
