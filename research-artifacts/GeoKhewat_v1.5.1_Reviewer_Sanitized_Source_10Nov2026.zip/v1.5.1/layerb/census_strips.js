'use strict';
/* GKC-P census: cells in the cover of an 8 m wide strip, bounding-box versus polygon-exact,
 * for lengths 100-1500 m and bearings 0-45 degrees, precision 8 (chaincode v1.4.0 functions). */
const fs = require('fs');
const I = require('../chaincode_v14/geokhewat-chaincode/lib/geokhewat-contract.js')._internal;
const G = require('./geo_util');
const out = [];
for (const L of [100, 250, 500, 1000, 1500]) for (const deg of [0, 15, 30, 45]) for (const W of [8, 30]) {
  const th = deg * Math.PI / 180;
  const pts = [[0, 0], [L, 0], [L, W], [0, W]].map(([x, y]) => [x * Math.cos(th) - y * Math.sin(th), x * Math.sin(th) + y * Math.cos(th)]);
  const ring = G.ringLL(pts);
  const o = I.originOf(ring.slice(0, -1));
  const mm = I.mmPath(ring, o);
  const poly = I.densifiedLL(mm, o);
  const p = 8, lb = Math.floor(p * 5 / 2), ob = p * 5 - lb, dlat = 180 / 2 ** lb, dlon = 360 / 2 ** ob, PAD = 1e-8;
  const lats = poly.map(v => v[1]), lons = poly.map(v => v[0]);
  const nBox = (Math.floor((Math.max(...lats) + PAD + 90) / dlat) - Math.floor((Math.min(...lats) - PAD + 90) / dlat) + 1) *
               (Math.floor((Math.max(...lons) + PAD + 180) / dlon) - Math.floor((Math.min(...lons) - PAD + 180) / dlon) + 1);
  const nPoly = I.regionCells(mm, o, p, 'poly').length;
  out.push({ length_m: L, width_m: W, bearing_deg: deg, area_m2: L * W, cells_bbox: nBox, cells_poly: nPoly, bbox_over_bound: nBox > 256, poly_over_bound: nPoly > 256 });
}
fs.writeFileSync('out/census_strips.json', JSON.stringify(out, null, 1));
for (const r of out.filter(r => r.width_m === 8)) console.log(`L=${r.length_m} b=${r.bearing_deg}: bbox ${r.cells_bbox} poly ${r.cells_poly}`);
