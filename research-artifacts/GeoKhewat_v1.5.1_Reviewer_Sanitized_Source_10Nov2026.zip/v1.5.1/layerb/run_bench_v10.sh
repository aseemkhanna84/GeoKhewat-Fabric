#!/bin/bash
# Layer B' v10 experiment matrix (current chaincode under the Fabric-semantics stub; each output line records the version).
cd /home/claude/gk10/layerb; mkdir -p out/bench logs
S10='[1,2,3,4,5,6,7,8,9,10]'
ALL='["B1:poly","B2:poly","B3:poly","GKF:poly","GKC:poly","GKCR:poly","GKCR:bbox"]'
FOUR='["B3:poly","GKF:poly","GKC:poly","GKCR:poly"]'
q1() {
  node bench_cc.js "{\"tag\":\"e1_uniform\",\"strategies\":$ALL,\"B\":[32,64,128,256],\"seeds\":$S10,\"blocks\":6}"
  node bench_cc.js "{\"tag\":\"e2_hetero\",\"corpus\":\"hetero\",\"strategies\":$ALL,\"B\":[128],\"seeds\":$S10,\"blocks\":6}"
  for p in 7 9; do node bench_cc.js "{\"tag\":\"e7_prec$p\",\"precision\":$p,\"strategies\":[\"GKF:poly\",\"GKC:poly\",\"GKCR:poly\"],\"B\":[128],\"seeds\":$S10,\"blocks\":6}"; done
  node bench_cc.js "{\"tag\":\"e6_history\",\"mix\":\"boundary_adjustment\",\"strategies\":[\"GKC:poly\",\"GKCR:poly\"],\"B\":[64],\"seeds\":[1,2,3],\"blocks\":40,\"trace\":true}"
  node bench_cc.js "{\"tag\":\"e6_history_compact\",\"mix\":\"boundary_adjustment\",\"strategies\":[\"GKCR:poly\"],\"B\":[64],\"seeds\":[1,2,3],\"blocks\":40,\"trace\":true,\"compact_every\":10}"
}
q2() {
  for th in 0 30 45; do node bench_cc.js "{\"tag\":\"e3_rot$th\",\"theta\":$th,\"strategies\":[\"B3:poly\",\"GKF:poly\",\"GKF:bbox\",\"GKC:poly\",\"GKC:bbox\",\"GKCR:poly\",\"GKCR:bbox\"],\"B\":[128],\"seeds\":$S10,\"blocks\":6}"; done
  for m in admin transfer_heavy rectification_heavy partition_heavy survey_campaign registration_burst boundary_adjustment; do
    node bench_cc.js "{\"tag\":\"e4_mix_$m\",\"mix\":\"$m\",\"strategies\":$FOUR,\"B\":[128],\"seeds\":$S10,\"blocks\":6}"; done
  for f in 0.25 0.5 0.75 0.9; do node bench_cc.js "{\"tag\":\"e5_skew_$f\",\"skew\":$f,\"strategies\":$FOUR,\"B\":[128],\"seeds\":$S10,\"blocks\":6}"; done
}
q1 > logs/q1.log 2>&1 &
q2 > logs/q2.log 2>&1 &
wait
echo ALLDONE >> logs/q1.log
