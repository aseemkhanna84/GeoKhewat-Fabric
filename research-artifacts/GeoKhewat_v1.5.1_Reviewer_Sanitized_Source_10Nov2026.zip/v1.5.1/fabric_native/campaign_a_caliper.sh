#!/bin/bash
# Part A2: three Caliper repetitions on the network left running by campaign_a_tests.sh.
set -x
NET=/home/claude/gk10/fabric_native
cd $NET && source env.sh
cd caliper
for n in 1 2 3; do GK_NONCE=$((100+n)) npx caliper launch manager --caliper-workspace . --caliper-networkconfig networks/geokhewat.yaml \
  --caliper-benchconfig benchmarks/register.yaml --caliper-flow-only-test --caliper-fabric-gateway-enabled --caliper-report-path ../results/caliper_report_rep$n.html > ../results/caliper_rep$n.log 2>&1; done
echo CAMPAIGN_A_CALIPER_DONE
