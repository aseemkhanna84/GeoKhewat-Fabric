#!/bin/bash
# Part A1: clean network, deploy the current chaincode (seven configurations) and v1.3.0, run the
# functional/regression/interleaving tests. Caliper follows in campaign_a_caliper.sh.
set -x
NET=/home/claude/gk10/fabric_native
cd $NET && source env.sh
mkdir -p results
sha256sum /home/claude/gk10/chaincode_v14/geokhewat-chaincode/lib/geokhewat-contract.js /home/claude/gk10/chaincode_v14/geokhewat-chaincode/lib/exact.js > results/chaincode_sha256.txt
rm -f results/region_counter.json
./redeploy_all.sh > logs_redeploy_final.txt 2>&1
peer version > results/peer_version.txt 2>&1; orderer version > results/orderer_version.txt 2>&1
cp configtx.yaml results/configtx_used.yaml
cd client
GK_RUN=final GK_PAIRS=20 node fabric_tests.js > ../results/fabric_tests_final.log 2>&1
echo CAMPAIGN_A_TESTS_DONE
