'use strict';
/* Caliper workload: registration of disjoint 30 x 40 m parcels, 100 m apart, so no two
 * transactions share a geohash cell; measures the cost of each strategy's checks and keys. */
const { WorkloadModuleBase } = require('@hyperledger/caliper-core');
const proj4 = require('proj4');
proj4.defs('EPSG:32643', '+proj=utm +zone=43 +datum=WGS84 +units=m +no_defs');
const ll = ([x, y]) => proj4('EPSG:32643', 'EPSG:4326', [x, y]);
function rect(x, y, w, h) { const r = [[x, y], [x + w, y], [x + w, y + h], [x, y + h]].map(ll); r.push([...r[0]]); return r; }
class Register extends WorkloadModuleBase {
  async initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext) {
    await super.initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext);
    this.i = 0;
    const nonce = Number(process.env.GK_NONCE || 0);
    this.x0 = 400000 + (nonce % 20) * 12000 + workerIndex * 5500;
    this.y0 = 3300000 + roundIndex * 3000 + Math.floor(nonce / 20) * 60000;
    this.tag = `C${nonce}_${roundIndex}_${workerIndex}`;
  }
  async submitTransaction() {
    const i = this.i++;
    const x = this.x0 + (i % 50) * 100, y = this.y0 + Math.floor(i / 50) * 100;
    await this.sutAdapter.sendRequests({
      contractId: this.roundArguments.contractId, contractFunction: 'RegisterParcel', invokerIdentity: 'User1', readOnly: false,
      contractArguments: [`${this.tag}_${i}`, `K${this.tag}_${i}`, JSON.stringify(rect(x, y, 30, 40)), '[{"owner":"O1","num":"1","den":"1"}]', 'CALIPER', '[]'],
    });
  }
}
module.exports.createWorkloadModule = () => new Register();
