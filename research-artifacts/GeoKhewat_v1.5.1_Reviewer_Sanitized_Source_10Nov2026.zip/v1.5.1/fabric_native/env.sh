# GeoKhewat native Fabric 2.5.16 network: shared environment
export NET=/home/claude/gk10/fabric_native
export PATH=$NET/fabric/bin:$PATH
export CRYPTO=$NET/crypto
export ORDERER_CA=$CRYPTO/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem
export ORDERER_ADMIN_CERT=$CRYPTO/ordererOrganizations/example.com/orderers/orderer.example.com/tls/server.crt
export ORDERER_ADMIN_KEY=$CRYPTO/ordererOrganizations/example.com/orderers/orderer.example.com/tls/server.key
peer_env() {   # $1 org (survey|revenue|registration)  $2 user (Admin|User1)
  local org=$1 user=${2:-Admin}
  case $org in survey) port=7051; msp=SurveyMSP;; revenue) port=8051; msp=RevenueMSP;; registration) port=9051; msp=RegistrationMSP;; esac
  export FABRIC_CFG_PATH=$NET/config/peer-$org
  export CORE_PEER_TLS_ENABLED=true
  export CORE_PEER_LOCALMSPID=$msp
  export CORE_PEER_TLS_ROOTCERT_FILE=$CRYPTO/peerOrganizations/$org.example.com/peers/peer0.$org.example.com/tls/ca.crt
  export CORE_PEER_MSPCONFIGPATH=$CRYPTO/peerOrganizations/$org.example.com/users/$user@$org.example.com/msp
  export CORE_PEER_ADDRESS=peer0.$org.example.com:$port
}
# keep all Fabric traffic off the outbound HTTPS proxy
export NO_PROXY="${NO_PROXY},.example.com,orderer.example.com,peer0.survey.example.com,peer0.revenue.example.com,peer0.registration.example.com"
export no_proxy="$NO_PROXY"
