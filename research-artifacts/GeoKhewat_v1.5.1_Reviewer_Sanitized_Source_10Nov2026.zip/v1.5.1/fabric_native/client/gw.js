'use strict';
/* Fabric Gateway helpers for the native GeoKhewat network (Fabric 2.5.16, 3 orgs). */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const grpc = require('@grpc/grpc-js');
const { connect, signers } = require('@hyperledger/fabric-gateway');
const protos = require('@hyperledger/fabric-protos');

const CRYPTO = '/home/claude/gk10/fabric_native/crypto/peerOrganizations';
const ORGS = {
  survey: { msp: 'SurveyMSP', peer: 'peer0.survey.example.com:7051' },
  revenue: { msp: 'RevenueMSP', peer: 'peer0.revenue.example.com:8051' },
  registration: { msp: 'RegistrationMSP', peer: 'peer0.registration.example.com:9051' },
};
const CODE = Object.fromEntries(Object.entries(protos.peer.TxValidationCode).map(([k, v]) => [v, k]));

function firstFile(dir) { return path.join(dir, fs.readdirSync(dir)[0]); }
const clients = new Map();
function grpcClient(org) {
  if (clients.has(org)) return clients.get(org);
  const o = ORGS[org];
  const host = o.peer.split(':')[0];
  const tlsRoot = fs.readFileSync(`${CRYPTO}/${org}.example.com/peers/${host}/tls/ca.crt`);
  const c = new grpc.Client(o.peer, grpc.credentials.createSsl(tlsRoot), { 'grpc.ssl_target_name_override': host });
  clients.set(org, c);
  return c;
}
function gateway(org, user = 'User1', viaOrg = org) {
  const o = ORGS[org];
  const mspDir = `${CRYPTO}/${org}.example.com/users/${user}@${org}.example.com/msp`;
  const credentials = fs.readFileSync(firstFile(path.join(mspDir, 'signcerts')));
  const key = crypto.createPrivateKey(fs.readFileSync(firstFile(path.join(mspDir, 'keystore'))));
  return connect({
    client: grpcClient(viaOrg), identity: { mspId: o.msp, credentials }, signer: signers.newPrivateKeySigner(key),
    evaluateOptions: () => ({ deadline: Date.now() + 30000 }), endorseOptions: () => ({ deadline: Date.now() + 60000 }),
    submitOptions: () => ({ deadline: Date.now() + 30000 }), commitStatusOptions: () => ({ deadline: Date.now() + 120000 }),
  });
}
function errText(e) {
  const parts = [e.message || String(e)];
  for (const d of e.details || []) parts.push(`${d.mspId || ''}@${d.address || ''}: ${d.message}`);
  return parts.join(' | ');
}
/* endorse only; returns a handle to submit later (for interleavings) */
async function endorse(contract, fn, args, opts = {}) {
  try {
    const prop = contract.newProposal(fn, { arguments: args.map(String), ...opts });
    const tx = await prop.endorse();
    return { ok: true, tx, txid: prop.getTransactionId(), fn };
  } catch (e) { return { ok: false, error: errText(e), fn }; }
}
async function submitEndorsed(h) {
  if (!h.ok) return { code: 'ENDORSEMENT_REFUSED', error: h.error, fn: h.fn };
  const t0 = process.hrtime.bigint();
  const commit = await h.tx.submit();
  const st = await commit.getStatus();
  return { code: CODE[st.code], valid: st.successful, block: Number(st.blockNumber), txid: h.txid, fn: h.fn, commit_wait_ms: Number(process.hrtime.bigint() - t0) / 1e6 };
}
async function submitMany(handles) {   // submit all endorsed transactions before awaiting any status
  const commits = [];
  for (const h of handles) {
    if (!h.ok) { commits.push(null); continue; }
    commits.push(await h.tx.submit());
  }
  const out = [];
  for (let i = 0; i < handles.length; i++) {
    const h = handles[i];
    if (!commits[i]) { out.push({ code: 'ENDORSEMENT_REFUSED', error: h.error, fn: h.fn }); continue; }
    const st = await commits[i].getStatus();
    out.push({ code: CODE[st.code], valid: st.successful, block: Number(st.blockNumber), txid: h.txid, fn: h.fn });
  }
  return out;
}
async function invoke(contract, fn, args, opts) { return submitEndorsed(await endorse(contract, fn, args, opts)); }
async function evaluate(contract, fn, args) {
  try { return { ok: true, out: Buffer.from(await contract.evaluateTransaction(fn, ...args.map(String))).toString() }; }
  catch (e) { return { ok: false, error: errText(e) }; }
}
function closeAll() { for (const c of clients.values()) c.close(); clients.clear(); }
module.exports = { gateway, endorse, submitEndorsed, submitMany, invoke, evaluate, closeAll, ORGS, CODE };
