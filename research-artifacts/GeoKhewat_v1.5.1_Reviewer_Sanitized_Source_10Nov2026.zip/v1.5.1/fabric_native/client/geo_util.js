'use strict';
/* Shared helpers for the Layer B' harnesses: synthetic rings in UTM 43N metres,
 * conversion to lon/lat, and an exact overlap measure independent of the chaincode
 * under test (integer-millimetre Clipper intersection, same method as v1.2). */
const proj4 = require('proj4');
const ClipperLib = require('clipper-lib');
proj4.defs('EPSG:32643', '+proj=utm +zone=43 +datum=WGS84 +units=m +no_defs');

const X0 = 600000, Y0 = 3450000;          // a point in UTM 43N (Punjab longitude band)
const ll = ([x, y]) => proj4('EPSG:32643', 'EPSG:4326', [x, y]);
const utm = ([lon, lat]) => proj4('EPSG:4326', 'EPSG:32643', [lon, lat]);
/* ring from local metres (relative to X0, Y0); closes the ring */
function ringLL(pts) {
  const r = pts.map(([x, y]) => ll([X0 + x, Y0 + y]));
  r.push([...r[0]]);
  return r;
}
function rect(x, y, w, h) { return ringLL([[x, y], [x + w, y], [x + w, y + h], [x, y + h]]); }
const J = o => JSON.stringify(o);

function mm(ring) {
  return ring.slice(0, -1).map(p => { const [x, y] = utm(p); return { X: Math.round((x - X0) * 1000), Y: Math.round((y - Y0) * 1000) }; });
}
/* v10.1: exact overlap (rational boundary integration, lib/exact.js), validated against GEOS in
 * layerb/validate_exact.py; the earlier Clipper measure rounded intersection points to 1 mm
 * and could miss slivers thinner than the lattice. overlapM2Clipper is kept for comparison. */
const EXACT = require('../../chaincode_v14/geokhewat-chaincode/lib/exact.js');
function overlapM2(a, b) { return EXACT.interAreaM2(mm(a), mm(b)); }
function overlapM2Clipper(a, b) {
  const c = new ClipperLib.Clipper();
  c.AddPath(mm(a), ClipperLib.PolyType.ptSubject, true);
  c.AddPath(mm(b), ClipperLib.PolyType.ptClip, true);
  const sol = new ClipperLib.Paths();
  c.Execute(ClipperLib.ClipType.ctIntersection, sol, ClipperLib.PolyFillType.pftNonZero, ClipperLib.PolyFillType.pftNonZero);
  let s = 0; for (const p of sol) s += ClipperLib.Clipper.Area(p);
  return Math.abs(s) / 1e6;
}
function areaM2(ring) {
  const p = ring.map(utm); let s = 0;
  for (let i = 0; i < p.length - 1; i++) s += p[i][0] * p[i + 1][1] - p[i + 1][0] * p[i][1];
  return Math.abs(s) / 2;
}
/* active parcels in a stub world, and the largest pairwise overlap among them */
function activeParcels(world) {
  const out = [];
  for (const [k, e] of world.state) {
    if (!k.startsWith('PARCEL~')) continue;
    const p = JSON.parse(e.value.toString());
    if (p.status === 'ACTIVE') out.push(p);
  }
  return out;
}
function maxPairOverlap(world) {
  const ps = activeParcels(world);
  let best = { area: 0, pair: null };
  for (let i = 0; i < ps.length; i++) for (let j = i + 1; j < ps.length; j++) {
    const a = overlapM2(ps[i].ring, ps[j].ring);
    if (a > best.area) best = { area: a, pair: [ps[i].id, ps[j].id] };
  }
  return best;
}
function rng(seed) { let s = seed >>> 0; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 2 ** 32; }; }

module.exports = { X0, Y0, ll, utm, ringLL, rect, J, mm, overlapM2, overlapM2Clipper, areaM2, activeParcels, maxPairOverlap, rng };
