'use strict';
/*
 * Layer B: GeoKhewat chaincode (current version) executed on a Hyperledger Fabric 2.5.16 network
 * (one Raft orderer, three peers for SurveyMSP, RevenueMSP and RegistrationMSP, LevelDB,
 * TLS, chaincode as a service). Every outcome below is read from the endorsement response
 * or from the commit status the peers returned. Writes ../results/fabric_v14_results.json.
 */
const fs = require('fs');
const path = require('path');
const { gateway, endorse, submitMany, invoke, evaluate, closeAll } = require('./gw');
const G = require('./geo_util');
const { rect, ringLL } = G;
const CC = require('/home/claude/gk10/chaincode_v14/geokhewat-chaincode/lib/geokhewat-contract.js');
const J = JSON.stringify;
const SH1 = '[{"owner":"O1","num":"1","den":"1"}]';
const RUN = process.env.GK_RUN || 'r1';
const OUT = path.join(__dirname, '..', 'results'); fs.mkdirSync(OUT, { recursive: true });

const gws = { survey: gateway('survey'), revenue: gateway('revenue'), registration: gateway('registration'), admin: gateway('survey', 'Admin') };
const C = (name, who = 'survey') => gws[who].getNetwork('landrecords').getContract(name);
const results = { run: RUN, started_utc: new Date().toISOString(), network: {
  fabric: '2.5.16 (native binaries)', orderer: 'etcdraft, 1 node, BatchTimeout 2s, MaxMessageCount 10', peers: 3,
  orgs: ['SurveyMSP', 'RevenueMSP', 'RegistrationMSP'], state_db: 'goleveldb', tls: true, endorsement_policy: 'MAJORITY Endorsement (2 of 3)',
  chaincode: `geokhewat v${require('/home/claude/gk10/chaincode_v14/geokhewat-chaincode/lib/geokhewat-contract.js')._internal.VERSION} via chaincode-as-a-service`, node: process.version }, tests: [] };
let region = Number(process.env.GK_REGION0 || 0);
const nextRegion = () => (region += 1) * 3000;     // local metres; keeps tests apart in one namespace
function rec(id, cc, expected, observed, pass, evidence = {}) {
  results.tests.push({ id, chaincode: cc, expected, observed, pass, evidence });
  console.log(`${pass ? 'PASS' : 'FAIL'} ${cc.padEnd(8)} ${id}: ${observed}`);
}
const reg = (cc, id, ring, kh = `K${id}`, sh = SH1) => invoke(C(cc), 'RegisterParcel', [id, kh, J(ring), sh, 'SYNTHETIC', '[]']);
const rectify = (cc, id, ring) => invoke(C(cc), 'RectifyBoundary', [id, J(ring), 'SYNTHETIC', '[]']);
const kid = (k, r) => ({ khasra: k, ring: r, shares: JSON.parse(SH1) });
const short = r => (r.code === 'VALID' ? 'VALID' : r.code === 'ENDORSEMENT_REFUSED' ? `refused: ${(r.error.match(/chaincode response 500, ([^|]*)/) || [, r.error])[1].slice(0, 110)}` : r.code);

async function functional(cc) {
  const RING1 = [[75.5000, 31.0000], [75.5010, 31.0000], [75.5010, 31.0010], [75.5000, 31.0010], [75.5000, 31.0000]];
  const RING2 = [[75.5010, 31.0000], [75.5020, 31.0000], [75.5020, 31.0010], [75.5010, 31.0010], [75.5010, 31.0000]];
  const RING3 = [[75.5002, 31.0002], [75.5008, 31.0002], [75.5008, 31.0008], [75.5002, 31.0008], [75.5002, 31.0002]];
  const RING1_RECT = [[75.500005, 31.0000], [75.5010, 31.0000], [75.5010, 31.0010], [75.500005, 31.0010], [75.500005, 31.0000]];
  const RING1_TOO_BIG = [[75.4990, 30.9990], [75.5020, 30.9990], [75.5020, 31.0020], [75.4990, 31.0020], [75.4990, 30.9990]];
  const BOWTIE = [[75.5100, 31.0000], [75.5110, 31.0010], [75.5100, 31.0010], [75.5110, 31.0000], [75.5100, 31.0000]];
  const t = []; const ev = {};
  const q = await evaluate(C(cc), 'QueryParcel', ['P000']);
  t.push(['runtime_smoke', !q.ok && /not found/.test(q.error)]);
  let r = await reg(cc, 'P001', RING1, 'K001'); t.push(['register_P001', r.code === 'VALID']); ev.register_P001 = r;
  t.push(['query_P001', /P001/.test((await evaluate(C(cc), 'QueryParcel', ['P001'])).out || '')]);
  r = await reg(cc, 'P002', RING2, 'K002'); t.push(['shared_boundary_P002', r.code === 'VALID']);
  t.push(['query_P002', /P002/.test((await evaluate(C(cc), 'QueryParcel', ['P002'])).out || '')]);
  r = await reg(cc, 'P003', RING3, 'K003'); t.push(['overlap_P003_rejected', r.code === 'ENDORSEMENT_REFUSED' && /overlap|meets/i.test(r.error)]); ev.overlap_P003 = short(r);
  const q3 = await evaluate(C(cc), 'QueryParcel', ['P003']); t.push(['P003_absent_after_rejection', !q3.ok && /not found/.test(q3.error)]);
  r = await rectify(cc, 'P001', RING1_RECT); t.push(['rectify_P001_within_2pct', r.code === 'VALID']);
  t.push(['P001_version_increment', JSON.parse((await evaluate(C(cc), 'QueryParcel', ['P001'])).out).version === 2]);
  r = await rectify(cc, 'P001', RING1_TOO_BIG); t.push(['rectify_over_2pct_rejected', r.code === 'ENDORSEMENT_REFUSED' && /2% area bound/.test(r.error)]);
  r = await reg(cc, 'P004', BOWTIE, 'K004'); t.push(['self_intersection_rejected', r.code === 'ENDORSEMENT_REFUSED' && /self-intersecting/.test(r.error)]);
  await invoke(C(cc, 'registration'), 'RecordDeed', ['D-K001-1', 'K001', 'O1', 'O2', '1', '2']);
  r = await invoke(C(cc, 'revenue'), 'TransferShare', ['K001', 'O1', 'O2', '1', '2', 'D-K001-1']); t.push(['transfer_share_K001', r.code === 'VALID']);
  const passN = t.slice(1).filter(x => x[1]).length;
  rec('functional_suite', cc, 'smoke PASS and 11/11 functional checks', `smoke ${t[0][1] ? 'PASS' : 'FAIL'}; ${passN}/11 passed`, t.every(x => x[1]), { checks: t, ...ev });
  // MVCC probe: two transfers endorsed against the same state and submitted together
  await invoke(C(cc, 'registration'), 'RecordDeed', ['D-a', 'K001', 'O1', 'O3', '1', '4']);
  await invoke(C(cc, 'registration'), 'RecordDeed', ['D-b', 'K001', 'O1', 'O4', '1', '4']);
  const a = await endorse(C(cc, 'revenue'), 'TransferShare', ['K001', 'O1', 'O3', '1', '4', 'D-a']);
  const b = await endorse(C(cc, 'revenue'), 'TransferShare', ['K001', 'O1', 'O4', '1', '4', 'D-b']);
  const codes = await submitMany([a, b]);
  rec('mvcc_probe_transfers', cc, 'one VALID, one MVCC_READ_CONFLICT', codes.map(x => x.code).join('/'),
    codes.filter(x => x.code === 'VALID').length === 1 && codes.some(x => x.code === 'MVCC_READ_CONFLICT'), { codes });
}

async function regressions(cc) {
  let r, X;
  // A1: configuration immutable
  r = await invoke(C(cc, 'admin'), 'SetStrategy', ['GK', '8']);
  rec('A1_setstrategy_removed', cc, 'refused', short(r), r.code === 'ENDORSEMENT_REFUSED' && /removed/.test(r.error));
  r = await invoke(C(cc, 'admin'), 'InitConfig', [J({ strategy: 'B1', research: true, roles: { admin: ['SurveyMSP'], survey: ['SurveyMSP'], registration: ['RegistrationMSP'], revenue: ['RevenueMSP'] } })]);
  rec('A1_second_initconfig', cc, 'refused', short(r), r.code === 'ENDORSEMENT_REFUSED' && /immutable/.test(r.error));
  // A3: identifier reuse, including two concurrent creations of one identifier
  X = nextRegion();
  await reg(cc, `P${X}`, rect(X, 0, 60, 40)); await reg(cc, `Q${X}`, rect(X + 200, 0, 60, 40));
  r = await invoke(C(cc), 'PartitionParcel', [`P${X}`, J([kid(`Q${X}`, rect(X, 0, 30, 40)), kid(`P${X}b`, rect(X + 30, 0, 30, 40))]), '[]']);
  rec('A3_child_id_exists', cc, 'refused', short(r), r.code === 'ENDORSEMENT_REFUSED' && /already exists/.test(r.error));
  const h1 = await endorse(C(cc), 'PartitionParcel', [`P${X}`, J([kid(`X${X}`, rect(X, 0, 30, 40)), kid(`P${X}b`, rect(X + 30, 0, 30, 40))]), '[]']);
  const h2 = await endorse(C(cc), 'PartitionParcel', [`Q${X}`, J([kid(`X${X}`, rect(X + 200, 0, 30, 40)), kid(`Q${X}b`, rect(X + 230, 0, 30, 40))]), '[]']);
  const codes = await submitMany([h1, h2]);
  rec('A3_concurrent_same_child_id', cc, 'one VALID, one MVCC_READ_CONFLICT', codes.map(x => x.code).join('/'),
    codes.filter(x => x.code === 'VALID').length === 1 && codes.some(x => x.code === 'MVCC_READ_CONFLICT'), { codes });
  // A4: ring validity
  X = nextRegion();
  const bad = {
    pinch: ringLL([[X, 0], [X + 20, 20], [X + 40, 0], [X + 40, 40], [X + 20, 20], [X, 40]]),
    vertex_touch: ringLL([[X, 0], [X + 40, 0], [X + 40, 40], [X + 25, 40], [X + 20, 0], [X + 15, 40], [X, 40]]),
    spike: ringLL([[X, 0], [X + 40, 0], [X + 20, 0], [X + 20, 20], [X, 20]]),
    repeated: ringLL([[X, 0], [X + 40, 0], [X + 40, 0], [X + 40, 20], [X, 20]]),
    tiny: ringLL([[X, 0], [X + 0.08, 0], [X, 0.1]]),
  };
  for (const [n, ring] of Object.entries(bad)) { r = await reg(cc, `V${X}${n}`, ring); rec(`A4_invalid_ring_${n}`, cc, 'refused', short(r), r.code === 'ENDORSEMENT_REFUSED'); }
  X = nextRegion();
  await reg(cc, `L${X}`, ringLL([[X, 0], [X + 60, 0], [X + 60, 20], [X + 20, 20], [X + 20, 60], [X, 60]]));
  r = await invoke(C(cc), 'PartitionParcel', [`L${X}`, J([kid(`L${X}a`, ringLL([[X + 20, 0], [X + 60, 0], [X + 60, 20], [X + 20, 60]])), kid(`L${X}b`, ringLL([[X, 0], [X + 20, 0], [X + 20, 20], [X, 20]]))]), '[]']);
  rec('A4_concave_parent_child_outside', cc, 'refused', short(r), r.code === 'ENDORSEMENT_REFUSED' && /outside the parent/.test(r.error));
  // L1: long-edge counterexample (absolute coordinates; registered once per namespace)
  const { construct } = require('./probe_long_edge');
  const k = construct();
  r = await reg(cc, 'LONG_B', k.B); const ra = await reg(cc, 'LONG_A', k.A);
  rec('L1_long_edge_overlap', cc, 'B VALID; A (overlaps B by 0.706 m2) refused', `B ${short(r)}; A ${short(ra)}`, r.code === 'VALID' && ra.code === 'ENDORSEMENT_REFUSED');
  // A6: accumulation of sub-tolerance bumps
  X = nextRegion();
  await reg(cc, `A${X}`, rect(X + 60, 0, 60, 40)); await reg(cc, `B${X}`, rect(X, 0, 60, 40));
  const bumps = []; let acc = 0;
  for (let i = 0; i < 6; i++) {
    const y = 2 + 4 * i; bumps.push([[X + 60, y], [X + 60.18, y + 0.05], [X + 60, y + 0.1]]);
    const right = []; for (const bb of bumps) right.push(...bb);
    r = await rectify(cc, `B${X}`, ringLL([[X, 0], [X + 60, 0], ...right, [X + 60, 40], [X, 40]]));
    if (r.code === 'VALID') acc += 1; else bumps.pop();
  }
  rec('A6_tolerance_accumulation', cc, cc === 'gkc' ? '0 of 6 accepted' : '1 of 6 accepted (0.009 <= 0.01, then refused)', `${acc} of 6 accepted`, acc === (cc === 'gkc' ? 0 : 1));
  // A7: released land
  X = nextRegion();
  await reg(cc, `A${X}`, rect(X, 0, 60, 40)); await reg(cc, `B${X}`, rect(X + 60, 0, 60, 40));
  await rectify(cc, `A${X}`, rect(X, 0, 59.2, 40));
  r = await rectify(cc, `B${X}`, ringLL([[X + 59.2, 0], [X + 120, 0], [X + 120, 40], [X + 59.2, 40]]));
  rec('A7_reclaim_released_land', cc, cc === 'gkc' ? 'refused (conservative index)' : 'VALID', short(r), cc === 'gkc' ? r.code === 'ENDORSEMENT_REFUSED' : r.code === 'VALID');
  // A5: QueryByCell against the expected set
  X = nextRegion();
  await reg(cc, `Q${X}`, rect(X, 0, 60, 40));
  await invoke(C(cc), 'PartitionParcel', [`Q${X}`, J([kid(`Q${X}a`, rect(X, 0, 30, 40)), kid(`Q${X}b`, rect(X + 30, 0, 30, 40))]), '[]']);
  const I = CC._internal; const ringA = rect(X, 0, 30, 40), ringB = rect(X + 30, 0, 30, 40);
  const o = I.originOf(ringA.slice(0, -1));
  const cells = I.cellsOf([I.mmPath(rect(X, 0, 60, 40), o)], o, 8, 'bbox');
  let mism = 0;
  for (const g of cells) {
    const got = JSON.parse((await evaluate(C(cc), 'QueryByCell', [g])).out).map(z => z.id).sort();
    const want = [[`Q${X}a`, ringA], [`Q${X}b`, ringB]].filter(([, rg]) => I.ringMeetsCellLL(rg, g)).map(([id]) => id).sort();
    if (J(got) !== J(want)) mism += 1;
  }
  rec('A5_query_by_cell', cc, '0 mismatches', `${cells.length} cells queried, ${mism} mismatches`, mism === 0);
  // T1 (v1.4.1): siblings overlapping a third sibling by 0.009 m2 each, then amalgamated
  X = nextRegion();
  await reg(cc, `T${X}`, rect(X, 0, 18, 40));
  const tk = [kid(`T${X}A`, rect(X, 0, 9, 20)), kid(`T${X}B`, rect(X + 9, 0, 9, 20)), kid(`T${X}S`, rect(X, 19.999, 18, 20.001))];
  const rp = await invoke(C(cc), 'PartitionParcel', [`T${X}`, J(tk), '[]']);
  let ram = null;
  if (rp.code === 'VALID') ram = await invoke(C(cc), 'AmalgamateParcels', [`T${X}A`, `T${X}B`, `T${X}M`, J(rect(X, 0, 18, 20)), '', J([`T${X}S`])]);
  const want = cc === 'gkc' ? 'partition refused (no sibling overlap under GK-C)' : 'partition VALID; amalgamation refused (0.018 m2 > eps)';
  const got = `partition ${short(rp)}; amalgamation ${ram ? short(ram) : 'not attempted'}`;
  rec('T1_sibling_amalgamation', cc, want, got, cc === 'gkc' ? rp.code === 'ENDORSEMENT_REFUSED' : (rp.code === 'VALID' && ram && ram.code === 'ENDORSEMENT_REFUSED'));
  // T2 (v1.5.0): two diagonal parcels whose true overlap (0.0105 m2) is a sliver thinner than 1 mm
  {
    const proj4 = require('proj4'); const k = nextRegion();
    const OR = [600641 + k, 3450313];
    const ringT = pts => { const r = pts.map(([X, Y]) => proj4('EPSG:32643', 'EPSG:4326', [OR[0] + X / 1000, OR[1] + Y / 1000])); r.push([...r[0]]); return r; };
    const rq = await reg(cc, `SQ${k}`, ringT([[28655, 29239], [56940, 57523], [35726, 78737], [7442, 50452]]));
    const ro = await reg(cc, `SO${k}`, ringT([[619, 707], [28904, 28991], [7442, 50452], [-20842, 22168]]));
    rec('T2_lattice_sliver', cc, 'first VALID; second (true overlap 0.0105 m2) refused', `first ${short(rq)}; second ${short(ro)}`, rq.code === 'VALID' && ro.code === 'ENDORSEMENT_REFUSED');
  }
  // T3 (v1.5.1): a partition child and a merged parcel claim land beside their ancestors' indexed
  // geometry (refused under GK-C by v1.5.0); encroachment on a sibling is still refused
  {
    const X = nextRegion();
    await reg(cc, `D${X}`, rect(X, 0, 60, 40), `KD${X}`);
    const p3 = await invoke(C(cc), 'PartitionParcel', [`D${X}`, J([kid(`D${X}A`, rect(X, 0, 30, 40)), kid(`D${X}B`, rect(X + 30, 0, 30, 40))]), '[]']);
    const out3 = await rectify(cc, `D${X}A`, rect(X, -0.4, 30, 40.4));
    const sib3 = await rectify(cc, `D${X}B`, rect(X + 29.7, 0, 30.3, 40));
    await reg(cc, `E${X}`, rect(X + 100, 0, 30, 40), `KE${X}`); await reg(cc, `F${X}`, rect(X + 130, 0, 30, 40), `KE${X}`);
    const am3 = await invoke(C(cc), 'AmalgamateParcels', [`E${X}`, `F${X}`, `M${X}`, J(rect(X + 100, 0, 60, 40)), '', '[]']);
    const mo3 = await rectify(cc, `M${X}`, rect(X + 100, -0.5, 60, 40.5));
    rec('T3_descendant_claim', cc, 'partition, child outward, amalgamation, merged outward VALID; child into sibling refused',
      `partition ${short(p3)}; child outward ${short(out3)}; into sibling ${short(sib3)}; amalgamation ${short(am3)}; merged outward ${short(mo3)}`,
      [p3, out3, am3, mo3].every(z => z.code === 'VALID') && sib3.code === 'ENDORSEMENT_REFUSED');
  }
}

async function roles(cc) {
  const X = nextRegion();
  let r = await invoke(C(cc, 'revenue'), 'RegisterParcel', [`R${X}`, `KR${X}`, J(rect(X, 0, 60, 40)), SH1, 'S', '[]']);
  rec('A8_register_by_revenue', cc, 'refused (survey role)', short(r), r.code === 'ENDORSEMENT_REFUSED' && /survey role/.test(r.error));
  r = await reg(cc, `R${X}`, rect(X, 0, 60, 40), `KR${X}`);
  rec('A8_register_by_survey', cc, 'VALID', short(r), r.code === 'VALID');
  r = await invoke(C(cc, 'revenue'), 'RecordDeed', [`D${X}`, `KR${X}`, 'O1', 'O2', '1', '2']);
  rec('A8_deed_by_revenue', cc, 'refused (registration role)', short(r), r.code === 'ENDORSEMENT_REFUSED');
  r = await invoke(C(cc, 'registration'), 'RecordDeed', [`D${X}`, `KR${X}`, 'O1', 'O2', '1', '2']);
  rec('A8_deed_by_registration', cc, 'VALID', short(r), r.code === 'VALID');
  r = await invoke(C(cc, 'registration'), 'TransferShare', [`KR${X}`, 'O1', 'O2', '1', '2', `D${X}`]);
  rec('A8_transfer_by_registration', cc, 'refused (revenue role)', short(r), r.code === 'ENDORSEMENT_REFUSED');
  const a = await endorse(C(cc, 'revenue'), 'TransferShare', [`KR${X}`, 'O1', 'O2', '1', '2', `D${X}`]);
  const b = await endorse(C(cc, 'revenue'), 'TransferShare', [`KR${X}`, 'O1', 'O2', '1', '2', `D${X}`]);
  const codes = await submitMany([a, b]);
  rec('A8_deed_consumed_twice', cc, 'one VALID, one MVCC_READ_CONFLICT', codes.map(x => x.code).join('/'),
    codes.filter(x => x.code === 'VALID').length === 1 && codes.some(x => x.code === 'MVCC_READ_CONFLICT'), { codes });
}

async function sbe() {
  const cc = 'gkcrsbe'; const X = nextRegion();
  let r = await invoke(C(cc), 'RegisterParcel', [`S${X}`, `KS${X}`, J(rect(X, 0, 60, 40)), SH1, 'S', '[]'], { endorsingOrganizations: ['RevenueMSP', 'RegistrationMSP'] });
  rec('SBE_create_without_survey_peer', cc, 'VALID (new keys follow the chaincode policy)', short(r), r.code === 'VALID');
  r = await invoke(C(cc), 'RectifyBoundary', [`S${X}`, J(rect(X, 0, 60.4, 40)), 'S', '[]'], { endorsingOrganizations: ['RevenueMSP', 'RegistrationMSP'] });
  rec('SBE_rectify_without_survey_peer', cc, 'ENDORSEMENT_POLICY_FAILURE (PARCEL key requires SurveyMSP)', short(r), r.code === 'ENDORSEMENT_POLICY_FAILURE');
  r = await invoke(C(cc), 'RectifyBoundary', [`S${X}`, J(rect(X, 0, 60.4, 40)), 'S', '[]'], { endorsingOrganizations: ['SurveyMSP', 'RevenueMSP'] });
  rec('SBE_rectify_with_survey_peer', cc, 'VALID', short(r), r.code === 'VALID');
  await invoke(C(cc, 'registration'), 'RecordDeed', [`D${X}`, `KS${X}`, 'O1', 'O2', '1', '2'], { endorsingOrganizations: ['RegistrationMSP', 'SurveyMSP'] });
  r = await invoke(C(cc, 'revenue'), 'TransferShare', [`KS${X}`, 'O1', 'O2', '1', '2', `D${X}`], { endorsingOrganizations: ['SurveyMSP', 'RevenueMSP'] });
  rec('SBE_transfer_without_registration_peer', cc, 'ENDORSEMENT_POLICY_FAILURE (DEED key requires RegistrationMSP)', short(r), r.code === 'ENDORSEMENT_POLICY_FAILURE');
  r = await invoke(C(cc, 'revenue'), 'TransferShare', [`KS${X}`, 'O1', 'O2', '1', '2', `D${X}`], { endorsingOrganizations: ['RevenueMSP', 'RegistrationMSP'] });
  rec('SBE_transfer_with_revenue_and_registration', cc, 'VALID', short(r), r.code === 'VALID');
}

async function interleavings(cc, n = Number(process.env.GK_PAIRS || 10)) {
  const kinds = ['facing', 'phantom', 'partition_beside'];
  for (const kind of kinds) {
    const tally = { placements: n, one_invalidated: 0, both_valid: 0, codes: {} };
    // setup all placements, submitted together
    const base = nextRegion(); region += Math.ceil(n * 250 / 3000); const setA = [], setB = [];
    for (let i = 0; i < n; i++) {
      const x = base + i * 250;
      setA.push(await endorse(C(cc), 'RegisterParcel', [`A${x}`, `KA${x}`, J(rect(x, 0, 60, 40)), SH1, 'S', '[]']));
    }
    const sa = await submitMany(setA);      // placements 250 m apart share no cell
    for (let i = 0; i < n; i++) {
      const x = base + i * 250;
      setB.push(await endorse(C(cc), 'RegisterParcel', [`B${x}`, `KB${x}`, J(rect(x + (kind === 'partition_beside' ? 60 : 61.4), 0, 60, 40)), SH1, 'S', '[]']));
    }
    const sc = sa.concat(await submitMany(setB));
    if (sc.some(z => z.code !== 'VALID')) { rec(`interleave_${kind}_setup`, cc, 'all VALID', sc.map(z => z.code).join(','), false); continue; }
    const hs = [];
    for (let i = 0; i < n; i++) {
      const x = base + i * 250;
      if (kind === 'facing') {
        hs.push([await endorse(C(cc), 'RectifyBoundary', [`A${x}`, J(rect(x, 0, 60.9, 40)), 'S', '[]']),
          await endorse(C(cc), 'RectifyBoundary', [`B${x}`, J(rect(x + 60.5, 0, 60.9, 40)), 'S', '[]'])]);
      } else if (kind === 'phantom') {
        hs.push([await endorse(C(cc), 'RegisterParcel', [`S${x}`, `KS${x}`, J(rect(x + 60, 0, 1.4, 40)), SH1, 'S', '[]']),
          await endorse(C(cc), 'RectifyBoundary', [`A${x}`, J(rect(x, 0, 60.9, 40)), 'S', '[]'])]);
      } else {
        hs.push([await endorse(C(cc), 'PartitionParcel', [`A${x}`, J([kid(`A${x}a`, rect(x, 0, 30, 40)), kid(`A${x}b`, rect(x + 30, 0, 30, 40))]), '[]']),
          await endorse(C(cc), 'RectifyBoundary', [`B${x}`, J(rect(x + 60, 0, 60.9, 40)), 'S', '[]'])]);
      }
    }
    const all = await submitMany(hs.flat());
    for (let i = 0; i < n; i++) {
      const pair = all.slice(2 * i, 2 * i + 2).map(z => z.code);
      const key = pair.join('/'); tally.codes[key] = (tally.codes[key] || 0) + 1;
      const v = pair.filter(c => c === 'VALID').length;
      if (v === 1) tally.one_invalidated += 1; if (v === 2) tally.both_valid += 1;
    }
    const want = kind === 'partition_beside' ? (cc === 'gkf' ? 'one invalidated' : 'both VALID') : 'one invalidated';
    const pass = want === 'both VALID' ? tally.both_valid === n : tally.one_invalidated === n;
    rec(`interleave_${kind}`, cc, `${want} in ${n}/${n}`, `one invalidated ${tally.one_invalidated}, both VALID ${tally.both_valid}; ${J(tally.codes)}`, pass, tally);
  }
}

/* v1.3.0 deployed side by side: the audit defects replayed on the network */
async function v13replay() {
  const cc = 'v13'; const X = nextRegion();
  const ringOf = async id => JSON.parse((await evaluate(C(cc), 'QueryParcel', [id])).out).ring;
  let r = await evaluate(C(cc), 'QueryByCell', ['ttw1']);
  rec('v13_A5_query_by_cell', cc, 'defect: QueryByCell fails on a Fabric peer', r.ok ? `returned ${r.out.slice(0, 60)}` : `error: ${r.error.slice(0, 120)}`, !r.ok);
  await invoke(C(cc), 'RegisterParcel', [`A${X}`, `KA${X}`, J(rect(X, 0, 60, 40)), SH1, 'S', '[]']);
  r = await invoke(C(cc, 'revenue'), 'SetStrategy', ['GK', '8']);
  const rb = await invoke(C(cc), 'RegisterParcel', [`B${X}`, `KB${X}`, J(rect(X + 30, 10, 60, 40)), SH1, 'S', '[]']);
  const ov = rb.code === 'VALID' ? G.overlapM2(await ringOf(`A${X}`), await ringOf(`B${X}`)) : 0;
  rec('v13_A1_switch_by_any_org_then_overlap', cc, 'defect reproduced on Fabric', `SetStrategy by RevenueMSP client: ${short(r)}; overlapping B: ${short(rb)}; committed overlap ${ov.toFixed(1)} m2`, r.code === 'VALID' && rb.code === 'VALID' && ov > 1, { overlap_m2: ov });
  const { construct } = require('./probe_long_edge'); const k = construct();
  const l1 = await invoke(C(cc), 'RegisterParcel', ['LONG_B', 'KLB', J(k.B), SH1, 'S', '[]']);
  const l2 = await invoke(C(cc), 'RegisterParcel', ['LONG_A', 'KLA', J(k.A), SH1, 'S', '["LONG_B"]']);
  const ovl = l2.code === 'VALID' ? G.overlapM2(await ringOf('LONG_A'), await ringOf('LONG_B')) : 0;
  rec('v13_L1_long_edge', cc, 'defect reproduced on Fabric', `B ${short(l1)}; A ${short(l2)}; committed overlap ${ovl.toFixed(3)} m2`, l2.code === 'VALID' && ovl > 0.01, { overlap_m2: ovl });
  const Y = nextRegion();
  await invoke(C(cc), 'RegisterParcel', [`P${Y}`, `KP${Y}`, J(rect(Y, 0, 60, 40)), SH1, 'S', '[]']);
  await invoke(C(cc), 'RegisterParcel', [`Q${Y}`, `KQ${Y}`, J(rect(Y + 200, 0, 60, 40)), SH1, 'S', '[]']);
  const h1 = await endorse(C(cc), 'PartitionParcel', [`P${Y}`, J([kid(`X${Y}`, rect(Y, 0, 30, 40)), kid(`P${Y}b`, rect(Y + 30, 0, 30, 40))]), '[]']);
  const h2 = await endorse(C(cc), 'PartitionParcel', [`Q${Y}`, J([kid(`X${Y}`, rect(Y + 200, 0, 30, 40)), kid(`Q${Y}b`, rect(Y + 230, 0, 30, 40))]), '[]']);
  const codes = await submitMany([h1, h2]);
  rec('v13_A3_concurrent_same_child_id', cc, 'defect reproduced on Fabric (both VALID, one child overwritten)', codes.map(z => z.code).join('/'), codes.every(z => z.code === 'VALID'), { codes });
  r = await invoke(C(cc, 'registration'), 'SetStrategy', ['GKC', '8']);
  const Z = nextRegion();
  await invoke(C(cc), 'RegisterParcel', [`A${Z}`, `KA${Z}`, J(rect(Z + 60, 0, 60, 40)), SH1, 'S', '[]']);
  await invoke(C(cc), 'RegisterParcel', [`B${Z}`, `KB${Z}`, J(rect(Z, 0, 60, 40)), SH1, 'S', '[]']);
  const bumps = []; let acc = 0;
  for (let i = 0; i < 8; i++) {
    const y = 2 + 4 * i; bumps.push([[Z + 60, y], [Z + 60.18, y + 0.05], [Z + 60, y + 0.1]]);
    const right = []; for (const bb of bumps) right.push(...bb);
    const rr = await invoke(C(cc), 'RectifyBoundary', [`B${Z}`, J(ringLL([[Z, 0], [Z + 60, 0], ...right, [Z + 60, 40], [Z, 40]])), 'S', '[]']);
    if (rr.code === 'VALID') acc += 1; else bumps.pop();
  }
  const ova = G.overlapM2(await ringOf(`A${Z}`), await ringOf(`B${Z}`));
  rec('v13_A6_accumulation', cc, 'defect reproduced on Fabric', `${acc}/8 accepted; committed overlap ${ova.toFixed(4)} m2`, ova > 0.01, { overlap_m2: ova });
  const W = nextRegion();
  await invoke(C(cc), 'RegisterParcel', [`A${W}`, `KA${W}`, J(rect(W, 0, 60, 40)), SH1, 'S', '[]']);
  await invoke(C(cc), 'RegisterParcel', [`B${W}`, `KB${W}`, J(rect(W + 60, 0, 60, 40)), SH1, 'S', '[]']);
  await invoke(C(cc), 'RectifyBoundary', [`A${W}`, J(rect(W, 0, 59.2, 40)), 'S', '[]']);
  r = await invoke(C(cc), 'RectifyBoundary', [`B${W}`, J(ringLL([[W + 59.2, 0], [W + 120, 0], [W + 120, 40], [W + 59.2, 40]])), 'S', '[]']);
  rec('v13_A7_released_land', cc, 'defect reproduced on Fabric (refused)', short(r), r.code === 'ENDORSEMENT_REFUSED');
  r = await invoke(C(cc, 'registration'), 'TransferShare', [`KA${W}`, 'O1', 'O9', '1', '2']);
  rec('v13_A8_transfer_by_any_org', cc, 'defect reproduced on Fabric (VALID)', short(r), r.code === 'VALID');
}

(async () => {
  try {
    const only = process.env.GK_ONLY || 'all';
    if (only === 'all') {
      await v13replay();
      for (const cc of ['gkcr', 'gkc', 'gkf']) { await functional(cc); await regressions(cc); }
      await roles('gkcr');
      await sbe();
    }
    for (const cc of ['gkcr', 'gkc', 'gkf']) await interleavings(cc);
    // GKC-P on the network: 600 m x 8 m diagonal strip
    const th = Math.PI / 4, L = 600, W = 8, X = nextRegion();
    const pts = [[0, 0], [L, 0], [L, W], [0, W]].map(([x, y]) => [X + x * Math.cos(th) - y * Math.sin(th), x * Math.sin(th) + y * Math.cos(th)]);
    const rb = await reg('gkcrbox', `STRIP${X}`, ringLL(pts)); const rp = await reg('gkcr', `STRIP${X}`, ringLL(pts));
    rec('GKCP_diagonal_strip', 'gkcrbox/gkcr', 'bbox refused (cover > 256), poly VALID', `bbox ${short(rb)}; poly ${short(rp)}`, rb.code === 'ENDORSEMENT_REFUSED' && rp.code === 'VALID');
  } finally {
    results.finished_utc = new Date().toISOString();
    results.summary = { tests: results.tests.length, passed: results.tests.filter(t => t.pass).length };
    fs.writeFileSync(path.join(OUT, `fabric_v14_results_${RUN}.json`), JSON.stringify(results, null, 1));
    console.log(results.summary);
    closeAll();
  }
})();
