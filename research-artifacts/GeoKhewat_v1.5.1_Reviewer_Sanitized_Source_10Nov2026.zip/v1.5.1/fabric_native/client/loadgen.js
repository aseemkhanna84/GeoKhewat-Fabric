'use strict';
/*
 * Open-loop load generator for the native Fabric 2.5.16 network (Layer B performance).
 * Transactions are issued at a fixed offered rate; each one is endorsed through the
 * Survey peer's gateway, submitted, and its commit status awaited. Per-transaction times
 * (endorse, submit-to-commit, end-to-end) and validation codes are recorded, and the CPU
 * time and resident memory of the orderer, the three peers and the chaincode server are
 * sampled from /proc once per second. Appends one JSON line per run to
 * ../results/loadgen.jsonl and writes the per-transaction rows to ../results/tx/<run>.csv.
 *
 * usage: node loadgen.js '{"cc":"gkcr","workload":"reg|mixed","rate":20,"duration":30,"rep":1}'
 */
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const { gateway, evaluate, closeAll, CODE } = require('./gw');
const G = require('./geo_util');
const SPEC = Object.assign({ cc: 'gkcr', workload: 'reg', rate: 10, duration: 30, rep: 1, warmup: 3 }, JSON.parse(process.argv[2] || '{}'));
const NET = '/home/claude/gk10/fabric_native';
const OUT = path.join(NET, 'results'); fs.mkdirSync(path.join(OUT, 'tx'), { recursive: true });
const RUN = `${SPEC.cc}_${SPEC.workload}_r${SPEC.rate}_rep${SPEC.rep}`;
const SH1 = '[{"owner":"O1","num":"1","den":"1"}]';
const J = JSON.stringify;
const sleep = ms => new Promise(r => setTimeout(r, ms));
const gw = gateway('survey');
const contract = gw.getNetwork('landrecords').getContract(SPEC.cc);

/* region offset: unique per (cc, workload, rate, rep) so runs never touch earlier parcels */
function regionBase() {
  const f = path.join(OUT, 'region_counter.json');
  let n = 0; try { n = JSON.parse(fs.readFileSync(f)).n; } catch (e) { n = 0; }
  fs.writeFileSync(f, J({ n: n + 1 }));
  return [-200000 + (n % 40) * 10000, -100000 + Math.floor(n / 40) * 6000];   // local metres
}
const [BX, BY] = regionBase();

function pidsOf() {
  const p = {};
  for (const n of ['orderer', 'peer-survey', 'peer-revenue', 'peer-registration', `cc_${SPEC.cc}`]) {
    try { p[n] = Number(fs.readFileSync(path.join(NET, 'data', `${n}.pid`), 'utf8').trim()); } catch (e) { /* absent */ }
  }
  return p;
}
const CLK = 100;
function sample(pids) {
  const out = {};
  for (const [n, pid] of Object.entries(pids)) {
    try {
      const st = fs.readFileSync(`/proc/${pid}/stat`, 'utf8').split(') ')[1].split(' ');
      const status = fs.readFileSync(`/proc/${pid}/status`, 'utf8');
      out[n] = { cpu_s: (Number(st[11]) + Number(st[12])) / CLK, rss_mb: Number((status.match(/VmRSS:\s+(\d+)/) || [0, 0])[1]) / 1024 };
    } catch (e) { out[n] = null; }
  }
  return out;
}

async function tx(fn, args) {
  const r = { fn, t0: Date.now() };
  const h0 = process.hrtime.bigint();
  try {
    const prop = contract.newProposal(fn, { arguments: args.map(String) });
    const t = await prop.endorse();
    const h1 = process.hrtime.bigint(); r.endorse_ms = Number(h1 - h0) / 1e6;
    const commit = await t.submit();
    const st = await commit.getStatus();
    const h2 = process.hrtime.bigint();
    r.commit_ms = Number(h2 - h1) / 1e6; r.e2e_ms = Number(h2 - h0) / 1e6;
    r.code = CODE[st.code]; r.block = Number(st.blockNumber);
  } catch (e) {
    r.code = /endorse|chaincode response/i.test(e.message || '') ? 'ENDORSEMENT_REFUSED' : `ERROR`;
    r.error = (e.message || String(e)).slice(0, 160);
    r.detail = (e.details || []).map(d => d.message).join(' | ').slice(0, 200);
    r.e2e_ms = Number(process.hrtime.bigint() - h0) / 1e6;
  }
  return r;
}

/* ------------------------------------------------------------ workloads */
let k = 0;
const regNext = () => { const i = k++; const x = BX + (i % 50) * 100, y = BY + Math.floor(i / 50) * 100;
  return ['RegisterParcel', [`L${RUN}_${i}`, `KL${RUN}_${i}`, J(G.rect(x, y, 30, 40)), SH1, 'LOADGEN', '[]']]; };
/* mixed: a dense 8 x 8 corpus (rows of 8 adjacent 30 x 40 m parcels, 4 m lanes) */
const corpus = [];
async function setupCorpus() {
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) corpus.push({ id: `M${RUN}${SPEC.idtag || ""}_${r}_${c}`, x0: BX + c * 30, y0: BY + r * 44, x1: BX + c * 30 + 30, y1: BY + r * 44 + 40, active: true });
  let todo = corpus.slice();
  for (let round = 0; round < 200 && todo.length; round++) {   // 200 rounds: B2 commits one registration per block
    const res = await Promise.all(todo.map(p => tx('RegisterParcel', [p.id, `K${p.id}`, J(G.rect(p.x0, p.y0, 30, 40)), SH1, 'LOADGEN', '[]'])));
    todo = todo.filter((p, i) => res[i].code !== 'VALID' && !/already exists/.test((res[i].error || '') + (res[i].detail || '')));
  }
  if (todo.length) throw new Error(`corpus setup left ${todo.length} parcels`);
}
let rngState = 12345 + SPEC.rep * 7919 + SPEC.rate;
const rnd = () => { rngState = (rngState * 1664525 + 1013904223) >>> 0; return rngState / 2 ** 32; };
/* neighbour list (B3 reads these parcels; the other strategies ignore the argument): active
 * corpus parcels whose bounding box lies within 3 m of the proposed ring's bounding box,
 * as in the Layer B' benchmark */
function neighboursOf(self, boxes) {
  const ids = [];
  for (const o of corpus) {
    if (!o.active || o.id === self.id) continue;
    if (boxes.some(b => o.x0 <= b.x1 + 3 && o.x1 >= b.x0 - 3 && o.y0 <= b.y1 + 3 && o.y1 >= b.y0 - 3)) ids.push(o.id);
  }
  return J(ids);
}
function mixedNext() {
  const act = corpus.filter(p => p.active);
  const p = act[Math.floor(rnd() * act.length)];
  const u = rnd();
  const r3 = v => Math.round(v * 1000) / 1000;
  if (u < 0.5) { const d = r3(0.2 + 0.4 * rnd()); const q = { ...p }; if (rnd() < 0.5) q.y0 -= d; else q.y1 += d; return [['RectifyBoundary', [p.id, J(G.rect(q.x0, q.y0, q.x1 - q.x0, q.y1 - q.y0)), 'LOADGEN', neighboursOf(p, [q])]], p, q]; }
  if (u < 0.8) { const d = r3(0.1 + 0.3 * rnd()); const q = { ...p }; const e = Math.floor(rnd() * 4); if (e === 0) q.x0 += d; if (e === 1) q.x1 -= d; if (e === 2) q.y0 += d; if (e === 3) q.y1 -= d; return [['RectifyBoundary', [p.id, J(G.rect(q.x0, q.y0, q.x1 - q.x0, q.y1 - q.y0)), 'LOADGEN', neighboursOf(p, [q])]], p, q]; }
  const f = r3(0.3 + 0.4 * rnd()); const w = p.x1 - p.x0; const id = `${p.id}_${k++}`;
  const a = { ...p, id: `${id}a`, x1: r3(p.x0 + w * f) }, b = { ...p, id: `${id}b`, x0: r3(p.x0 + w * f) };
  const kids = [a, b].map(z => ({ khasra: z.id, ring: G.rect(z.x0, z.y0, z.x1 - z.x0, z.y1 - z.y0), shares: JSON.parse(SH1) }));
  return [['PartitionParcel', [p.id, J(kids), neighboursOf(p, [a, b])]], p, [a, b]];
}

(async () => {
  if (SPEC.workload === 'mixed') await setupCorpus();
  const pids = pidsOf();
  const s0 = sample(pids); const tS = Date.now();
  const rows = []; const inflight = [];
  const total = Math.round(SPEC.rate * SPEC.duration);
  const start = Date.now() + 200;
  for (let i = 0; i < total; i++) {
    const due = start + (i * 1000) / SPEC.rate;
    const wait = due - Date.now(); if (wait > 0) await sleep(wait);
    let fnArgs, apply = null;
    if (SPEC.workload === 'reg') fnArgs = regNext();
    else { const [fa, p, q] = mixedNext(); fnArgs = fa; apply = r => { if (r.code !== 'VALID') return; if (Array.isArray(q)) { p.active = false; for (const z of q) corpus.push({ ...z, active: true }); } else Object.assign(p, { x0: q.x0, y0: q.y0, x1: q.x1, y1: q.y1 }); }; }
    const pr = tx(fnArgs[0], fnArgs[1]).then(r => { r.i = i; r.scheduled = due; rows.push(r); if (apply) apply(r); return r; });
    inflight.push(pr);
  }
  await Promise.all(inflight);
  const tE = Date.now(); const s1 = sample(pids);
  const warm = start + SPEC.warmup * 1000;
  const meas = rows.filter(r => r.t0 >= warm);
  const ok = meas.filter(r => r.code === 'VALID');
  const pct = (a, q) => { if (!a.length) return null; const s = a.slice().sort((x, y) => x - y); return s[Math.min(s.length - 1, Math.floor(q * (s.length - 1) + 0.5))]; };
  const lastCommit = Math.max(...meas.map(r => r.t0 + r.e2e_ms));
  const winS = (lastCommit - warm) / 1000;
  const codes = {}; for (const r of meas) codes[r.code] = (codes[r.code] || 0) + 1;
  /* client-side errors grouped by message (digits masked); added during the campaign, so absent from the first runs */
  const errors = {}; for (const r of meas) if (r.code === 'ERROR' || r.code === 'ENDORSEMENT_REFUSED') { const m = String(r.error || '').replace(/[0-9a-f]{16,}/g, '#').replace(/[0-9]+/g, '#').slice(0, 120); errors[m] = (errors[m] || 0) + 1; }
  const cpu = {}; for (const n of Object.keys(pids)) if (s0[n] && s1[n]) cpu[n] = { cpu_pct: 100 * (s1[n].cpu_s - s0[n].cpu_s) / ((tE - tS) / 1000), rss_mb: s1[n].rss_mb };
  const idx = await evaluate(contract, 'IndexStats', []);
  let ledgerBytes = null; try { ledgerBytes = Number(execSync(`du -sb ${NET}/data/peer-survey`).toString().split('\t')[0]); } catch (e) { /* ignore */ }
  const res = {
    run: RUN, ...SPEC, timestamp_utc: new Date().toISOString(), host: { cpus: require('os').cpus().length, cpu_model: require('os').cpus()[0].model, mem_gb: Math.round(require('os').totalmem() / 2 ** 30) },
    errors, offered: meas.length, offered_tps: meas.length / ((rows.length ? (Math.max(...meas.map(r => r.scheduled)) - warm) : 1) / 1000 || 1),
    committed: ok.length, committed_tps: ok.length / winS, codes,
    abort_rate: ((codes.MVCC_READ_CONFLICT || 0) + (codes.PHANTOM_READ_CONFLICT || 0)) / Math.max(1, meas.length - (codes.ENDORSEMENT_REFUSED || 0)),
    latency_ms_valid: { mean: ok.reduce((a, r) => a + r.e2e_ms, 0) / Math.max(1, ok.length), p50: pct(ok.map(r => r.e2e_ms), 0.5), p95: pct(ok.map(r => r.e2e_ms), 0.95), p99: pct(ok.map(r => r.e2e_ms), 0.99), max: Math.max(...ok.map(r => r.e2e_ms)) },
    endorse_ms: { p50: pct(meas.filter(r => r.endorse_ms).map(r => r.endorse_ms), 0.5), p95: pct(meas.filter(r => r.endorse_ms).map(r => r.endorse_ms), 0.95) },
    resources: cpu, index: idx.ok ? JSON.parse(idx.out) : idx.error, ledger_bytes_survey_peer: ledgerBytes,
  };
  fs.appendFileSync(path.join(OUT, 'loadgen.jsonl'), J(res) + '\n');
  fs.writeFileSync(path.join(OUT, 'tx', `${RUN}.csv`), 'i,fn,code,scheduled_ms,t0_ms,endorse_ms,commit_ms,e2e_ms,block\n' +
    rows.sort((a, b) => a.i - b.i).map(r => [r.i, r.fn, r.code, r.scheduled, r.t0, r.endorse_ms ?? '', r.commit_ms ?? '', r.e2e_ms?.toFixed(2), r.block ?? ''].join(',')).join('\n') + '\n');
  console.log(`${RUN}: offered ${meas.length} committed ${ok.length} (${res.committed_tps.toFixed(1)} tps) codes ${J(codes)} p50 ${res.latency_ms_valid.p50?.toFixed(0)} p95 ${res.latency_ms_valid.p95?.toFixed(0)} p99 ${res.latency_ms_valid.p99?.toFixed(0)} ms`);
  closeAll();
})().catch(e => { console.error('FAILED', e); closeAll(); process.exit(1); });
