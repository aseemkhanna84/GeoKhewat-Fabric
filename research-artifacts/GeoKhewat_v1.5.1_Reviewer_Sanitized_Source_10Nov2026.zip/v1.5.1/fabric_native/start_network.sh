#!/bin/bash
# Starts one Raft orderer and three peers (Survey, Revenue, Registration) as native
# processes, creates channel landrecords, joins all peers. State database: LevelDB.
set -e
source /home/claude/gk10/fabric_native/env.sh
mkdir -p $NET/logs $NET/data $NET/config
# orderer
mkdir -p $NET/config/orderer && cp $NET/fabric/config/orderer.yaml $NET/config/orderer/
OD=$CRYPTO/ordererOrganizations/example.com/orderers/orderer.example.com
FABRIC_CFG_PATH=$NET/config/orderer \
ORDERER_GENERAL_LISTENADDRESS=127.0.0.1 ORDERER_GENERAL_LISTENPORT=7050 \
ORDERER_GENERAL_LOCALMSPID=OrdererMSP ORDERER_GENERAL_LOCALMSPDIR=$OD/msp \
ORDERER_GENERAL_TLS_ENABLED=true ORDERER_GENERAL_TLS_PRIVATEKEY=$OD/tls/server.key \
ORDERER_GENERAL_TLS_CERTIFICATE=$OD/tls/server.crt ORDERER_GENERAL_TLS_ROOTCAS=[$OD/tls/ca.crt] \
ORDERER_GENERAL_CLUSTER_CLIENTCERTIFICATE=$OD/tls/server.crt ORDERER_GENERAL_CLUSTER_CLIENTPRIVATEKEY=$OD/tls/server.key \
ORDERER_GENERAL_CLUSTER_ROOTCAS=[$OD/tls/ca.crt] ORDERER_GENERAL_BOOTSTRAPMETHOD=none \
ORDERER_CHANNELPARTICIPATION_ENABLED=true ORDERER_ADMIN_LISTENADDRESS=127.0.0.1:7053 \
ORDERER_ADMIN_TLS_ENABLED=true ORDERER_ADMIN_TLS_CERTIFICATE=$OD/tls/server.crt ORDERER_ADMIN_TLS_PRIVATEKEY=$OD/tls/server.key \
ORDERER_ADMIN_TLS_ROOTCAS=[$OD/tls/ca.crt] ORDERER_ADMIN_TLS_CLIENTROOTCAS=[$OD/tls/ca.crt] \
ORDERER_FILELEDGER_LOCATION=$NET/data/orderer ORDERER_CONSENSUS_WALDIR=$NET/data/orderer/etcdraft/wal \
ORDERER_CONSENSUS_SNAPDIR=$NET/data/orderer/etcdraft/snapshot ORDERER_OPERATIONS_LISTENADDRESS=127.0.0.1:9443 \
ORDERER_METRICS_PROVIDER=prometheus \
nohup orderer > $NET/logs/orderer.log 2>&1 &
echo $! > $NET/data/orderer.pid
# peers
start_peer() { local org=$1 port=$2 ops=$3
  mkdir -p $NET/config/peer-$org && cp $NET/fabric/config/core.yaml $NET/config/peer-$org/
  local PD=$CRYPTO/peerOrganizations/$org.example.com/peers/peer0.$org.example.com
  local msp=$(case $org in survey) echo SurveyMSP;; revenue) echo RevenueMSP;; registration) echo RegistrationMSP;; esac)
  FABRIC_CFG_PATH=$NET/config/peer-$org CORE_PEER_ID=peer0.$org.example.com \
  CORE_PEER_ADDRESS=peer0.$org.example.com:$port CORE_PEER_LISTENADDRESS=127.0.0.1:$port \
  CORE_PEER_CHAINCODEADDRESS=peer0.$org.example.com:$((port+1)) CORE_PEER_CHAINCODELISTENADDRESS=127.0.0.1:$((port+1)) \
  CORE_PEER_GOSSIP_BOOTSTRAP=peer0.$org.example.com:$port CORE_PEER_GOSSIP_EXTERNALENDPOINT=peer0.$org.example.com:$port \
  CORE_PEER_LOCALMSPID=$msp CORE_PEER_MSPCONFIGPATH=$PD/msp \
  CORE_PEER_TLS_ENABLED=true CORE_PEER_TLS_CERT_FILE=$PD/tls/server.crt CORE_PEER_TLS_KEY_FILE=$PD/tls/server.key \
  CORE_PEER_TLS_ROOTCERT_FILE=$PD/tls/ca.crt CORE_PEER_FILESYSTEMPATH=$NET/data/peer-$org \
  CORE_OPERATIONS_LISTENADDRESS=127.0.0.1:$ops CORE_METRICS_PROVIDER=prometheus \
  CORE_LEDGER_STATE_STATEDATABASE=goleveldb CORE_VM_ENDPOINT= CORE_CHAINCODE_MODE=net \
  CORE_PEER_GATEWAY_ENABLED=true \
  nohup peer node start > $NET/logs/peer-$org.log 2>&1 &
  echo $! > $NET/data/peer-$org.pid
}
start_peer survey 7051 9444
start_peer revenue 8051 9445
start_peer registration 9051 9446
sleep 6
osnadmin channel join --channelID landrecords --config-block $NET/artifacts/landrecords.block -o localhost:7053 \
  --ca-file $ORDERER_CA --client-cert $ORDERER_ADMIN_CERT --client-key $ORDERER_ADMIN_KEY
sleep 3
for org in survey revenue registration; do peer_env $org Admin; peer channel join -b $NET/artifacts/landrecords.block; done
sleep 3
peer_env survey Admin; peer channel getinfo -c landrecords
