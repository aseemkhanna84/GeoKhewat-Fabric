#!/bin/bash
# deploy_cc.sh NAME PORT CONFIG_JSON : chaincode-as-a-service deployment of the GeoKhewat chaincode
# in CC_DIR (default: the current version; the label carries the version from its package.json)
# under chaincode name NAME, served by a local node process on PORT, then InitConfig.
set -e
source /home/claude/gk10/fabric_native/env.sh
NAME=$1; PORT=$2; CFG=$3
CC=${CC_DIR:-/home/claude/gk10/chaincode_v14/geokhewat-chaincode}
VER=${CC_VERSION:-$(node -p "require('$CC/package.json').version")}
P=$NET/pkg/$NAME; rm -rf $P; mkdir -p $P/src
cat > $P/src/connection.json <<J
{"address":"localhost:$PORT","dial_timeout":"10s","tls_required":false}
J
cat > $P/metadata.json <<J
{"type":"ccaas","label":"${NAME}_${VER}"}
J
tar -C $P/src -czf $P/code.tar.gz connection.json
tar -C $P -czf $P/$NAME.tgz code.tar.gz metadata.json
peer_env survey Admin
PKGID=$(peer lifecycle chaincode calculatepackageid $P/$NAME.tgz)
for org in survey revenue registration; do peer_env $org Admin; peer lifecycle chaincode install $P/$NAME.tgz >> $NET/logs/deploy_$NAME.log 2>&1; done
( cd $CC && CHAINCODE_SERVER_ADDRESS=127.0.0.1:$PORT CHAINCODE_ID=$PKGID exec node $CC/node_modules/.bin/fabric-chaincode-node server \
    --chaincode-address 127.0.0.1:$PORT --chaincode-id $PKGID ) > $NET/logs/cc_$NAME.log 2>&1 < /dev/null &
echo $! > $NET/data/cc_$NAME.pid
sleep 2
for org in survey revenue registration; do peer_env $org Admin
  peer lifecycle chaincode approveformyorg -o orderer.example.com:7050 --tls --cafile $ORDERER_CA --channelID landrecords \
    --name $NAME --version $VER --package-id $PKGID --sequence 1 >> $NET/logs/deploy_$NAME.log 2>&1; done
PEERS="--peerAddresses peer0.survey.example.com:7051 --tlsRootCertFiles $CRYPTO/peerOrganizations/survey.example.com/peers/peer0.survey.example.com/tls/ca.crt \
 --peerAddresses peer0.revenue.example.com:8051 --tlsRootCertFiles $CRYPTO/peerOrganizations/revenue.example.com/peers/peer0.revenue.example.com/tls/ca.crt \
 --peerAddresses peer0.registration.example.com:9051 --tlsRootCertFiles $CRYPTO/peerOrganizations/registration.example.com/peers/peer0.registration.example.com/tls/ca.crt"
peer_env survey Admin
peer lifecycle chaincode commit -o orderer.example.com:7050 --tls --cafile $ORDERER_CA --channelID landrecords --name $NAME --version $VER --sequence 1 $PEERS >> $NET/logs/deploy_$NAME.log 2>&1
peer lifecycle chaincode querycommitted --channelID landrecords --name $NAME
ARGS=$(python3 -c "import json,sys; print(json.dumps({'function':sys.argv[2],'Args':[a for a in sys.argv[1].split('|')] if sys.argv[2]!='InitConfig' else [sys.argv[1]]}))" "$CFG" "${INIT_FN:-InitConfig}")
peer chaincode invoke -o orderer.example.com:7050 --tls --cafile $ORDERER_CA -C landrecords -n $NAME $PEERS --waitForEvent -c "$ARGS" 2>&1 | tail -1
echo "PKGID=$PKGID"
