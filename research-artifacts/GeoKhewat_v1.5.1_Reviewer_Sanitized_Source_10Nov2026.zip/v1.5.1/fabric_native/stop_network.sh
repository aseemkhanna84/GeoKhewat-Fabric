#!/bin/bash
NET=/home/claude/gk10/fabric_native
for f in $NET/data/*.pid; do [ -f "$f" ] && kill $(cat $f) 2>/dev/null; done
sleep 2
[ "$1" == "clean" ] && rm -rf $NET/data $NET/logs
exit 0
