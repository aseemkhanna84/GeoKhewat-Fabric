#!/bin/bash
# Clean network, then deploy the current chaincode under seven configurations and v1.3.0 (for defect replay).
cd /home/claude/gk10/fabric_native
./stop_network.sh clean; mkdir -p logs data
./start_network.sh > logs/start.txt 2>&1
R='"roles":{"admin":["SurveyMSP"],"survey":["SurveyMSP"],"registration":["RegistrationMSP"],"revenue":["RevenueMSP"]}'
./deploy_cc.sh gkcr 9101 "{\"strategy\":\"GKCR\",\"precision\":8,\"cover\":\"poly\",\"eps\":0.01,$R}"
./deploy_cc.sh gkc 9102 "{\"strategy\":\"GKC\",\"precision\":8,\"cover\":\"poly\",$R}"
./deploy_cc.sh gkf 9103 "{\"strategy\":\"GKF\",\"precision\":8,\"cover\":\"poly\",$R}"
./deploy_cc.sh b3 9104 "{\"strategy\":\"B3\",\"research\":true,\"precision\":8,$R}"
./deploy_cc.sh b2 9105 "{\"strategy\":\"B2\",\"research\":true,\"precision\":8,$R}"
./deploy_cc.sh gkcrsbe 9106 "{\"strategy\":\"GKCR\",\"precision\":8,\"cover\":\"poly\",\"sbe\":true,$R}"
./deploy_cc.sh gkcrbox 9107 "{\"strategy\":\"GKCR\",\"precision\":8,\"cover\":\"bbox\",$R}"
CC_DIR=/home/claude/gk10/chaincode_v13run/geokhewat-chaincode CC_VERSION=1.3.0 INIT_FN=SetStrategy ./deploy_cc.sh v13 9108 "GKC|8"
