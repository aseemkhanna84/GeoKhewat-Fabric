#!/bin/bash
# Layer B campaign, part B: open-loop load generator, five strategies, two workloads,
# three repetitions, on the network left running by part A.
NET=/home/claude/gk10/fabric_native
cd $NET && source env.sh && cd client
for rep in 1 2 3; do
  for cc in gkf gkc gkcr b3 b2; do
    for rate in 10 20 40 80; do node loadgen.js "{\"cc\":\"$cc\",\"workload\":\"reg\",\"rate\":$rate,\"duration\":30,\"rep\":$rep}" >> ../results/loadgen.log 2>&1; done
    for rate in 10 20 40; do node loadgen.js "{\"cc\":\"$cc\",\"workload\":\"mixed\",\"rate\":$rate,\"duration\":30,\"rep\":$rep}" >> ../results/loadgen.log 2>&1; done
  done
done
echo CAMPAIGN_DONE >> ../results/loadgen.log
